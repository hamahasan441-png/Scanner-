import type { Attachment, ContentBlock } from "./types";

export const MAX_ATTACHMENTS = 10;
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // provider limit for base64 images
export const MAX_TEXT_BYTES = 1024 * 1024;
export const MAX_PDF_BYTES = 20 * 1024 * 1024;

const IMAGE_TYPES = new Set(["image/png", "image/jpeg", "image/gif", "image/webp"]);

/** Extensions we treat as plain text even when the browser reports no MIME type. */
const TEXT_EXTENSIONS = new Set([
  "txt", "md", "markdown", "json", "jsonl", "yaml", "yml", "toml", "ini", "cfg", "env",
  "csv", "tsv", "log", "sql", "sh", "bash", "zsh", "fish", "ps1", "bat",
  "js", "jsx", "mjs", "cjs", "ts", "tsx", "vue", "svelte", "astro",
  "py", "rb", "go", "rs", "java", "kt", "kts", "swift", "c", "h", "cpp", "hpp", "cc", "cs",
  "php", "pl", "lua", "r", "scala", "dart", "ex", "exs", "erl", "hs", "clj",
  "html", "htm", "css", "scss", "sass", "less", "xml", "svg", "graphql", "gql",
  "dockerfile", "gitignore", "editorconfig", "lock", "diff", "patch",
]);

export class AttachmentError extends Error {}

function extensionOf(name: string): string {
  const dot = name.lastIndexOf(".");
  if (dot < 0) return name.toLowerCase();
  return name.slice(dot + 1).toLowerCase();
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function readAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || "");
      const comma = result.indexOf(",");
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.onerror = () => reject(new AttachmentError(`Could not read ${file.name}`));
    reader.readAsDataURL(file);
  });
}

function readAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new AttachmentError(`Could not read ${file.name}`));
    reader.readAsText(file);
  });
}

let counter = 0;
function nextId(): string {
  counter += 1;
  return `att-${Date.now().toString(36)}-${counter}`;
}

/**
 * Classify a dropped file and load it. Throws AttachmentError with a message
 * that is safe to show directly in the UI.
 */
export async function readAttachment(file: File): Promise<Attachment> {
  const mediaType = file.type || "";
  const ext = extensionOf(file.name);

  if (IMAGE_TYPES.has(mediaType)) {
    if (file.size > MAX_IMAGE_BYTES) {
      throw new AttachmentError(
        `${file.name} is ${formatBytes(file.size)}. Images must be under ${formatBytes(MAX_IMAGE_BYTES)}.`,
      );
    }
    return {
      id: nextId(),
      name: file.name,
      size: file.size,
      mediaType,
      kind: "image",
      data: await readAsBase64(file),
      previewUrl: URL.createObjectURL(file),
    };
  }

  if (mediaType.startsWith("image/")) {
    throw new AttachmentError(
      `${file.name} is ${mediaType}. Use PNG, JPEG, GIF or WebP.`,
    );
  }

  if (mediaType === "application/pdf" || ext === "pdf") {
    if (file.size > MAX_PDF_BYTES) {
      throw new AttachmentError(
        `${file.name} is ${formatBytes(file.size)}. PDFs must be under ${formatBytes(MAX_PDF_BYTES)}.`,
      );
    }
    return {
      id: nextId(),
      name: file.name,
      size: file.size,
      mediaType: "application/pdf",
      kind: "pdf",
      data: await readAsBase64(file),
    };
  }

  const looksTextual = mediaType.startsWith("text/") || TEXT_EXTENSIONS.has(ext) || !mediaType;
  if (!looksTextual) {
    throw new AttachmentError(
      `${file.name} (${mediaType}) is not supported. Attach images, PDFs, or text and code files.`,
    );
  }
  if (file.size > MAX_TEXT_BYTES) {
    throw new AttachmentError(
      `${file.name} is ${formatBytes(file.size)}. Text files must be under ${formatBytes(MAX_TEXT_BYTES)}.`,
    );
  }
  return {
    id: nextId(),
    name: file.name,
    size: file.size,
    mediaType: mediaType || "text/plain",
    kind: "text",
    data: await readAsText(file),
  };
}

export function releaseAttachment(file: Attachment): void {
  if (file.previewUrl) URL.revokeObjectURL(file.previewUrl);
}

/** Build the content array for one user turn: files first, then the prompt. */
export function toContentBlocks(text: string, attachments: Attachment[]): ContentBlock[] {
  const blocks: ContentBlock[] = [];

  for (const file of attachments) {
    if (file.kind === "image") {
      blocks.push({
        type: "image",
        source: { type: "base64", media_type: file.mediaType, data: file.data },
      });
    } else if (file.kind === "pdf") {
      blocks.push({
        type: "document",
        source: { type: "base64", media_type: "application/pdf", data: file.data },
      });
    } else {
      const fence = extensionOf(file.name);
      blocks.push({
        type: "text",
        text: `Attached file: ${file.name}\n\n\`\`\`${fence}\n${file.data}\n\`\`\``,
      });
    }
  }

  const prompt = text.trim();
  if (prompt) blocks.push({ type: "text", text: prompt });

  // Every turn needs at least one block, even if the user only dropped files.
  if (blocks.length === 0) blocks.push({ type: "text", text: "(no message)" });
  if (!prompt && attachments.length > 0) {
    blocks.push({ type: "text", text: "Review the attached files." });
  }
  return blocks;
}

export { formatBytes };
