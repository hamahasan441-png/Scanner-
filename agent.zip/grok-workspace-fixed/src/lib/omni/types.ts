import { PROVIDER_DEFAULT_BASE_URL } from "./provider";

/**
 * Wire types for the console. These mirror the Anthropic Messages API shape,
 * which is what AgentRouter and other Anthropic-compatible providers speak.
 */

export type TextBlock = { type: "text"; text: string };

export type ImageBlock = {
  type: "image";
  source: { type: "base64"; media_type: string; data: string };
};

export type DocumentBlock = {
  type: "document";
  source: { type: "base64"; media_type: "application/pdf"; data: string };
};

export type ContentBlock = TextBlock | ImageBlock | DocumentBlock;

export type WireMessage = {
  role: "user" | "assistant";
  content: ContentBlock[];
};

/** One attachment as held in the composer, before it becomes a content block. */
export type Attachment = {
  id: string;
  name: string;
  size: number;
  mediaType: string;
  kind: "image" | "pdf" | "text";
  /** base64 for image/pdf, decoded UTF-8 for text */
  data: string;
  /** object URL for image thumbnails; revoked on removal */
  previewUrl?: string;
};

export type Usage = {
  input_tokens?: number;
  output_tokens?: number;
  cache_read_input_tokens?: number;
  cache_creation_input_tokens?: number;
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  /** Rendered body text. Streams in for assistant turns. */
  text: string;
  /** Extended-thinking output, kept separate so it can be collapsed. */
  thinking: string;
  attachments: Attachment[];
  usage?: Usage;
  model?: string;
  stopReason?: string;
  error?: string;
  /** milliseconds from request start to final event */
  durationMs?: number;
  createdAt: number;
};

export type ChatSettings = {
  apiKey: string;
  baseUrl: string;
  model: string;
  systemPrompt: string;
  maxTokens: number;
  thinkingBudget: number;
  enableThinking: boolean;
};

export type ProviderModel = { id: string; display_name?: string };

export { normalizeBaseUrl } from "./provider";

export const DEFAULT_BASE_URL = PROVIDER_DEFAULT_BASE_URL;

export const FALLBACK_MODELS: string[] = [
  "claude-opus-4-6",
  "claude-sonnet-4-6",
  "claude-opus-4-5",
  "claude-sonnet-4-5",
  "claude-opus-4-1",
  "claude-sonnet-4",
  "claude-3-7-sonnet-latest",
  "claude-3-5-sonnet-latest",
];

export const DEFAULT_SETTINGS: ChatSettings = {
  apiKey: "",
  baseUrl: DEFAULT_BASE_URL,
  model: "",
  systemPrompt:
    "You are Omni, a precise engineering assistant. Answer directly, show working code, and say when you are unsure.",
  maxTokens: 8192,
  thinkingBudget: 4096,
  enableThinking: false,
};

export function maskKey(key: string): string {
  const value = (key || "").trim();
  if (!value) return "not set";
  if (value.length <= 10) return `${value.slice(0, 2)}${"•".repeat(Math.max(value.length - 2, 1))}`;
  return `${value.slice(0, 6)}…${value.slice(-4)}`;
}
