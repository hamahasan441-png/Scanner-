import {
  DEFAULT_SETTINGS,
  normalizeBaseUrl,
  type ChatMessage,
  type ChatSettings,
} from "./types";

const SETTINGS_KEY = "omni.console.settings.v1";
const THREAD_KEY = "omni.console.thread.v1";

function canStore(): boolean {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

export function loadSettings(): ChatSettings {
  if (!canStore()) return { ...DEFAULT_SETTINGS };
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw) as Partial<ChatSettings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      baseUrl: normalizeBaseUrl(parsed.baseUrl || DEFAULT_SETTINGS.baseUrl),
      maxTokens: clamp(parsed.maxTokens ?? DEFAULT_SETTINGS.maxTokens, 256, 64000),
      thinkingBudget: clamp(parsed.thinkingBudget ?? DEFAULT_SETTINGS.thinkingBudget, 1024, 32000),
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(settings: ChatSettings): void {
  if (!canStore()) return;
  try {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // Storage can be full or blocked; the session still works in memory.
  }
}

export function clearStoredKey(): void {
  if (!canStore()) return;
  try {
    const current = loadSettings();
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify({ ...current, apiKey: "" }));
  } catch {
    // ignore
  }
}

/** Thread persistence drops attachment payloads — they can be megabytes each. */
export function loadThread(): ChatMessage[] {
  if (!canStore()) return [];
  try {
    const raw = window.localStorage.getItem(THREAD_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as ChatMessage[]) : [];
  } catch {
    return [];
  }
}

export function saveThread(messages: ChatMessage[]): void {
  if (!canStore()) return;
  try {
    const trimmed = messages.slice(-60).map((message) => ({
      ...message,
      attachments: message.attachments.map((file) => ({
        ...file,
        data: "",
        previewUrl: undefined,
      })),
    }));
    window.localStorage.setItem(THREAD_KEY, JSON.stringify(trimmed));
  } catch {
    // ignore
  }
}

export function clearThread(): void {
  if (!canStore()) return;
  try {
    window.localStorage.removeItem(THREAD_KEY);
  } catch {
    // ignore
  }
}

export function clamp(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(Math.max(Math.round(value), min), max);
}
