/**
 * Helpers shared by the /api/chat and /api/models routes.
 *
 * Kept free of framework and browser imports so they can be unit tested and
 * run inside the server bundle unchanged.
 */

export const ANTHROPIC_VERSION = "2023-06-01";
export const PROVIDER_DEFAULT_BASE_URL = "https://agentrouter.org";

/**
 * Providers expect the origin only. People routinely paste the full endpoint
 * they found in docs, so trim the well-known suffixes instead of letting the
 * request 404 later.
 */
export function normalizeBaseUrl(raw: unknown): string {
  let value = typeof raw === "string" ? raw.trim() : "";
  if (!value) return PROVIDER_DEFAULT_BASE_URL;
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
  value = value.replace(/\/+$/, "");
  value = value.replace(/\/v1\/(messages|models|chat\/completions)\/?$/i, "");
  value = value.replace(/\/v1\/?$/i, "");
  return value || PROVIDER_DEFAULT_BASE_URL;
}

export function clampInt(raw: unknown, fallback: number, min: number, max: number): number {
  const value = typeof raw === "number" ? raw : Number(raw);
  if (!Number.isFinite(value)) return fallback;
  return Math.min(Math.max(Math.round(value), min), max);
}

/** Turn an upstream status into something a person can act on. */
export function explainStatus(status: number, baseUrl: string): string {
  if (status === 401 || status === 403) {
    return "The provider rejected this API key. Check it is correct, active, and has credit.";
  }
  if (status === 404) {
    return `No endpoint found at ${baseUrl}. The base URL should be the provider origin only, with no path.`;
  }
  if (status === 429) {
    return "Rate limited by the provider. Wait a moment and send again.";
  }
  if (status === 400) {
    return "The provider rejected the request. The model name or an attachment may be unsupported.";
  }
  if (status === 413) {
    return "The request was too large. Remove an attachment and try again.";
  }
  if (status >= 500) {
    return "The provider had a server error. Try again shortly.";
  }
  return `The provider returned HTTP ${status}.`;
}

/** Accepts both `{data:[...]}` and a bare array, of strings or objects. */
export function extractModelIds(payload: unknown): string[] {
  const list = Array.isArray(payload)
    ? payload
    : payload && typeof payload === "object" && Array.isArray((payload as { data?: unknown[] }).data)
      ? (payload as { data: unknown[] }).data
      : [];

  const ids: string[] = [];
  for (const item of list) {
    if (typeof item === "string") {
      if (item) ids.push(item);
    } else if (item && typeof item === "object") {
      const record = item as { id?: unknown; name?: unknown };
      const id =
        typeof record.id === "string" ? record.id : typeof record.name === "string" ? record.name : "";
      if (id) ids.push(id);
    }
  }
  return Array.from(new Set(ids));
}

/** Headers every Anthropic-compatible provider accepts. */
export function providerHeaders(apiKey: string, accept: string): Record<string, string> {
  return {
    accept,
    authorization: `Bearer ${apiKey}`,
    "x-api-key": apiKey,
    "anthropic-version": ANTHROPIC_VERSION,
  };
}

export type ChatPayloadInput = {
  model: string;
  messages: unknown[];
  system?: string;
  maxTokens?: unknown;
  thinkingBudget?: unknown;
  enableThinking?: unknown;
};

/** Build the upstream request body, clamping anything the caller got wrong. */
export function buildChatPayload(input: ChatPayloadInput): Record<string, unknown> {
  const maxTokens = clampInt(input.maxTokens, 8192, 256, 64000);
  const payload: Record<string, unknown> = {
    model: input.model,
    max_tokens: maxTokens,
    stream: true,
    messages: input.messages,
  };

  const system = typeof input.system === "string" ? input.system.trim() : "";
  if (system) payload.system = system;

  if (input.enableThinking === true) {
    // The budget has to leave room for the visible answer.
    const ceiling = Math.max(1024, maxTokens - 1024);
    const budget = clampInt(input.thinkingBudget, 4096, 1024, ceiling);
    if (budget >= 1024 && budget < maxTokens) {
      payload.thinking = { type: "enabled", budget_tokens: budget };
    }
  }

  return payload;
}

export function jsonResponse(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}

export function errorResponse(message: string, status: number, detail?: string): Response {
  return jsonResponse({ error: { message, detail } }, status);
}
