import type { ChatSettings, Usage, WireMessage } from "./types";

export type StreamHandlers = {
  onText: (delta: string) => void;
  onThinking: (delta: string) => void;
  onMeta: (meta: { model?: string; usage?: Usage; stopReason?: string }) => void;
};

export class ChatStreamError extends Error {
  detail?: string;
  status?: number;
  constructor(message: string, options?: { detail?: string; status?: number }) {
    super(message);
    this.name = "ChatStreamError";
    this.detail = options?.detail;
    this.status = options?.status;
  }
}

type SseEvent = { event: string; data: string };

/**
 * Split off every complete SSE frame in the buffer, returning the frames and
 * whatever partial frame is left over. Handles both \n\n and \r\n\r\n.
 */
export function takeFrames(buffer: string): { frames: string[]; rest: string } {
  const frames: string[] = [];
  let rest = buffer;
  for (;;) {
    const lf = rest.indexOf("\n\n");
    const crlf = rest.indexOf("\r\n\r\n");
    let index = -1;
    let width = 2;
    if (crlf >= 0 && (lf < 0 || crlf < lf)) {
      index = crlf;
      width = 4;
    } else if (lf >= 0) {
      index = lf;
      width = 2;
    }
    if (index < 0) break;
    frames.push(rest.slice(0, index));
    rest = rest.slice(index + width);
  }
  return { frames, rest };
}

export function decodeFrame(frame: string): SseEvent | null {
  let event = "message";
  const dataLines: string[] = [];
  for (const line of frame.split(/\r?\n/)) {
    if (!line || line.startsWith(":")) continue;
    if (line.startsWith("event:")) {
      event = line.slice(6).trim();
    } else if (line.startsWith("data:")) {
      dataLines.push(line.slice(5).replace(/^ /, ""));
    }
  }
  if (dataLines.length === 0) return null;
  return { event, data: dataLines.join("\n") };
}

/**
 * POST to the local proxy and drive the handlers as events arrive.
 * Resolves when the turn completes; rejects with ChatStreamError on failure.
 */
export async function streamChat(
  settings: ChatSettings,
  messages: WireMessage[],
  handlers: StreamHandlers,
  signal: AbortSignal,
): Promise<void> {
  const response = await fetch("/api/chat", {
    method: "POST",
    signal,
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      apiKey: settings.apiKey,
      baseUrl: settings.baseUrl,
      model: settings.model,
      system: settings.systemPrompt,
      maxTokens: settings.maxTokens,
      thinkingBudget: settings.thinkingBudget,
      enableThinking: settings.enableThinking,
      messages,
    }),
  });

  if (!response.ok || !response.body) {
    let message = `Request failed with HTTP ${response.status}.`;
    let detail: string | undefined;
    try {
      const payload = await response.json();
      if (payload?.error?.message) message = String(payload.error.message);
      if (payload?.error?.detail) detail = String(payload.error.detail);
    } catch {
      // keep the generic message
    }
    throw new ChatStreamError(message, { detail, status: response.status });
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const { frames, rest } = takeFrames(buffer);
      buffer = rest;
      for (const frame of frames) {
        const decoded = decodeFrame(frame);
        if (!decoded) continue;
        if (decoded.data === "[DONE]") return;
        applyEvent(decoded, handlers);
      }
    }
  } finally {
    reader.releaseLock();
  }
}

export function applyEvent(sse: SseEvent, handlers: StreamHandlers): void {
  let data: Record<string, unknown>;
  try {
    data = JSON.parse(sse.data) as Record<string, unknown>;
  } catch {
    return;
  }

  const type = (data.type as string) || sse.event;

  if (type === "error") {
    const err = (data.error as { message?: string }) || {};
    throw new ChatStreamError(err.message || "The provider reported an error mid-stream.");
  }

  if (type === "message_start") {
    const message = (data.message as { model?: string; usage?: Usage }) || {};
    handlers.onMeta({ model: message.model, usage: message.usage });
    return;
  }

  if (type === "content_block_delta") {
    const delta = (data.delta as Record<string, unknown>) || {};
    const deltaType = delta.type as string | undefined;
    if (deltaType === "thinking_delta" || typeof delta.thinking === "string") {
      handlers.onThinking(String(delta.thinking || ""));
    } else if (deltaType === "text_delta" || typeof delta.text === "string") {
      handlers.onText(String(delta.text || ""));
    }
    return;
  }

  if (type === "message_delta") {
    const delta = (data.delta as { stop_reason?: string }) || {};
    handlers.onMeta({ stopReason: delta.stop_reason, usage: data.usage as Usage | undefined });
    return;
  }

  if (type === "message_stop") {
    handlers.onMeta({ stopReason: "end_turn" });
  }
}
