import assert from "node:assert/strict";
import { test } from "node:test";

import {
  buildChatPayload,
  clampInt,
  explainStatus,
  extractModelIds,
  normalizeBaseUrl,
  providerHeaders,
} from "./provider.ts";
import { applyEvent, decodeFrame, takeFrames, ChatStreamError } from "./stream.ts";
import { toContentBlocks } from "./attachments.ts";
import type { Attachment } from "./types.ts";

test("normalizeBaseUrl trims the paths people paste from provider docs", () => {
  assert.equal(normalizeBaseUrl("https://agentrouter.org"), "https://agentrouter.org");
  assert.equal(normalizeBaseUrl("https://agentrouter.org/"), "https://agentrouter.org");
  assert.equal(normalizeBaseUrl("https://agentrouter.org/v1"), "https://agentrouter.org");
  assert.equal(normalizeBaseUrl("https://agentrouter.org/v1/"), "https://agentrouter.org");
  assert.equal(normalizeBaseUrl("https://agentrouter.org/v1/messages"), "https://agentrouter.org");
  assert.equal(normalizeBaseUrl("https://x.example/v1/chat/completions"), "https://x.example");
  assert.equal(normalizeBaseUrl("  agentrouter.org  "), "https://agentrouter.org");
  assert.equal(normalizeBaseUrl("http://localhost:8787"), "http://localhost:8787");
});

test("normalizeBaseUrl falls back rather than producing an unusable URL", () => {
  assert.equal(normalizeBaseUrl(""), "https://agentrouter.org");
  assert.equal(normalizeBaseUrl(null), "https://agentrouter.org");
  assert.equal(normalizeBaseUrl(42), "https://agentrouter.org");
});

test("clampInt keeps bad input inside the allowed range", () => {
  assert.equal(clampInt(500, 100, 10, 1000), 500);
  assert.equal(clampInt(5, 100, 10, 1000), 10);
  assert.equal(clampInt(9999, 100, 10, 1000), 1000);
  assert.equal(clampInt("abc", 100, 10, 1000), 100);
  assert.equal(clampInt(undefined, 100, 10, 1000), 100);
  assert.equal(clampInt(12.6, 100, 10, 1000), 13);
});

test("buildChatPayload always streams and carries the model", () => {
  const payload = buildChatPayload({ model: "claude-sonnet-4-6", messages: [{ role: "user" }] });
  assert.equal(payload.model, "claude-sonnet-4-6");
  assert.equal(payload.stream, true);
  assert.equal(payload.max_tokens, 8192);
  assert.equal(payload.system, undefined);
  assert.equal(payload.thinking, undefined);
});

test("buildChatPayload only enables thinking when it fits under max_tokens", () => {
  const on = buildChatPayload({
    model: "m",
    messages: [],
    enableThinking: true,
    thinkingBudget: 4096,
    maxTokens: 16000,
  });
  assert.deepEqual(on.thinking, { type: "enabled", budget_tokens: 4096 });

  // A budget larger than the response limit would be rejected upstream.
  const squeezed = buildChatPayload({
    model: "m",
    messages: [],
    enableThinking: true,
    thinkingBudget: 30000,
    maxTokens: 2048,
  });
  assert.deepEqual(squeezed.thinking, { type: "enabled", budget_tokens: 1024 });

  const off = buildChatPayload({ model: "m", messages: [], enableThinking: false });
  assert.equal(off.thinking, undefined);
});

test("buildChatPayload drops an empty system prompt", () => {
  assert.equal(buildChatPayload({ model: "m", messages: [], system: "   " }).system, undefined);
  assert.equal(buildChatPayload({ model: "m", messages: [], system: " hi " }).system, "hi");
});

test("explainStatus names the fix, not just the code", () => {
  assert.match(explainStatus(401, "https://x"), /rejected this API key/);
  assert.match(explainStatus(403, "https://x"), /rejected this API key/);
  assert.match(explainStatus(404, "https://x"), /origin only/);
  assert.match(explainStatus(429, "https://x"), /Rate limited/);
  assert.match(explainStatus(503, "https://x"), /server error/);
});

test("extractModelIds handles every shape providers return", () => {
  assert.deepEqual(extractModelIds({ data: [{ id: "a" }, { id: "b" }] }), ["a", "b"]);
  assert.deepEqual(extractModelIds(["a", "b"]), ["a", "b"]);
  assert.deepEqual(extractModelIds([{ name: "a" }]), ["a"]);
  assert.deepEqual(extractModelIds({ data: [{ id: "a" }, { id: "a" }] }), ["a"]);
  assert.deepEqual(extractModelIds(null), []);
  assert.deepEqual(extractModelIds({ nope: 1 }), []);
});

test("providerHeaders sends the key both ways provider APIs accept", () => {
  const headers = providerHeaders("sk-test", "text/event-stream");
  assert.equal(headers.authorization, "Bearer sk-test");
  assert.equal(headers["x-api-key"], "sk-test");
  assert.equal(headers["anthropic-version"], "2023-06-01");
  assert.equal(headers.accept, "text/event-stream");
});

test("takeFrames splits complete frames and keeps the partial tail", () => {
  const { frames, rest } = takeFrames("event: a\ndata: 1\n\nevent: b\ndata: 2\n\nevent: c\ndata:");
  assert.equal(frames.length, 2);
  assert.equal(rest, "event: c\ndata:");
});

test("takeFrames handles CRLF frame boundaries", () => {
  const { frames, rest } = takeFrames("data: 1\r\n\r\ndata: 2\r\n\r\n");
  assert.deepEqual(frames, ["data: 1", "data: 2"]);
  assert.equal(rest, "");
});

test("takeFrames returns nothing until a boundary arrives", () => {
  const { frames, rest } = takeFrames("data: partial");
  assert.deepEqual(frames, []);
  assert.equal(rest, "data: partial");
});

test("decodeFrame reads the event name and joins multi-line data", () => {
  assert.deepEqual(decodeFrame("event: ping\ndata: {}"), { event: "ping", data: "{}" });
  assert.deepEqual(decodeFrame("data: one\ndata: two"), { event: "message", data: "one\ntwo" });
  assert.equal(decodeFrame(": heartbeat comment"), null);
  assert.equal(decodeFrame(""), null);
});

function collect() {
  const state = { text: "", thinking: "", meta: [] as unknown[] };
  return {
    state,
    handlers: {
      onText: (d: string) => {
        state.text += d;
      },
      onThinking: (d: string) => {
        state.thinking += d;
      },
      onMeta: (m: unknown) => {
        state.meta.push(m);
      },
    },
  };
}

test("applyEvent accumulates text and thinking separately", () => {
  const { state, handlers } = collect();
  applyEvent(
    { event: "x", data: JSON.stringify({ type: "content_block_delta", delta: { type: "text_delta", text: "Hel" } }) },
    handlers,
  );
  applyEvent(
    { event: "x", data: JSON.stringify({ type: "content_block_delta", delta: { type: "text_delta", text: "lo" } }) },
    handlers,
  );
  applyEvent(
    { event: "x", data: JSON.stringify({ type: "content_block_delta", delta: { type: "thinking_delta", thinking: "hmm" } }) },
    handlers,
  );
  assert.equal(state.text, "Hello");
  assert.equal(state.thinking, "hmm");
});

test("applyEvent reports model and usage from message_start", () => {
  const { state, handlers } = collect();
  applyEvent(
    {
      event: "x",
      data: JSON.stringify({
        type: "message_start",
        message: { model: "claude-sonnet-4-6", usage: { input_tokens: 12 } },
      }),
    },
    handlers,
  );
  assert.deepEqual(state.meta[0], { model: "claude-sonnet-4-6", usage: { input_tokens: 12 } });
});

test("applyEvent turns a provider error frame into a throw", () => {
  const { handlers } = collect();
  assert.throws(
    () =>
      applyEvent(
        { event: "error", data: JSON.stringify({ type: "error", error: { message: "overloaded" } }) },
        handlers,
      ),
    (error: unknown) => error instanceof ChatStreamError && /overloaded/.test((error as Error).message),
  );
});

test("applyEvent ignores frames that are not JSON", () => {
  const { state, handlers } = collect();
  applyEvent({ event: "x", data: "not json at all" }, handlers);
  assert.equal(state.text, "");
  assert.equal(state.meta.length, 0);
});

function textFile(name: string, data: string): Attachment {
  return { id: name, name, size: data.length, mediaType: "text/plain", kind: "text", data };
}

test("toContentBlocks puts files before the prompt", () => {
  const blocks = toContentBlocks("what does this do?", [textFile("a.py", "print(1)")]);
  assert.equal(blocks.length, 2);
  assert.equal(blocks[0].type, "text");
  assert.match((blocks[0] as { text: string }).text, /Attached file: a\.py/);
  assert.match((blocks[0] as { text: string }).text, /```py\nprint\(1\)\n```/);
  assert.equal((blocks[1] as { text: string }).text, "what does this do?");
});

test("toContentBlocks encodes images and PDFs as source blocks", () => {
  const blocks = toContentBlocks("", [
    { id: "1", name: "a.png", size: 3, mediaType: "image/png", kind: "image", data: "AAA" },
    { id: "2", name: "b.pdf", size: 3, mediaType: "application/pdf", kind: "pdf", data: "BBB" },
  ]);
  assert.equal(blocks[0].type, "image");
  assert.deepEqual((blocks[0] as { source: unknown }).source, {
    type: "base64",
    media_type: "image/png",
    data: "AAA",
  });
  assert.equal(blocks[1].type, "document");
});

test("toContentBlocks never sends an empty turn", () => {
  const empty = toContentBlocks("", []);
  assert.equal(empty.length, 1);
  assert.equal((empty[0] as { text: string }).text, "(no message)");

  // Files with no prompt still need something for the model to act on.
  const filesOnly = toContentBlocks("", [textFile("a.txt", "hi")]);
  assert.equal(filesOnly.at(-1)?.type, "text");
  assert.match((filesOnly.at(-1) as { text: string }).text, /Review the attached files/);
});
