import { createFileRoute } from "@tanstack/react-router";
import {
  buildChatPayload,
  errorResponse,
  explainStatus,
  normalizeBaseUrl,
  providerHeaders,
} from "@/lib/omni/provider";

/**
 * Streaming proxy for the console.
 *
 * The browser cannot call most providers directly (they send no CORS headers),
 * so the request is relayed here and the SSE body is piped straight back. The
 * API key arrives in the request body from the user's own browser, is used for
 * exactly one upstream call, and is never logged or persisted server-side.
 */

const UPSTREAM_TIMEOUT_MS = 300_000;

type IncomingBody = {
  apiKey?: unknown;
  baseUrl?: unknown;
  model?: unknown;
  system?: unknown;
  messages?: unknown;
  maxTokens?: unknown;
  thinkingBudget?: unknown;
  enableThinking?: unknown;
};

async function readBodyPreview(response: Response): Promise<string> {
  try {
    return (await response.text()).slice(0, 2000);
  } catch {
    return "(no response body)";
  }
}

async function handleChat({ request }: { request: Request }): Promise<Response> {
  let body: IncomingBody;
  try {
    body = (await request.json()) as IncomingBody;
  } catch {
    return errorResponse("Request body was not valid JSON.", 400);
  }

  const apiKey = typeof body.apiKey === "string" ? body.apiKey.trim() : "";
  if (!apiKey) {
    return errorResponse("Add your API key in Settings before sending a message.", 401);
  }

  const messages = Array.isArray(body.messages) ? body.messages : [];
  if (messages.length === 0) {
    return errorResponse("No messages to send.", 400);
  }

  const model = typeof body.model === "string" ? body.model.trim() : "";
  if (!model) {
    return errorResponse("Pick a model in Settings before sending a message.", 400);
  }

  const baseUrl = normalizeBaseUrl(body.baseUrl);
  const payload = buildChatPayload({
    model,
    messages,
    system: typeof body.system === "string" ? body.system : undefined,
    maxTokens: body.maxTokens,
    thinkingBudget: body.thinkingBudget,
    enableThinking: body.enableThinking,
  });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);
  // Cancelling in the browser should release the upstream connection too.
  request.signal?.addEventListener("abort", () => controller.abort(), { once: true });

  let upstream: Response;
  try {
    upstream = await fetch(`${baseUrl}/v1/messages`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        ...providerHeaders(apiKey, "text/event-stream"),
        "content-type": "application/json",
      },
      body: JSON.stringify(payload),
    });
  } catch (error) {
    clearTimeout(timeout);
    if (controller.signal.aborted) {
      return errorResponse("The request was cancelled.", 499);
    }
    const detail = error instanceof Error ? error.message : String(error);
    return errorResponse(
      `Could not reach ${baseUrl}. Check the base URL and your connection.`,
      502,
      detail,
    );
  }

  if (!upstream.ok || !upstream.body) {
    clearTimeout(timeout);
    const detail = await readBodyPreview(upstream);
    return errorResponse(explainStatus(upstream.status, baseUrl), upstream.status, detail);
  }

  const stream = new ReadableStream<Uint8Array>({
    async start(out) {
      const reader = upstream.body!.getReader();
      try {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          out.enqueue(value);
        }
        out.close();
      } catch (error) {
        // Surface a mid-stream break as an SSE error the console understands
        // rather than truncating the answer silently.
        const message = error instanceof Error ? error.message : String(error);
        const frame = JSON.stringify({ type: "error", error: { message } });
        out.enqueue(new TextEncoder().encode(`event: error\ndata: ${frame}\n\n`));
        out.close();
      } finally {
        clearTimeout(timeout);
        reader.releaseLock();
      }
    },
    cancel() {
      clearTimeout(timeout);
      controller.abort();
    },
  });

  return new Response(stream, {
    status: 200,
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
      // Stops proxies and the Vercel edge from buffering the stream.
      "x-accel-buffering": "no",
    },
  });
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: handleChat,
    },
  },
});
