import { createFileRoute } from "@tanstack/react-router";
import {
  errorResponse,
  explainStatus,
  extractModelIds,
  jsonResponse,
  normalizeBaseUrl,
  providerHeaders,
} from "@/lib/omni/provider";

/**
 * Key check and model discovery, behind the Settings panel's "Test connection"
 * button. The key is relayed once and dropped — nothing is stored server-side.
 */

const TIMEOUT_MS = 20_000;

async function handleModels({ request }: { request: Request }): Promise<Response> {
  let body: { apiKey?: unknown; baseUrl?: unknown };
  try {
    body = (await request.json()) as { apiKey?: unknown; baseUrl?: unknown };
  } catch {
    return errorResponse("Request body was not valid JSON.", 400);
  }

  const apiKey = typeof body.apiKey === "string" ? body.apiKey.trim() : "";
  if (!apiKey) {
    return errorResponse("Enter an API key first.", 401);
  }

  const baseUrl = normalizeBaseUrl(body.baseUrl);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const upstream = await fetch(`${baseUrl}/v1/models`, {
      method: "GET",
      signal: controller.signal,
      headers: providerHeaders(apiKey, "application/json"),
    });

    if (!upstream.ok) {
      const detail = (await upstream.text().catch(() => "")).slice(0, 1000);
      // A 404 here is common and harmless: not every provider exposes /v1/models.
      const message =
        upstream.status === 404
          ? `${baseUrl} does not list models. The key may still work — type a model name by hand.`
          : explainStatus(upstream.status, baseUrl);
      return errorResponse(message, upstream.status, detail);
    }

    const payload = await upstream.json().catch(() => null);
    return jsonResponse({ ok: true, baseUrl, models: extractModelIds(payload) }, 200);
  } catch (error) {
    if (controller.signal.aborted) {
      return errorResponse(`${baseUrl} did not respond within 20 seconds.`, 504);
    }
    const detail = error instanceof Error ? error.message : String(error);
    return errorResponse(
      `Could not reach ${baseUrl}. Check the base URL and your connection.`,
      502,
      detail,
    );
  } finally {
    clearTimeout(timeout);
  }
}

export const Route = createFileRoute("/api/models")({
  server: {
    handlers: {
      POST: handleModels,
    },
  },
});
