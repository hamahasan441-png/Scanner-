import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ClipboardEvent as ReactClipboardEvent,
  type DragEvent as ReactDragEvent,
  type KeyboardEvent as ReactKeyboardEvent,
} from "react";
import { Button } from "@/components/ui/button";
import { SettingsPanel } from "@/components/omni/settings-panel";
import { cn } from "@/lib/utils";
import {
  AttachmentError,
  MAX_ATTACHMENTS,
  formatBytes,
  readAttachment,
  releaseAttachment,
  toContentBlocks,
} from "@/lib/omni/attachments";
import {
  clearThread,
  loadSettings,
  loadThread,
  saveSettings,
  saveThread,
} from "@/lib/omni/settings";
import { ChatStreamError, streamChat } from "@/lib/omni/stream";
import {
  DEFAULT_SETTINGS,
  maskKey,
  type Attachment,
  type ChatMessage,
  type ChatSettings,
  type WireMessage,
} from "@/lib/omni/types";

let messageSeq = 0;
function nextId(prefix: string): string {
  messageSeq += 1;
  return `${prefix}-${Date.now().toString(36)}-${messageSeq}`;
}

function hostOf(url: string): string {
  try {
    return new URL(url).host;
  } catch {
    return url || "no provider";
  }
}

export function AgentConsole() {
  const [settings, setSettings] = useState<ChatSettings>(DEFAULT_SETTINGS);
  const [models, setModels] = useState<string[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  const scroller = useRef<HTMLDivElement>(null);
  const textarea = useRef<HTMLTextAreaElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const dragDepth = useRef(0);
  const pinnedToBottom = useRef(true);

  // Restore browser-local state after mount so SSR output stays stable.
  useEffect(() => {
    const stored = loadSettings();
    setSettings(stored);
    setMessages(loadThread());
    setShowSettings(!stored.apiKey);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveThread(messages);
  }, [messages, hydrated]);

  useEffect(() => {
    if (!pinnedToBottom.current) return;
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [messages, streaming]);

  useEffect(() => () => abortRef.current?.abort(), []);

  const ready = Boolean(settings.apiKey.trim() && settings.model.trim());

  const updateSettings = useCallback((next: ChatSettings) => {
    setSettings(next);
    saveSettings(next);
  }, []);

  const addFiles = useCallback(
    async (files: FileList | File[]) => {
      const incoming = Array.from(files);
      if (incoming.length === 0) return;

      const problems: string[] = [];
      const accepted: Attachment[] = [];

      for (const file of incoming) {
        if (attachments.length + accepted.length >= MAX_ATTACHMENTS) {
          problems.push(`Only ${MAX_ATTACHMENTS} files can be attached at once.`);
          break;
        }
        try {
          accepted.push(await readAttachment(file));
        } catch (error) {
          problems.push(
            error instanceof AttachmentError ? error.message : `Could not read ${file.name}.`,
          );
        }
      }

      if (accepted.length > 0) setAttachments((prev) => [...prev, ...accepted]);
      setNotice(problems.length > 0 ? problems.join(" ") : null);
    },
    [attachments.length],
  );

  function removeAttachment(id: string) {
    setAttachments((prev) => {
      const target = prev.find((file) => file.id === id);
      if (target) releaseAttachment(target);
      return prev.filter((file) => file.id !== id);
    });
  }

  function clearAttachments(list: Attachment[]) {
    list.forEach(releaseAttachment);
  }

  function onDragEnter(event: ReactDragEvent) {
    if (!Array.from(event.dataTransfer.types).includes("Files")) return;
    event.preventDefault();
    dragDepth.current += 1;
    setDragging(true);
  }

  function onDragLeave(event: ReactDragEvent) {
    event.preventDefault();
    dragDepth.current = Math.max(0, dragDepth.current - 1);
    if (dragDepth.current === 0) setDragging(false);
  }

  function onDrop(event: ReactDragEvent) {
    event.preventDefault();
    dragDepth.current = 0;
    setDragging(false);
    if (event.dataTransfer.files.length > 0) void addFiles(event.dataTransfer.files);
  }

  function onPaste(event: ReactClipboardEvent) {
    const files = Array.from(event.clipboardData.files);
    if (files.length === 0) return;
    event.preventDefault();
    void addFiles(files);
  }

  function onScroll() {
    const node = scroller.current;
    if (!node) return;
    const distance = node.scrollHeight - node.scrollTop - node.clientHeight;
    pinnedToBottom.current = distance < 80;
  }

  function stop() {
    abortRef.current?.abort();
    abortRef.current = null;
    setStreaming(false);
  }

  function startNewChat() {
    stop();
    clearAttachments(attachments);
    setAttachments([]);
    setMessages([]);
    setInput("");
    setNotice(null);
    clearThread();
  }

  /** Rebuild the provider-facing history from the rendered thread. */
  const buildWireMessages = useCallback(
    (history: ChatMessage[]): WireMessage[] => {
      const wire: WireMessage[] = [];
      for (const message of history) {
        if (message.error) continue;
        if (message.role === "user") {
          // Thread history is persisted without file payloads, so a message
          // restored after reload can carry attachments with no data. Send a
          // note instead of an empty base64 block the provider would reject.
          const live = message.attachments.filter((file) => file.data.length > 0);
          const dropped = message.attachments.filter((file) => file.data.length === 0);
          let text = message.text;
          if (dropped.length > 0) {
            const names = dropped.map((file) => file.name).join(", ");
            text = `${text}\n\n[Earlier attachments not resent after reload: ${names}]`.trim();
          }
          wire.push({ role: "user", content: toContentBlocks(text, live) });
        } else if (message.text.trim()) {
          wire.push({ role: "assistant", content: [{ type: "text", text: message.text }] });
        }
      }
      return wire;
    },
    [],
  );

  async function send() {
    const prompt = input.trim();
    if (streaming) return;
    if (!prompt && attachments.length === 0) return;
    if (!ready) {
      setShowSettings(true);
      setNotice("Add your API key and pick a model before sending.");
      return;
    }

    const outgoing: ChatMessage = {
      id: nextId("user"),
      role: "user",
      text: prompt,
      thinking: "",
      attachments,
      createdAt: Date.now(),
    };
    const placeholder: ChatMessage = {
      id: nextId("assistant"),
      role: "assistant",
      text: "",
      thinking: "",
      attachments: [],
      createdAt: Date.now(),
    };

    const history = [...messages, outgoing];
    setMessages([...history, placeholder]);
    setInput("");
    setAttachments([]);
    setNotice(null);
    pinnedToBottom.current = true;

    const controller = new AbortController();
    abortRef.current = controller;
    setStreaming(true);
    const startedAt = performance.now();

    const patch = (update: Partial<ChatMessage>) => {
      setMessages((prev) =>
        prev.map((message) => (message.id === placeholder.id ? { ...message, ...update } : message)),
      );
    };

    let text = "";
    let thinking = "";

    try {
      await streamChat(
        settings,
        buildWireMessages(history),
        {
          onText: (delta) => {
            text += delta;
            patch({ text });
          },
          onThinking: (delta) => {
            thinking += delta;
            patch({ thinking });
          },
          // message_start carries the model, message_delta the stop reason;
          // each omits the other's fields, so only apply what is present.
          onMeta: (meta) => {
            const defined: Partial<ChatMessage> = {};
            if (meta.model) defined.model = meta.model;
            if (meta.stopReason) defined.stopReason = meta.stopReason;
            if (meta.usage) {
              setMessages((prev) =>
                prev.map((message) =>
                  message.id === placeholder.id
                    ? { ...message, usage: { ...message.usage, ...meta.usage } }
                    : message,
                ),
              );
            }
            if (Object.keys(defined).length > 0) patch(defined);
          },
        },
        controller.signal,
      );
      patch({ durationMs: Math.round(performance.now() - startedAt) });
    } catch (error) {
      if (controller.signal.aborted) {
        patch({
          text: text || "",
          stopReason: "cancelled",
          durationMs: Math.round(performance.now() - startedAt),
        });
      } else if (error instanceof ChatStreamError) {
        patch({ error: error.detail ? `${error.message}\n\n${error.detail}` : error.message });
        if (error.status === 401 || error.status === 403) setShowSettings(true);
      } else {
        patch({ error: error instanceof Error ? error.message : String(error) });
      }
    } finally {
      abortRef.current = null;
      setStreaming(false);
      textarea.current?.focus();
    }
  }

  function onKeyDown(event: ReactKeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void send();
    }
  }

  const status = useMemo(() => {
    if (streaming) return { label: "streaming", tone: "text-sage" };
    if (!settings.apiKey.trim()) return { label: "no API key", tone: "text-danger" };
    if (!settings.model.trim()) return { label: "no model", tone: "text-danger" };
    return { label: "ready", tone: "text-muted" };
  }, [streaming, settings.apiKey, settings.model]);

  return (
    <div className="mx-auto max-w-4xl">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl sm:text-5xl">Console</h1>
          <p className="mt-3 max-w-[60ch] text-muted">
            Chat with your own provider account. Drop in images, PDFs, or source files and ask
            about them.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setShowSettings((v) => !v)}
            className="min-h-11 rounded-sm border border-border px-4 text-sm text-muted hover:text-fg focus-visible:outline-2 focus-visible:outline-accent"
          >
            {showSettings ? "Hide settings" : "Settings"}
          </button>
          <button
            type="button"
            onClick={startNewChat}
            disabled={messages.length === 0}
            className="min-h-11 rounded-sm border border-border px-4 text-sm text-muted hover:text-fg disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-accent"
          >
            New chat
          </button>
        </div>
      </div>

      {showSettings && (
        <div className="mt-6">
          <SettingsPanel
            settings={settings}
            models={models}
            onChange={updateSettings}
            onModelsLoaded={setModels}
            onClose={() => setShowSettings(false)}
          />
        </div>
      )}

      <div
        className={cn(
          "relative mt-6 overflow-hidden rounded-xl border bg-surface transition-colors",
          dragging ? "border-sage" : "border-border",
        )}
        onDragEnter={onDragEnter}
        onDragOver={(e) => e.preventDefault()}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
      >
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3">
          <p className="font-mono text-xs text-muted">
            {settings.model || "no model"} · {hostOf(settings.baseUrl)}
          </p>
          <p className={cn("font-mono text-xs", status.tone)}>{status.label}</p>
        </div>

        <div
          ref={scroller}
          onScroll={onScroll}
          className="h-console space-y-6 overflow-auto px-4 py-5"
        >
          {messages.length === 0 ? (
            <EmptyState hasKey={Boolean(settings.apiKey.trim())} onOpenSettings={() => setShowSettings(true)} />
          ) : (
            messages.map((message) => (
              <MessageBubble key={message.id} message={message} streaming={streaming} />
            ))
          )}
        </div>

        {dragging && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center bg-bg/85">
            <p className="rounded-md border border-sage px-4 py-3 text-sm text-sage">
              Drop files to attach
            </p>
          </div>
        )}

        <div className="border-t border-border p-3">
          {attachments.length > 0 && (
            <ul className="mb-3 flex flex-wrap gap-2">
              {attachments.map((file) => (
                <li
                  key={file.id}
                  className="flex items-center gap-2 rounded-sm border border-border bg-bg py-1.5 pl-2 pr-1"
                >
                  {file.previewUrl ? (
                    <img
                      src={file.previewUrl}
                      alt=""
                      className="size-8 rounded-xs object-cover"
                    />
                  ) : (
                    <span className="grid size-8 place-items-center rounded-xs bg-elevated font-mono text-[10px] text-muted">
                      {file.kind === "pdf" ? "PDF" : "TXT"}
                    </span>
                  )}
                  <span className="max-w-[14ch] truncate text-sm">{file.name}</span>
                  <span className="font-mono text-xs text-subtle">{formatBytes(file.size)}</span>
                  <button
                    type="button"
                    onClick={() => removeAttachment(file.id)}
                    aria-label={`Remove ${file.name}`}
                    className="grid size-8 place-items-center rounded-xs text-muted hover:text-fg"
                  >
                    ×
                  </button>
                </li>
              ))}
            </ul>
          )}

          {notice && (
            <p className="mb-3 rounded-sm border border-danger/40 bg-danger/10 px-3 py-2 text-sm text-danger">
              {notice}
            </p>
          )}

          <div className="flex items-end gap-2">
            <button
              type="button"
              onClick={() => fileInput.current?.click()}
              aria-label="Attach files"
              className="grid size-11 shrink-0 place-items-center rounded-sm border border-border text-muted hover:text-fg focus-visible:outline-2 focus-visible:outline-accent"
            >
              +
            </button>
            <input
              ref={fileInput}
              type="file"
              multiple
              hidden
              onChange={(e) => {
                if (e.target.files) void addFiles(e.target.files);
                e.target.value = "";
              }}
            />
            <textarea
              ref={textarea}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKeyDown}
              onPaste={onPaste}
              rows={1}
              placeholder="Ask something, or drop a file and describe what you need"
              className="max-h-40 min-h-11 flex-1 resize-y rounded-sm border border-border bg-bg px-3 py-2.5 text-sm text-fg outline-none ring-accent/40 placeholder:text-subtle focus:ring-2"
            />
            {streaming ? (
              <Button type="button" onClick={stop} className="h-11 shrink-0">
                Stop
              </Button>
            ) : (
              <Button
                type="button"
                onClick={() => void send()}
                disabled={!input.trim() && attachments.length === 0}
                className="h-11 shrink-0"
              >
                Send
              </Button>
            )}
          </div>
          <p className="mt-2 text-xs text-subtle">
            Enter sends · Shift+Enter adds a line · key {maskKey(settings.apiKey)}
          </p>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ hasKey, onOpenSettings }: { hasKey: boolean; onOpenSettings: () => void }) {
  if (!hasKey) {
    return (
      <div className="grid h-full place-items-center text-center">
        <div className="max-w-[46ch]">
          <p className="text-lg">Connect your provider account to start</p>
          <p className="mt-2 text-muted">
            The console uses your own API key. It stays in this browser and is sent only to the
            provider you choose.
          </p>
          <Button type="button" onClick={onOpenSettings} className="mt-5">
            Add API key
          </Button>
        </div>
      </div>
    );
  }
  return (
    <div className="grid h-full place-items-center text-center">
      <p className="max-w-[46ch] text-muted">
        Ready. Type a message, or drop an image, PDF, or source file anywhere in this panel.
      </p>
    </div>
  );
}

function MessageBubble({ message, streaming }: { message: ChatMessage; streaming: boolean }) {
  const [showThinking, setShowThinking] = useState(false);
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(message.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  }

  if (message.role === "user") {
    return (
      <div className="flex justify-end">
        <div className="max-w-[85%] rounded-md rounded-br-xs border border-border bg-elevated px-3 py-2">
          {message.attachments.length > 0 && (
            <ul className="mb-2 flex flex-wrap gap-1.5">
              {message.attachments.map((file) => (
                <li
                  key={file.id}
                  className="rounded-xs border border-border px-2 py-0.5 font-mono text-xs text-muted"
                >
                  {file.name}
                </li>
              ))}
            </ul>
          )}
          <p className="whitespace-pre-wrap text-sm">{message.text || "(files only)"}</p>
        </div>
      </div>
    );
  }

  const pending = streaming && !message.text && !message.thinking && !message.error;

  return (
    <div className="max-w-[92%]">
      {message.thinking && (
        <div className="mb-2">
          <button
            type="button"
            onClick={() => setShowThinking((v) => !v)}
            className="rounded-xs text-sm text-subtle hover:text-muted focus-visible:outline-2 focus-visible:outline-accent"
          >
            {showThinking ? "Hide reasoning" : "Show reasoning"}
          </button>
          {showThinking && (
            <p className="mt-2 whitespace-pre-wrap border-l-2 border-border pl-3 text-sm italic text-muted">
              {message.thinking}
            </p>
          )}
        </div>
      )}

      {message.error ? (
        <div className="rounded-md border border-danger/40 bg-danger/10 p-3">
          <p className="text-sm text-danger">{message.error}</p>
        </div>
      ) : pending ? (
        <p className="text-sm text-subtle">Thinking…</p>
      ) : (
        <AnswerBody text={message.text} />
      )}

      {!streaming && !message.error && message.text && (
        <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-subtle">
          <button
            type="button"
            onClick={copy}
            className="rounded-xs hover:text-muted focus-visible:outline-2 focus-visible:outline-accent"
          >
            {copied ? "Copied" : "Copy"}
          </button>
          {message.usage?.output_tokens != null && (
            <span className="font-mono">
              {message.usage.input_tokens ?? 0} in / {message.usage.output_tokens} out
            </span>
          )}
          {message.durationMs != null && (
            <span className="font-mono">{(message.durationMs / 1000).toFixed(1)}s</span>
          )}
          {message.stopReason === "cancelled" && <span>stopped</span>}
          {message.stopReason === "max_tokens" && <span>hit the response limit</span>}
        </div>
      )}
    </div>
  );
}

/** Minimal renderer: fenced code blocks become <pre>, everything else is prose. */
function AnswerBody({ text }: { text: string }) {
  const parts = useMemo(() => splitFences(text), [text]);
  return (
    <div className="space-y-3">
      {parts.map((part, index) =>
        part.type === "code" ? (
          <pre
            key={index}
            className="overflow-x-auto rounded-md border border-border bg-bg p-3 font-mono text-xs leading-relaxed text-fg"
          >
            <code>{part.text}</code>
          </pre>
        ) : (
          <p key={index} className="whitespace-pre-wrap text-sm leading-relaxed">
            {part.text}
          </p>
        ),
      )}
    </div>
  );
}

type Part = { type: "text" | "code"; text: string };

function splitFences(input: string): Part[] {
  const parts: Part[] = [];
  const pattern = /```[^\n]*\n?([\s\S]*?)(?:```|$)/g;
  let cursor = 0;
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(input)) !== null) {
    if (match.index > cursor) {
      const before = input.slice(cursor, match.index);
      if (before.trim()) parts.push({ type: "text", text: before.replace(/\n+$/, "") });
    }
    if (match[1]) parts.push({ type: "code", text: match[1].replace(/\n$/, "") });
    cursor = pattern.lastIndex;
  }

  if (cursor < input.length) {
    const rest = input.slice(cursor);
    if (rest.trim()) parts.push({ type: "text", text: rest });
  }
  return parts.length > 0 ? parts : [{ type: "text", text: input }];
}
