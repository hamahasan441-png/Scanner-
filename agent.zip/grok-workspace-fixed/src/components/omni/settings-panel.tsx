import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { clamp } from "@/lib/omni/settings";
import {
  FALLBACK_MODELS,
  maskKey,
  normalizeBaseUrl,
  type ChatSettings,
} from "@/lib/omni/types";

type TestState =
  | { status: "idle" }
  | { status: "testing" }
  | { status: "ok"; message: string }
  | { status: "error"; message: string; detail?: string };

type Props = {
  settings: ChatSettings;
  models: string[];
  onChange: (next: ChatSettings) => void;
  onModelsLoaded: (models: string[]) => void;
  onClose: () => void;
};

export function SettingsPanel({ settings, models, onChange, onModelsLoaded, onClose }: Props) {
  const [draft, setDraft] = useState<ChatSettings>(settings);
  const [revealKey, setRevealKey] = useState(false);
  const [test, setTest] = useState<TestState>({ status: "idle" });

  const modelOptions = models.length > 0 ? models : FALLBACK_MODELS;

  function patch(update: Partial<ChatSettings>) {
    setDraft((prev) => ({ ...prev, ...update }));
    setTest({ status: "idle" });
  }

  async function testConnection() {
    if (!draft.apiKey.trim()) {
      setTest({ status: "error", message: "Enter an API key first." });
      return;
    }
    setTest({ status: "testing" });
    try {
      const response = await fetch("/api/models", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ apiKey: draft.apiKey, baseUrl: draft.baseUrl }),
      });
      const payload = await response.json();
      if (!response.ok) {
        setTest({
          status: "error",
          message: payload?.error?.message || `HTTP ${response.status}`,
          detail: payload?.error?.detail,
        });
        return;
      }
      const found: string[] = Array.isArray(payload.models) ? payload.models : [];
      onModelsLoaded(found);
      if (found.length > 0 && !found.includes(draft.model)) {
        const preferred = FALLBACK_MODELS.find((id) => found.includes(id)) || found[0];
        setDraft((prev) => ({ ...prev, model: preferred }));
      }
      setTest({
        status: "ok",
        message:
          found.length > 0
            ? `Connected. ${found.length} models available.`
            : "Connected, but this provider does not list models. Type a model name below.",
      });
    } catch (error) {
      setTest({
        status: "error",
        message: "Could not reach the server.",
        detail: error instanceof Error ? error.message : String(error),
      });
    }
  }

  function save() {
    onChange({
      ...draft,
      apiKey: draft.apiKey.trim(),
      baseUrl: normalizeBaseUrl(draft.baseUrl),
      model: draft.model.trim(),
      maxTokens: clamp(draft.maxTokens, 256, 64000),
      thinkingBudget: clamp(draft.thinkingBudget, 1024, 32000),
    });
    onClose();
  }

  return (
    <div className="rounded-lg border border-border bg-surface">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <h2 className="font-sans text-base font-medium">Connection</h2>
        <button
          type="button"
          onClick={onClose}
          className="min-h-11 rounded-sm px-2 text-sm text-muted hover:text-fg focus-visible:outline-2 focus-visible:outline-accent"
        >
          Close
        </button>
      </div>

      <div className="space-y-5 p-4">
        <Field
          label="API key"
          hint={`Stored in this browser only, and sent to ${normalizeBaseUrl(draft.baseUrl)} with each message. Currently ${maskKey(settings.apiKey)}.`}
        >
          <div className="flex gap-2">
            <input
              type={revealKey ? "text" : "password"}
              value={draft.apiKey}
              onChange={(e) => patch({ apiKey: e.target.value })}
              placeholder="sk-…"
              autoComplete="off"
              spellCheck={false}
              className={inputClass}
            />
            <button
              type="button"
              onClick={() => setRevealKey((v) => !v)}
              className="min-h-11 shrink-0 rounded-sm border border-border px-3 text-sm text-muted hover:text-fg"
            >
              {revealKey ? "Hide" : "Show"}
            </button>
          </div>
        </Field>

        <Field label="Provider base URL" hint="The origin only. Paths like /v1/messages are trimmed automatically.">
          <input
            type="text"
            value={draft.baseUrl}
            onChange={(e) => patch({ baseUrl: e.target.value })}
            placeholder="https://agentrouter.org"
            autoComplete="off"
            spellCheck={false}
            className={inputClass}
          />
        </Field>

        <div className="flex flex-wrap items-center gap-3">
          <Button type="button" onClick={testConnection} disabled={test.status === "testing"}>
            {test.status === "testing" ? "Testing…" : "Test connection"}
          </Button>
          {test.status === "ok" && <p className="text-sm text-sage">{test.message}</p>}
          {test.status === "error" && (
            <div className="min-w-0 flex-1">
              <p className="text-sm text-danger">{test.message}</p>
              {test.detail && (
                <p className="mt-1 break-words font-mono text-xs text-subtle">{test.detail}</p>
              )}
            </div>
          )}
        </div>

        <Field label="Model" hint="Loaded from the provider after a successful test. You can also type one.">
          <input
            type="text"
            list="omni-models"
            value={draft.model}
            onChange={(e) => patch({ model: e.target.value })}
            placeholder="claude-sonnet-4-6"
            autoComplete="off"
            spellCheck={false}
            className={inputClass}
          />
          <datalist id="omni-models">
            {modelOptions.map((id) => (
              <option key={id} value={id} />
            ))}
          </datalist>
        </Field>

        <Field label="System prompt" hint="Sent at the start of every turn.">
          <textarea
            value={draft.systemPrompt}
            onChange={(e) => patch({ systemPrompt: e.target.value })}
            rows={3}
            className={`${inputClass} h-auto resize-y py-2 leading-relaxed`}
          />
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Response limit" hint="Maximum tokens per reply.">
            <input
              type="number"
              min={256}
              max={64000}
              step={256}
              value={draft.maxTokens}
              onChange={(e) => patch({ maxTokens: Number(e.target.value) })}
              className={inputClass}
            />
          </Field>
          <Field label="Thinking budget" hint="Tokens reserved for reasoning, when enabled.">
            <input
              type="number"
              min={1024}
              max={32000}
              step={512}
              value={draft.thinkingBudget}
              onChange={(e) => patch({ thinkingBudget: Number(e.target.value) })}
              disabled={!draft.enableThinking}
              className={`${inputClass} disabled:opacity-50`}
            />
          </Field>
        </div>

        <label className="flex items-start gap-3">
          <input
            type="checkbox"
            checked={draft.enableThinking}
            onChange={(e) => patch({ enableThinking: e.target.checked })}
            className="mt-1 size-4 accent-sage"
          />
          <span>
            <span className="block text-sm">Show extended thinking</span>
            <span className="block text-sm text-muted">
              Streams the model's reasoning above each answer. Not every model supports it.
            </span>
          </span>
        </label>

        <div className="flex flex-wrap gap-2 border-t border-border pt-4">
          <Button type="button" onClick={save}>
            Save settings
          </Button>
          <button
            type="button"
            onClick={() => patch({ apiKey: "" })}
            className="min-h-11 rounded-sm border border-border px-4 text-sm text-muted hover:text-fg"
          >
            Forget key
          </button>
        </div>
      </div>
    </div>
  );
}

const inputClass =
  "h-11 w-full min-w-0 rounded-sm border border-border bg-bg px-3 font-mono text-sm text-fg outline-none ring-accent/40 placeholder:text-subtle focus:ring-2";

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm text-fg">{label}</span>
      {children}
      {hint && <span className="mt-1.5 block text-sm text-muted">{hint}</span>}
    </label>
  );
}
