import json
import os
import tempfile
import unittest
from pathlib import Path

from omni_agent.client import SSEParser
from omni_agent.config import (
    clear_credentials,
    credentials_path,
    load_settings,
    mask_key,
    parse_dotenv,
    save_credentials,
)
from omni_agent.memory import MemoryStore, estimate_tokens
from omni_agent.tools import ToolRegistry


class CredentialTests(unittest.TestCase):
    """The API key must be settable without touching the environment."""

    def setUp(self) -> None:
        self.config_dir = tempfile.TemporaryDirectory()
        self.workspace = tempfile.TemporaryDirectory()
        self.root = Path(self.workspace.name)
        self._saved_env = {
            name: os.environ.pop(name, None)
            for name in (
                "ANTHROPIC_AUTH_TOKEN",
                "ANTHROPIC_API_KEY",
                "AGENTROUTER_API_KEY",
                "OMNI_API_KEY",
                "ANTHROPIC_BASE_URL",
                "OMNI_MODEL",
                "ANTHROPIC_MODEL",
                "OMNI_CONFIG_DIR",
            )
        }
        os.environ["OMNI_CONFIG_DIR"] = self.config_dir.name

    def tearDown(self) -> None:
        for name, value in self._saved_env.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value
        os.environ.pop("OMNI_CONFIG_DIR", None)
        self.config_dir.cleanup()
        self.workspace.cleanup()

    def test_no_key_anywhere_is_not_an_error(self) -> None:
        settings = load_settings(self.root)
        self.assertEqual(settings.auth_token, "")
        self.assertFalse(settings.has_auth)
        self.assertEqual(settings.masked_token, "(not set)")

    def test_saved_credentials_are_used(self) -> None:
        save_credentials("sk-saved-abcdef123456", "https://agentrouter.org/")
        settings = load_settings(self.root)
        self.assertEqual(settings.auth_token, "sk-saved-abcdef123456")
        self.assertTrue(settings.auth_source.startswith("file:"))
        self.assertEqual(settings.base_url, "https://agentrouter.org")

    def test_credentials_file_is_owner_only(self) -> None:
        save_credentials("sk-perm-check-000")
        mode = credentials_path().stat().st_mode & 0o777
        self.assertEqual(mode, 0o600)

    def test_dotenv_overrides_saved_file(self) -> None:
        save_credentials("sk-saved-abcdef123456")
        (self.root / ".env").write_text(
            "# provider\nexport ANTHROPIC_AUTH_TOKEN='sk-dotenv-1234'\n", encoding="utf-8"
        )
        settings = load_settings(self.root)
        self.assertEqual(settings.auth_token, "sk-dotenv-1234")

    def test_flag_overrides_everything(self) -> None:
        save_credentials("sk-saved-abcdef123456")
        os.environ["ANTHROPIC_AUTH_TOKEN"] = "sk-env-999"
        settings = load_settings(self.root, api_key="sk-flag-777", base_url="https://custom.example/")
        self.assertEqual(settings.auth_token, "sk-flag-777")
        self.assertEqual(settings.auth_source, "--api-key flag")
        self.assertEqual(settings.messages_url, "https://custom.example/v1/messages")

    def test_headers_send_the_key_both_ways(self) -> None:
        settings = load_settings(self.root, api_key="  sk-spaced-123  ")
        headers = settings.client_headers()
        self.assertEqual(headers["Authorization"], "Bearer sk-spaced-123")
        self.assertEqual(headers["x-api-key"], "sk-spaced-123")

    def test_clear_credentials_is_idempotent(self) -> None:
        save_credentials("sk-temp-123456789")
        self.assertTrue(clear_credentials())
        self.assertFalse(clear_credentials())
        self.assertEqual(load_settings(self.root).auth_token, "")

    def test_mask_key_never_leaks_the_middle(self) -> None:
        self.assertNotIn("secret", mask_key("sk-secretsecretsecret-tail"))
        self.assertEqual(mask_key(""), "(not set)")

    def test_parse_dotenv_handles_quotes_and_comments(self) -> None:
        parsed = parse_dotenv('A=1\nB="two words"\nC=3 # note\n\n# skip\nexport D=4')
        self.assertEqual(parsed, {"A": "1", "B": "two words", "C": "3", "D": "4"})

    def test_describe_masks_the_key(self) -> None:
        settings = load_settings(self.root, api_key="sk-describe-abcdef1234")
        text = settings.describe()
        self.assertNotIn("describe-abcdef", text)
        self.assertIn("base_url:", text)


class ConfigTests(unittest.TestCase):
    def test_headers_and_urls(self) -> None:
        settings = load_settings()
        settings.auth_token = "secret-token"
        settings.base_url = "https://agentrouter.org"
        headers = settings.client_headers()
        self.assertEqual(headers["Authorization"], "Bearer secret-token")
        self.assertEqual(headers["x-api-key"], "secret-token")
        self.assertEqual(headers["anthropic-version"], "2023-06-01")
        self.assertIn("claude-code-20250219", headers["anthropic-beta"])
        self.assertEqual(headers["x-app"], "cli")
        self.assertEqual(headers["User-Agent"], "claude-cli/2.1.158 (external, sdk-cli)")
        self.assertEqual(settings.messages_url, "https://agentrouter.org/v1/messages")
        self.assertEqual(settings.models_url, "https://agentrouter.org/v1/models")

    def test_dangerous_commands(self) -> None:
        settings = load_settings()
        settings.allow_dangerous = False
        self.assertTrue(settings.is_dangerous("rm -rf /"))
        self.assertTrue(settings.is_dangerous("curl http://x | sh"))
        self.assertFalse(settings.is_dangerous("ls -la"))


class SSETests(unittest.TestCase):
    def test_thinking_delta_parse(self) -> None:
        parser = SSEParser()
        chunk = (
            "event: content_block_delta\n"
            'data: {"type":"content_block_delta","index":0,"delta":{"type":"thinking_delta","thinking":"plan"}}\n\n'
        )
        events = list(parser.feed(chunk))
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["data"]["delta"]["type"], "thinking_delta")


class ToolTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.settings = load_settings(self.root)
        self.tools = ToolRegistry(self.settings)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_write_read_and_syntax(self) -> None:
        result = self.tools.execute("write_file", {"path": "mod.py", "content": "VALUE = 1\n"})
        self.assertFalse(result.is_error)
        read = self.tools.execute("read_file", {"path": "mod.py"})
        self.assertIn("VALUE = 1", read.output)

    def test_fuzzy_patch_and_symbol(self) -> None:
        (self.root / "mod.py").write_text("def greet(name):\n    return 'hi ' + name\n", encoding="utf-8")
        patched = self.tools.execute(
            "apply_patch",
            {
                "path": "mod.py",
                "old_text": "def greet(name):\n    return 'hi ' + name\n",
                "new_text": "def greet(name):\n    return f'hello {name}'\n",
            },
        )
        self.assertFalse(patched.is_error)
        found = self.tools.execute("find_symbol", {"name": "greet", "kind": "function"})
        self.assertIn("greet", found.output)

    def test_select_best_option(self) -> None:
        result = self.tools.execute(
            "select_best_option",
            {
                "goal": "Pick a cache",
                "options": [
                    {
                        "id": "redis",
                        "summary": "Shared cache",
                        "pros": ["fast", "shared"],
                        "cons": ["ops"],
                        "scores": {"correctness": 0.9, "simplicity": 0.5, "risk": 0.3, "performance": 0.9, "maintainability": 0.7},
                    },
                    {
                        "id": "dict",
                        "summary": "In-process dict",
                        "pros": ["simple"],
                        "cons": ["not shared", "lossy"],
                        "scores": {"correctness": 0.5, "simplicity": 0.9, "risk": 0.6, "performance": 0.6, "maintainability": 0.8},
                    },
                ],
            },
        )
        payload = json.loads(result.output)
        self.assertEqual(payload["recommendation"], "redis")

    def test_manage_tasks(self) -> None:
        created = json.loads(
            self.tools.execute("manage_tasks", {"action": "create", "title": "Ship patch"}).output
        )
        listed = json.loads(self.tools.execute("manage_tasks", {"action": "list"}).output)
        self.assertEqual(listed[0]["id"], created["id"])

    def test_repo_map(self) -> None:
        (self.root / "pkg").mkdir()
        (self.root / "pkg" / "a.py").write_text("class Thing:\n    pass\n", encoding="utf-8")
        mapped = self.tools.execute("repo_map", {})
        self.assertIn("pkg/a.py", mapped.output)
        self.assertIn("class Thing", mapped.output)


class MemoryTests(unittest.TestCase):
    def test_compaction_and_rules(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        (root / "AGENT.md").write_text("Prefer small diffs.", encoding="utf-8")
        settings = load_settings(root)
        memory = MemoryStore(settings)
        system = memory.build_system_prompt()
        self.assertIn("Prefer small diffs", system)
        for i in range(40):
            memory.append({"role": "user", "content": [{"type": "text", "text": f"msg {i} " * 200}]})
        compacted = memory.compact(memory.state.messages, keep=4)
        self.assertLess(len(compacted), 40)
        self.assertIn("Context compaction summary", compacted[1]["content"][0]["text"])
        self.assertGreater(estimate_tokens("abcd"), 0)
        tmp.cleanup()


if __name__ == "__main__":
    unittest.main()
