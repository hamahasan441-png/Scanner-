# Omni Agent

An autonomous software engineering agent that runs against your own provider
account, plus a web control plane for browsing it and chatting with it.

- **`omni_agent/`** — the Python package. Tool-use loop, SSE streaming,
  checkpoints, self-healing test runner. See
  [`omni_agent/README.md`](omni_agent/README.md).
- **`src/`** — the OMNI control plane: architecture map, tool registry, source
  browser, and a live chat console.

## Your API key

Nothing calls the network until you supply a key. It is yours, it stays on your
machine or in your browser, and it is sent only to the provider you name.

**CLI**

```bash
pip install -e .
omni-agent --login          # prompts, verifies against /v1/models, then saves
omni-agent "explain src/"
```

`--login` writes `~/.omni_agent/credentials.json` with mode `0600`. Other ways
in, highest priority first: `--api-key`, then `ANTHROPIC_AUTH_TOKEN` (or
`ANTHROPIC_API_KEY` / `AGENTROUTER_API_KEY` / `OMNI_API_KEY`), then `.env`, then
the saved file. `omni-agent --show-config` shows which one won, masked;
`omni-agent --logout` deletes it.

Copy `omni_agent.env.example` to `.env` for the file route.

**Web console**

```bash
npm install
npm run dev     # http://localhost:8080/console
```

Open Settings, paste your key, pick a provider base URL, and press *Test
connection* — it lists the models your key can reach before you send anything.
The key is stored in that browser's local storage and relayed through
`/api/chat` only because providers do not send CORS headers; the server keeps
no copy.

Drag images, PDFs, or source files anywhere onto the console to attach them.
Paste screenshots directly. Enter sends, Shift+Enter adds a line.

## Tests

```bash
python -m unittest discover -s tests   # agent framework
npm test                               # console, scripts, auth helpers
npm run typecheck
```

## A note on request headers

`omni_agent/config.py` identifies itself to the provider as the Claude Code CLI:

```
User-Agent: claude-cli/2.1.158 (external, sdk-cli)
x-app: cli
anthropic-beta: claude-code-20250219,interleaved-thinking-2025-05-14
```

The web console does not do this — it sends only `authorization`, `x-api-key`
and `anthropic-version`, which any Anthropic-compatible provider accepts. If you
do not need the CLI identity, drop `DEFAULT_USER_AGENT` and `DEFAULT_APP_HEADER`
from `client_headers()` and the agent will keep working.
