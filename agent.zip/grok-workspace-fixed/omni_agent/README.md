# Omni Agent

Production-grade autonomous software engineering agent (`omni_agent`).

The framework talks to the AgentRouter Anthropic-compatible proxy with live SSE streaming, extended thinking (`thinking_delta`), model auto-discovery, and auto-continuation on `max_tokens`.

## Package layout

| Module | Responsibility |
| --- | --- |
| `config.py` | Environment, endpoints, token budgets, dangerous-command patterns |
| `client.py` | Resilient HTTP + SSE, retries, thinking blocks, `/v1/models` |
| `tools.py` | Tool registry: bash, files, fuzzy patch, AST search, repo map, fetch, daemons, tasks, trade-offs |
| `memory.py` | Compaction, session JSON, base64 images, `CLAUDE.md` / `AGENT.md` injection |
| `diagnostics.py` | `git stash create` checkpoints and `/undo` rollback |
| `test_runner.py` | Detect tests, capture logs, iterate patches until green |
| `agent.py` | Tool-use loop with compaction and continuation |
| `cli.py` | REPL, history, slash commands |

## Protocol

- Base URL: `ANTHROPIC_BASE_URL` or `https://agentrouter.org`
- Messages: `/v1/messages`
- Models: `/v1/models`
- Headers: `Authorization`, `x-api-key`, `anthropic-version: 2023-06-01`, `anthropic-beta: claude-code-20250219,interleaved-thinking-2025-05-14`, `x-app: cli`, `User-Agent: claude-cli/2.1.158 (external, sdk-cli)`

## Setting your API key

The agent will not make a network call without one. Any of these work, and the
first match wins:

```bash
omni-agent --login                  # prompts, verifies, saves to ~/.omni_agent/credentials.json
omni-agent --api-key sk-... "task"  # one run only, never written to disk
export ANTHROPIC_AUTH_TOKEN=sk-...  # or ANTHROPIC_API_KEY / AGENTROUTER_API_KEY / OMNI_API_KEY
echo 'ANTHROPIC_AUTH_TOKEN=sk-...' >> .env
```

Resolution order, highest priority first:

1. `--api-key`
2. `ANTHROPIC_AUTH_TOKEN`, `ANTHROPIC_API_KEY`, `AGENTROUTER_API_KEY`, `OMNI_API_KEY`
3. `.env` in the workspace, then `~/.omni_agent/.env`
4. `~/.omni_agent/credentials.json`, written by `--login` with mode `0600`

Check what resolved without revealing the key:

```bash
omni-agent --show-config
omni-agent --logout      # delete the saved key
```

`--login` verifies the key against `/v1/models` before saving, so a typo fails
immediately instead of on your first message.

## Environment

| Variable | Purpose |
| --- | --- |
| `ANTHROPIC_AUTH_TOKEN` | API key. `ANTHROPIC_API_KEY`, `AGENTROUTER_API_KEY` and `OMNI_API_KEY` also work |
| `ANTHROPIC_BASE_URL` | Provider origin, no path. Also `AGENTROUTER_BASE_URL`, `OMNI_BASE_URL` |
| `OMNI_MODEL` | Preferred model id |
| `OMNI_MAX_TOKENS` | Completion budget |
| `OMNI_THINKING_BUDGET` | Extended thinking budget |
| `OMNI_ALLOW_DANGEROUS` | Permit blocked shell patterns |
| `OMNI_SESSION_DIR` | Persistence directory |
| `OMNI_CONFIG_DIR` | Where the saved key lives (default `~/.omni_agent`) |

## Slash commands

`/test` `/plan` `/image` `/commit` `/undo` `/diff` `/stats` `/clear` `/model` `/help` `/exit`

Credentials: `/login` `/logout` `/key` `/baseurl` `/config`

## Tools

`bash` `read_file` `write_file` `apply_patch` `syntax_check` `find_symbol` `repo_map` `fetch_url` `daemon_control` `manage_tasks` `select_best_option` `glob_search` `grep_search`

`apply_patch` uses exact then difflib fuzzy matching. `syntax_check` runs `py_compile` or `node --check`. `find_symbol` walks Python ASTs. `select_best_option` ranks weighted trade-offs.
