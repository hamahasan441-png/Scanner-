"""Interactive REPL with command history and slash-command routing."""

from __future__ import annotations

import argparse
import getpass
import logging
import os
import shlex
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

from .agent import OmniAgent, TurnResult
from .config import (
    DEFAULT_BASE_URL,
    Settings,
    clear_credentials,
    credentials_path,
    load_settings,
    save_credentials,
)
from .diagnostics import Diagnostics
from .memory import MemoryStore, estimate_messages_tokens
from .test_runner import TestRunner

try:
    import readline  # noqa: F401
except ImportError:  # pragma: no cover - Windows
    readline = None  # type: ignore[assignment]


logger = logging.getLogger("omni_agent.cli")

SLASH_COMMANDS = {
    "/help": "Show available slash commands",
    "/test": "Run the autonomous self-healing test runner",
    "/plan": "Ask the agent for an implementation plan without editing",
    "/image": "Attach an image to the next prompt: /image path/to/file.png prompt...",
    "/commit": "Create a git commit from the current diff",
    "/undo": "Roll back to the last checkpoint",
    "/diff": "Show the working tree diff",
    "/stats": "Print session statistics",
    "/clear": "Clear conversation memory",
    "/model": "Show or set the active model: /model [name]",
    "/login": "Enter and save your API key: /login [key]",
    "/logout": "Delete the saved API key",
    "/key": "Show the active API key (masked) and where it came from",
    "/baseurl": "Show or set the provider origin: /baseurl [url]",
    "/config": "Print the resolved connection settings",
    "/exit": "Leave the REPL",
}

PROMPT_LOGIN_HELP = (
    "Paste your API key for the provider below. Input is hidden.\n"
    "Leave it blank to cancel."
)


class OmniREPL:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self.settings.ensure_session_dir()
        self._configure_logging()
        self.memory = MemoryStore(self.settings)
        self.diagnostics = Diagnostics(self.settings)
        self.agent = OmniAgent(
            settings=self.settings,
            memory=self.memory,
            diagnostics=self.diagnostics,
            on_event=self._on_event,
        )
        self.tests = TestRunner(
            settings=self.settings,
            tools=self.agent.tools,
            diagnostics=self.diagnostics,
            fixer=self._heal_fixer,
        )
        self._setup_history()

    def _configure_logging(self) -> None:
        logging.basicConfig(
            level=os.getenv("OMNI_LOG_LEVEL", "INFO"),
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        )

    def _setup_history(self) -> None:
        if readline is None:
            return
        history = str(self.settings.history_path)
        try:
            readline.read_history_file(history)
        except FileNotFoundError:
            pass
        readline.set_history_length(1000)
        self._history_path = history

    def _save_history(self) -> None:
        if readline is None:
            return
        try:
            readline.write_history_file(getattr(self, "_history_path", str(self.settings.history_path)))
        except OSError:
            pass

    def _on_event(self, kind: str, payload: Dict[str, Any]) -> None:
        if kind == "thinking_delta":
            sys.stdout.write("")
            sys.stdout.flush()
        elif kind == "content_block_delta":
            delta = payload.get("delta") or {}
            if delta.get("type") == "text_delta":
                sys.stdout.write(str(delta.get("text") or ""))
                sys.stdout.flush()
        elif kind == "tool_round":
            print(f"\n[tools] round {payload.get('round')} ({payload.get('count')} calls)")
        elif kind == "tool_result":
            name = payload.get("tool_use_id")
            flag = "error" if payload.get("is_error") else "ok"
            preview = str(payload.get("content") or "").splitlines()[:1]
            print(f"[tool {flag}] {name} {preview[0][:120] if preview else ''}")

    def ensure_auth(self, interactive: bool = True) -> bool:
        """Make sure an API key is present, prompting for one when possible."""
        if self.settings.has_auth:
            return True
        if not interactive or not sys.stdin.isatty():
            print(
                "No API key configured. Set one with `omni-agent --login`, "
                "`--api-key <KEY>`, ANTHROPIC_AUTH_TOKEN, or a .env file."
            )
            return False
        print("\nNo API key found for this agent.")
        print(PROMPT_LOGIN_HELP)
        return self._prompt_and_store_key()

    def _prompt_and_store_key(self, key: str | None = None) -> bool:
        try:
            entered = (key or getpass.getpass("API key: ")).strip()
        except (EOFError, KeyboardInterrupt):
            print("\nCancelled.")
            return False
        if not entered:
            print("No key entered; skipping.")
            return False

        base_url = self.settings.base_url
        try:
            typed = input(f"Provider base URL [{base_url}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            typed = ""
        if typed:
            base_url = typed

        self.agent.client.set_auth(entered, base_url, source="interactive login")
        print("Verifying key...")
        ok, detail = self.agent.client.check_auth()
        print(("OK: " if ok else "Failed: ") + detail)
        if not ok:
            print("The key was not saved. Fix it and run /login again.")
            return False

        try:
            answer = input(f"Save this key to {credentials_path()}? [Y/n]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "y"
        if answer in {"", "y", "yes"}:
            try:
                path = save_credentials(entered, base_url)
                print(f"Saved to {path} (permissions 0600).")
            except (OSError, ValueError) as exc:
                print(f"Could not save the key: {exc}. It stays active for this session only.")
        else:
            print("Not saved; the key is active for this session only.")
        return True

    def run_forever(self) -> int:
        print("Omni Agent REPL. Type /help for commands, /exit to quit.")
        self.ensure_auth()
        try:
            while True:
                try:
                    raw = input("omni> ").strip()
                except EOFError:
                    print()
                    break
                if not raw:
                    continue
                if raw.startswith("/"):
                    if self._dispatch_slash(raw):
                        break
                    continue
                self._chat(raw)
        finally:
            self._save_history()
        return 0

    def _dispatch_slash(self, raw: str) -> bool:
        parts = shlex.split(raw)
        command = parts[0]
        args = parts[1:]
        if command in {"/exit", "/quit"}:
            return True
        handlers = {
            "/help": self._cmd_help,
            "/test": self._cmd_test,
            "/plan": self._cmd_plan,
            "/image": self._cmd_image,
            "/commit": self._cmd_commit,
            "/undo": self._cmd_undo,
            "/diff": self._cmd_diff,
            "/stats": self._cmd_stats,
            "/clear": self._cmd_clear,
            "/model": self._cmd_model,
            "/login": self._cmd_login,
            "/logout": self._cmd_logout,
            "/key": self._cmd_key,
            "/baseurl": self._cmd_baseurl,
            "/config": self._cmd_config,
        }
        handler = handlers.get(command)
        if handler is None:
            print(f"Unknown command {command}. Try /help")
            return False
        try:
            handler(args)
        except Exception as exc:  # noqa: BLE001
            print(f"Command failed: {exc}")
            logger.debug(traceback.format_exc())
        return False

    def _cmd_help(self, _args: List[str]) -> None:
        width = max(len(k) for k in SLASH_COMMANDS)
        for name, desc in SLASH_COMMANDS.items():
            print(f"{name.ljust(width)}  {desc}")

    def _cmd_test(self, args: List[str]) -> None:
        command = args or None
        print("Running self-healing test loop...")
        report = self.tests.heal(command=command, max_attempts=5)
        print(report.log_text())
        print("PASS" if report.passed else "FAIL")

    def _heal_fixer(self, log_text: str, report: Any) -> Optional[str]:
        prompt = (
            "The test suite failed. Inspect the log, edit the repository with tools, "
            "and stop when you believe tests will pass. Do not explain at length.\n\n"
            f"{log_text}"
        )
        result = self.agent.run(prompt, snapshot=False)
        return result.text or "attempted-fix"

    def _cmd_plan(self, args: List[str]) -> None:
        prompt = " ".join(args) or "Plan the next implementation steps for this repository."
        result = self.agent.plan(prompt)
        self._print_result(result)

    def _cmd_image(self, args: List[str]) -> None:
        if not args:
            print("Usage: /image path/to/file.png [prompt]")
            return
        image = args[0]
        prompt = " ".join(args[1:]) or "Describe this image and apply any implied engineering task."
        result = self.agent.run(prompt, images=[image])
        self._print_result(result)

    def _cmd_commit(self, args: List[str]) -> None:
        message = " ".join(args) or "chore: omni agent checkpoint"
        diff = self.diagnostics.diff()
        print(diff)
        self.agent.tools.execute("bash", {"command": "git add -A"})
        quoted = message.replace('"', '\\"')
        result = self.agent.tools.execute("bash", {"command": f'git commit -m "{quoted}"'})
        print(result.output)

    def _cmd_undo(self, args: List[str]) -> None:
        ident = args[0] if args else None
        checkpoint = self.diagnostics.undo(ident)
        print(f"Restored checkpoint {checkpoint.id} ({checkpoint.method})")

    def _cmd_diff(self, _args: List[str]) -> None:
        print(self.diagnostics.diff())

    def _cmd_stats(self, _args: List[str]) -> None:
        tokens = estimate_messages_tokens(self.memory.state.messages)
        print(f"model: {self.memory.state.model or self.agent.client.resolve_model()}")
        print(f"messages: {len(self.memory.state.messages)}")
        print(f"estimated_tokens: {tokens}")
        print(f"turns: {self.agent.stats['turns']}")
        print(f"tool_calls: {self.agent.stats['tool_calls']}")
        print(f"errors: {self.agent.stats['errors']}")
        print(f"input_tokens: {self.agent.stats['input_tokens']}")
        print(f"output_tokens: {self.agent.stats['output_tokens']}")
        print(f"checkpoints: {len(self.diagnostics.history())}")

    def _cmd_clear(self, _args: List[str]) -> None:
        self.memory.clear()
        print("Session memory cleared")

    def _cmd_model(self, args: List[str]) -> None:
        if not args:
            try:
                models = self.agent.client.discover_models()
            except Exception as exc:  # noqa: BLE001
                print(f"Could not list models: {exc}")
                models = []
            current = self.memory.state.model or self.settings.model or "(auto)"
            print(f"current: {current}")
            for item in models[:40]:
                ident = item.get("id") if isinstance(item, dict) else item
                print(f"- {ident}")
            return
        resolved = self.agent.set_model(args[0])
        print(f"model set to {resolved}")

    def _cmd_login(self, args: List[str]) -> None:
        self._prompt_and_store_key(args[0] if args else None)

    def _cmd_logout(self, _args: List[str]) -> None:
        removed = clear_credentials()
        self.agent.client.set_auth("", source="")
        if removed:
            print(f"Deleted {credentials_path()}. The session is now unauthenticated.")
        else:
            print("No saved credentials file to delete.")
        env_names = [n for n in ("ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_API_KEY", "AGENTROUTER_API_KEY", "OMNI_API_KEY") if os.getenv(n)]
        if env_names:
            print(f"Note: {', '.join(env_names)} is still set in the environment and will be used on restart.")

    def _cmd_key(self, _args: List[str]) -> None:
        print(f"api_key:    {self.settings.masked_token}")
        print(f"key_source: {self.settings.auth_source or '(none)'}")
        if self.settings.has_auth:
            ok, detail = self.agent.client.check_auth()
            print(("status:     ok — " if ok else "status:     failed — ") + detail)

    def _cmd_baseurl(self, args: List[str]) -> None:
        if not args:
            print(f"base_url: {self.settings.base_url}")
            print(f"messages: {self.settings.messages_url}")
            return
        self.agent.client.set_auth(self.settings.auth_token, args[0], source=self.settings.auth_source)
        print(f"base_url set to {self.settings.base_url}")
        ok, detail = self.agent.client.check_auth()
        print(("ok — " if ok else "failed — ") + detail)

    def _cmd_config(self, _args: List[str]) -> None:
        print(self.settings.describe())

    def _chat(self, prompt: str) -> None:
        try:
            result = self.agent.run(prompt)
            self._print_result(result)
        except Exception as exc:  # noqa: BLE001
            print(f"\nAgent error: {exc}")
            logger.debug(traceback.format_exc())

    def _print_result(self, result: TurnResult) -> None:
        if result.text and not result.text.endswith("\n"):
            print()
        if result.thinking:
            print(f"\n[thinking {len(result.thinking)} chars]")
        print(f"[stop={result.stop_reason} tools={result.tool_rounds} {result.duration_ms}ms]")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="omni_agent",
        description="Omni autonomous engineering agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "API key resolution order (first match wins):\n"
            "  1. --api-key\n"
            "  2. ANTHROPIC_AUTH_TOKEN / ANTHROPIC_API_KEY / AGENTROUTER_API_KEY / OMNI_API_KEY\n"
            "  3. .env in the workspace, then ~/.omni_agent/.env\n"
            "  4. ~/.omni_agent/credentials.json (written by --login)\n"
        ),
    )
    parser.add_argument("prompt", nargs="*", help="Optional one-shot prompt")
    parser.add_argument("--workspace", default=None, help="Workspace root")
    parser.add_argument("--model", default=None, help="Model id override")
    parser.add_argument("--repl", action="store_true", help="Force interactive REPL")
    parser.add_argument("--api-key", default=None, help="API key for this run (not saved)")
    parser.add_argument(
        "--base-url",
        default=None,
        help=f"Provider origin, e.g. {DEFAULT_BASE_URL} (no endpoint path)",
    )
    parser.add_argument(
        "--login",
        action="store_true",
        help="Prompt for an API key, verify it, and save it to ~/.omni_agent/credentials.json",
    )
    parser.add_argument("--logout", action="store_true", help="Delete the saved API key and exit")
    parser.add_argument(
        "--show-config",
        action="store_true",
        help="Print the resolved connection settings (key is masked) and exit",
    )
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.logout:
        removed = clear_credentials()
        print(f"Deleted {credentials_path()}" if removed else "No saved credentials file to delete.")
        return 0

    settings = load_settings(args.workspace, api_key=args.api_key, base_url=args.base_url)

    if args.show_config:
        print(settings.describe())
        return 0

    repl = OmniREPL(settings)

    if args.login:
        return 0 if repl._prompt_and_store_key() else 1

    if args.model:
        repl.agent.set_model(args.model)

    if args.prompt and not args.repl:
        if not repl.ensure_auth(interactive=sys.stdin.isatty()):
            return 2
        result = repl.agent.run(" ".join(args.prompt))
        if result.text:
            print(result.text)
        return 0
    return repl.run_forever()
