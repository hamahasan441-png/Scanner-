"""Environment configuration, API endpoints, token constraints, and safety patterns."""

from __future__ import annotations

import json
import os
import re
import stat
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Pattern, Sequence


DEFAULT_BASE_URL = "https://agentrouter.org"
DEFAULT_ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_ANTHROPIC_BETA = "claude-code-20250219,interleaved-thinking-2025-05-14"
DEFAULT_USER_AGENT = "claude-cli/2.1.158 (external, sdk-cli)"
DEFAULT_APP_HEADER = "cli"

DEFAULT_MODEL_CANDIDATES: Sequence[str] = (
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "claude-opus-4-5",
    "claude-sonnet-4-5",
    "claude-opus-4-1",
    "claude-sonnet-4",
    "claude-3-7-sonnet-latest",
    "claude-3-5-sonnet-latest",
)

DEFAULT_MAX_TOKENS = 16_384
DEFAULT_THINKING_BUDGET = 10_240
DEFAULT_COMPACTION_THRESHOLD = 96_000
DEFAULT_COMPACTION_KEEP = 24
DEFAULT_REQUEST_TIMEOUT = 300.0
DEFAULT_CONNECT_TIMEOUT = 20.0
DEFAULT_MAX_RETRIES = 6
DEFAULT_RETRY_BASE_SECONDS = 1.25
DEFAULT_RETRY_MAX_SECONDS = 32.0
DEFAULT_STREAM_IDLE_TIMEOUT = 90.0
DEFAULT_MAX_CONTINUATIONS = 8
DEFAULT_MAX_TOOL_ROUNDS = 80
DEFAULT_TOOL_TIMEOUT = 120.0
DEFAULT_MAX_TOOL_OUTPUT_CHARS = 80_000
DEFAULT_SESSION_DIRNAME = ".omni_agent"
DEFAULT_HISTORY_FILE = "history"
DEFAULT_SESSION_FILE = "session.json"
DEFAULT_TASKS_FILE = "tasks.json"
DEFAULT_DAEMONS_FILE = "daemons.json"
DEFAULT_CHECKPOINTS_FILE = "checkpoints.json"

DEFAULT_CONFIG_DIRNAME = ".omni_agent"
DEFAULT_CREDENTIALS_FILE = "credentials.json"
DEFAULT_DOTENV_FILE = ".env"

# Checked in order. The first non-empty value wins.
API_KEY_ENV_VARS: Sequence[str] = (
    "ANTHROPIC_AUTH_TOKEN",
    "ANTHROPIC_API_KEY",
    "AGENTROUTER_API_KEY",
    "OMNI_API_KEY",
)
BASE_URL_ENV_VARS: Sequence[str] = (
    "ANTHROPIC_BASE_URL",
    "AGENTROUTER_BASE_URL",
    "OMNI_BASE_URL",
)

RETRYABLE_STATUS_CODES = frozenset({408, 409, 425, 429, 500, 502, 503, 504, 529})
AUTH_STATUS_CODES = frozenset({401, 403})

DANGEROUS_COMMAND_PATTERNS: Sequence[str] = (
    r"\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+)*(/\s*($|\s)|/\*|~|/home|/Users|/var|/usr|/etc|/boot)",
    r"\bmkfs(\.\w+)?\b",
    r"\bdd\s+if=",
    r":\(\)\s*\{\s*:\s*\|\s*:\s*&\s*;\s*\}",
    r"\bchmod\s+-R\s+777\s+/",
    r"\bchown\s+-R\s+[^\n]+?\s+/\s*$",
    r"\b(shutdown|reboot|halt|poweroff)\b",
    r"\b(mkfs|fdisk|parted|diskpart)\b",
    r">\s*/dev/sd[a-z]",
    r"\bcurl\b[^\n]*\|\s*(ba)?sh\b",
    r"\bwget\b[^\n]*\|\s*(ba)?sh\b",
    r"\bgit\s+push\b[^\n]*--force[^\n]*\b(main|master)\b",
    r"\bgit\s+reset\s+--hard\b",
    r"\bDROP\s+(DATABASE|SCHEMA|TABLE)\b",
    r"\bTRUNCATE\s+TABLE\b",
    r"\bsudo\s+rm\b",
    r"\bkill\s+-9\s+1\b",
    r"\biptables\s+-F\b",
    r"\bfork\s*\(\s*\)\s*while",
    r"\bnc\s+-l\b[^\n]*-e\b",
    r"\bpython\s+-c\s+['\"]import\s+socket[^\n]*subprocess",
)

COMPILED_DANGEROUS_PATTERNS: List[Pattern[str]] = [
    re.compile(p, re.IGNORECASE | re.MULTILINE) for p in DANGEROUS_COMMAND_PATTERNS
]

PROJECT_RULE_FILENAMES: Sequence[str] = (
    "CLAUDE.md",
    "AGENT.md",
    "AGENTS.md",
    "OMNI.md",
    ".omni_agent/rules.md",
)


def config_home() -> Path:
    """Directory that stores the saved API key. Override with OMNI_CONFIG_DIR."""
    override = os.getenv("OMNI_CONFIG_DIR")
    if override and override.strip():
        return Path(override).expanduser()
    return Path.home() / DEFAULT_CONFIG_DIRNAME


def credentials_path() -> Path:
    return config_home() / DEFAULT_CREDENTIALS_FILE


def read_credentials() -> Dict[str, str]:
    """Read the saved credentials file. Returns {} when absent or unreadable."""
    path = credentials_path()
    try:
        raw = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return {}
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(payload, dict):
        return {}
    return {str(k): str(v) for k, v in payload.items() if v not in (None, "")}


def save_credentials(api_key: str, base_url: str | None = None, model: str | None = None) -> Path:
    """Persist the API key (and optional base URL / model) with 0600 permissions."""
    key = (api_key or "").strip()
    if not key:
        raise ValueError("api_key must not be empty")
    payload = read_credentials()
    payload["api_key"] = key
    if base_url:
        payload["base_url"] = base_url.strip().rstrip("/")
    if model:
        payload["model"] = model.strip()
    path = credentials_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    try:
        os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:  # pragma: no cover - platforms without POSIX permissions
        pass
    tmp.replace(path)
    return path


def clear_credentials() -> bool:
    """Delete the saved credentials file. Returns True when something was removed."""
    path = credentials_path()
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False
    except OSError:
        return False


def parse_dotenv(text: str) -> Dict[str, str]:
    """Parse a minimal .env document (KEY=value, optional `export`, # comments)."""
    values: Dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("export "):
            stripped = stripped[7:].lstrip()
        if "=" not in stripped:
            continue
        name, _, value = stripped.partition("=")
        name = name.strip()
        if not name:
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        else:
            value = value.split(" #", 1)[0].strip()
        values[name] = value
    return values


def load_dotenv_files(workspace: Path) -> Dict[str, str]:
    """Load .env from the workspace and the config home without clobbering real env vars."""
    loaded: Dict[str, str] = {}
    candidates = [workspace / DEFAULT_DOTENV_FILE, config_home() / DEFAULT_DOTENV_FILE]
    seen: set[Path] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            continue
        if resolved in seen or not resolved.is_file():
            continue
        seen.add(resolved)
        try:
            text = resolved.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for name, value in parse_dotenv(text).items():
            loaded.setdefault(name, value)
            # Real environment variables always win over .env files.
            os.environ.setdefault(name, value)
    return loaded


def mask_key(key: str) -> str:
    """Render an API key safe for logs and terminal output."""
    key = (key or "").strip()
    if not key:
        return "(not set)"
    if len(key) <= 10:
        return f"{key[:2]}{'*' * max(len(key) - 2, 1)}"
    return f"{key[:6]}...{key[-4:]} ({len(key)} chars)"


def _first_env(names: Sequence[str]) -> tuple[str, str]:
    for name in names:
        raw = os.getenv(name)
        if raw and raw.strip():
            return raw.strip(), name
    return "", ""


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return float(raw)
    except ValueError:
        return default


@dataclass
class Settings:
    """Runtime configuration resolved from the process environment."""

    auth_token: str = ""
    base_url: str = DEFAULT_BASE_URL
    model: str = ""
    max_tokens: int = DEFAULT_MAX_TOKENS
    thinking_budget: int = DEFAULT_THINKING_BUDGET
    enable_thinking: bool = True
    compaction_threshold: int = DEFAULT_COMPACTION_THRESHOLD
    compaction_keep: int = DEFAULT_COMPACTION_KEEP
    request_timeout: float = DEFAULT_REQUEST_TIMEOUT
    connect_timeout: float = DEFAULT_CONNECT_TIMEOUT
    max_retries: int = DEFAULT_MAX_RETRIES
    retry_base_seconds: float = DEFAULT_RETRY_BASE_SECONDS
    retry_max_seconds: float = DEFAULT_RETRY_MAX_SECONDS
    stream_idle_timeout: float = DEFAULT_STREAM_IDLE_TIMEOUT
    max_continuations: int = DEFAULT_MAX_CONTINUATIONS
    max_tool_rounds: int = DEFAULT_MAX_TOOL_ROUNDS
    tool_timeout: float = DEFAULT_TOOL_TIMEOUT
    max_tool_output_chars: int = DEFAULT_MAX_TOOL_OUTPUT_CHARS
    workspace: Path = field(default_factory=lambda: Path.cwd())
    session_dir: Path = field(default_factory=lambda: Path.cwd() / DEFAULT_SESSION_DIRNAME)
    allow_dangerous: bool = False
    extra_headers: Dict[str, str] = field(default_factory=dict)
    auth_source: str = ""

    @property
    def has_auth(self) -> bool:
        return bool(self.auth_token.strip())

    @property
    def masked_token(self) -> str:
        return mask_key(self.auth_token)

    def describe(self) -> str:
        """Human-readable, secret-safe summary of the active connection settings."""
        source = self.auth_source or ("none" if not self.has_auth else "unknown")
        return "\n".join(
            [
                f"base_url:    {self.base_url}",
                f"messages:    {self.messages_url}",
                f"api_key:     {self.masked_token}",
                f"key_source:  {source}",
                f"model:       {self.model or '(auto-detect)'}",
                f"max_tokens:  {self.max_tokens}",
                f"thinking:    {'on' if self.enable_thinking else 'off'} (budget {self.thinking_budget})",
                f"workspace:   {self.workspace}",
                f"credentials: {credentials_path()}",
            ]
        )

    def set_auth(self, api_key: str, base_url: str | None = None, source: str = "runtime") -> None:
        """Update the credentials in place; the HTTP client rebuilds headers per request."""
        self.auth_token = (api_key or "").strip()
        self.auth_source = source if self.auth_token else ""
        if base_url and base_url.strip():
            self.base_url = base_url.strip().rstrip("/")

    @property
    def messages_url(self) -> str:
        return f"{self.base_url.rstrip('/')}/v1/messages"

    @property
    def models_url(self) -> str:
        return f"{self.base_url.rstrip('/')}/v1/models"

    @property
    def history_path(self) -> Path:
        return self.session_dir / DEFAULT_HISTORY_FILE

    @property
    def session_path(self) -> Path:
        return self.session_dir / DEFAULT_SESSION_FILE

    @property
    def tasks_path(self) -> Path:
        return self.session_dir / DEFAULT_TASKS_FILE

    @property
    def daemons_path(self) -> Path:
        return self.session_dir / DEFAULT_DAEMONS_FILE

    @property
    def checkpoints_path(self) -> Path:
        return self.session_dir / DEFAULT_CHECKPOINTS_FILE

    def client_headers(self) -> Dict[str, str]:
        token = (self.auth_token or "").strip()
        headers = {
            "Authorization": f"Bearer {token}",
            "x-api-key": token,
            "anthropic-version": DEFAULT_ANTHROPIC_VERSION,
            "anthropic-beta": DEFAULT_ANTHROPIC_BETA,
            "x-app": DEFAULT_APP_HEADER,
            "User-Agent": DEFAULT_USER_AGENT,
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        headers.update(self.extra_headers)
        return headers

    def ensure_session_dir(self) -> Path:
        self.session_dir.mkdir(parents=True, exist_ok=True)
        return self.session_dir

    def is_dangerous(self, command: str) -> bool:
        if self.allow_dangerous:
            return False
        return any(p.search(command) for p in COMPILED_DANGEROUS_PATTERNS)


def resolve_credentials(
    workspace: Path,
    api_key: str | None = None,
    base_url: str | None = None,
) -> tuple[str, str, str, str]:
    """Resolve (api_key, base_url, model, source) from every supported location.

    Priority, highest first:
      1. explicit argument (``--api-key`` / ``--base-url``)
      2. environment variables
      3. ``.env`` in the workspace, then in ``~/.omni_agent``
      4. the saved credentials file (``omni-agent --login``)
    """
    load_dotenv_files(workspace)  # populates os.environ without overriding real vars
    stored = read_credentials()

    if api_key and api_key.strip():
        token, source = api_key.strip(), "--api-key flag"
    else:
        token, env_name = _first_env(API_KEY_ENV_VARS)
        if token:
            source = f"env:{env_name}"
        elif stored.get("api_key"):
            token, source = stored["api_key"].strip(), f"file:{credentials_path()}"
        else:
            token, source = "", ""

    if base_url and base_url.strip():
        resolved_base = base_url.strip()
    else:
        env_base, _ = _first_env(BASE_URL_ENV_VARS)
        resolved_base = env_base or stored.get("base_url", "") or DEFAULT_BASE_URL

    model = (
        os.getenv("OMNI_MODEL", "").strip()
        or os.getenv("ANTHROPIC_MODEL", "").strip()
        or stored.get("model", "").strip()
    )
    return token, resolved_base.rstrip("/") or DEFAULT_BASE_URL, model, source


def load_settings(
    workspace: str | Path | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
) -> Settings:
    """Load settings from CLI overrides, environment, .env files and saved credentials."""
    root = Path(workspace).resolve() if workspace else Path.cwd().resolve()
    token, resolved_base, model, source = resolve_credentials(root, api_key, base_url)
    session_dir = Path(os.getenv("OMNI_SESSION_DIR", str(root / DEFAULT_SESSION_DIRNAME))).resolve()
    return Settings(
        auth_token=token,
        auth_source=source,
        base_url=resolved_base,
        model=model,
        max_tokens=_env_int("OMNI_MAX_TOKENS", DEFAULT_MAX_TOKENS),
        thinking_budget=_env_int("OMNI_THINKING_BUDGET", DEFAULT_THINKING_BUDGET),
        enable_thinking=_env_bool("OMNI_ENABLE_THINKING", True),
        compaction_threshold=_env_int("OMNI_COMPACTION_THRESHOLD", DEFAULT_COMPACTION_THRESHOLD),
        compaction_keep=_env_int("OMNI_COMPACTION_KEEP", DEFAULT_COMPACTION_KEEP),
        request_timeout=_env_float("OMNI_REQUEST_TIMEOUT", DEFAULT_REQUEST_TIMEOUT),
        connect_timeout=_env_float("OMNI_CONNECT_TIMEOUT", DEFAULT_CONNECT_TIMEOUT),
        max_retries=_env_int("OMNI_MAX_RETRIES", DEFAULT_MAX_RETRIES),
        retry_base_seconds=_env_float("OMNI_RETRY_BASE", DEFAULT_RETRY_BASE_SECONDS),
        retry_max_seconds=_env_float("OMNI_RETRY_MAX", DEFAULT_RETRY_MAX_SECONDS),
        stream_idle_timeout=_env_float("OMNI_STREAM_IDLE_TIMEOUT", DEFAULT_STREAM_IDLE_TIMEOUT),
        max_continuations=_env_int("OMNI_MAX_CONTINUATIONS", DEFAULT_MAX_CONTINUATIONS),
        max_tool_rounds=_env_int("OMNI_MAX_TOOL_ROUNDS", DEFAULT_MAX_TOOL_ROUNDS),
        tool_timeout=_env_float("OMNI_TOOL_TIMEOUT", DEFAULT_TOOL_TIMEOUT),
        max_tool_output_chars=_env_int("OMNI_MAX_TOOL_OUTPUT", DEFAULT_MAX_TOOL_OUTPUT_CHARS),
        workspace=root,
        session_dir=session_dir,
        allow_dangerous=_env_bool("OMNI_ALLOW_DANGEROUS", False),
    )
