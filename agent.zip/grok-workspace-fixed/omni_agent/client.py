"""Resilient AgentRouter HTTP client with SSE streaming, thinking blocks, and auto-continuation."""

from __future__ import annotations

import json
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence

import requests

from .config import (
    AUTH_STATUS_CODES,
    DEFAULT_MODEL_CANDIDATES,
    RETRYABLE_STATUS_CODES,
    Settings,
    load_settings,
)

logger = logging.getLogger("omni_agent.client")

StreamCallback = Callable[[str, Dict[str, Any]], None]


class AgentRouterError(RuntimeError):
    """Raised when the AgentRouter proxy returns an unrecoverable error."""

    def __init__(self, message: str, status_code: int | None = None, payload: Any = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


@dataclass
class ContentBlock:
    type: str
    text: str = ""
    thinking: str = ""
    id: str = ""
    name: str = ""
    input: Dict[str, Any] = field(default_factory=dict)
    signature: str = ""

    def to_api(self) -> Dict[str, Any]:
        if self.type == "text":
            return {"type": "text", "text": self.text}
        if self.type == "thinking":
            block: Dict[str, Any] = {"type": "thinking", "thinking": self.thinking}
            if self.signature:
                block["signature"] = self.signature
            return block
        if self.type == "tool_use":
            return {"type": "tool_use", "id": self.id, "name": self.name, "input": self.input}
        if self.type == "redacted_thinking":
            return {"type": "redacted_thinking", "data": self.text}
        return {"type": self.type}


@dataclass
class StreamMessage:
    id: str = ""
    model: str = ""
    role: str = "assistant"
    stop_reason: Optional[str] = None
    stop_sequence: Optional[str] = None
    usage: Dict[str, int] = field(default_factory=dict)
    blocks: List[ContentBlock] = field(default_factory=list)
    raw_events: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def text(self) -> str:
        return "".join(b.text for b in self.blocks if b.type == "text")

    @property
    def thinking(self) -> str:
        return "".join(b.thinking for b in self.blocks if b.type == "thinking")

    @property
    def tool_calls(self) -> List[ContentBlock]:
        return [b for b in self.blocks if b.type == "tool_use"]

    def to_assistant_message(self) -> Dict[str, Any]:
        content: List[Dict[str, Any]] = []
        for block in self.blocks:
            api = block.to_api()
            if block.type == "text" and not block.text:
                continue
            if block.type == "thinking" and not block.thinking:
                continue
            content.append(api)
        if not content:
            content = [{"type": "text", "text": self.text or ""}]
        return {"role": "assistant", "content": content}


class SSEParser:
    """Incremental Server-Sent Events parser for Anthropic-compatible streams."""

    def __init__(self) -> None:
        self._buffer = ""

    def feed(self, chunk: str) -> Iterator[Dict[str, Any]]:
        self._buffer += chunk
        while "\n\n" in self._buffer or "\r\n\r\n" in self._buffer:
            if "\r\n\r\n" in self._buffer and (
                "\n\n" not in self._buffer
                or self._buffer.find("\r\n\r\n") < self._buffer.find("\n\n")
            ):
                raw, self._buffer = self._buffer.split("\r\n\r\n", 1)
            else:
                raw, self._buffer = self._buffer.split("\n\n", 1)
            event = self._parse_event(raw)
            if event is not None:
                yield event

    def flush(self) -> Iterator[Dict[str, Any]]:
        if self._buffer.strip():
            event = self._parse_event(self._buffer)
            self._buffer = ""
            if event is not None:
                yield event

    @staticmethod
    def _parse_event(raw: str) -> Optional[Dict[str, Any]]:
        event_name = "message"
        data_lines: List[str] = []
        for line in raw.splitlines():
            if not line or line.startswith(":"):
                continue
            if line.startswith("event:"):
                event_name = line[6:].strip()
            elif line.startswith("data:"):
                data_lines.append(line[5:].lstrip())
            elif line.startswith("id:") or line.startswith("retry:"):
                continue
        if not data_lines:
            return None
        payload = "\n".join(data_lines)
        if payload == "[DONE]":
            return {"event": "done", "data": {"type": "done"}}
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            data = {"type": "raw", "data": payload}
        if isinstance(data, dict) and "type" not in data:
            data["type"] = event_name
        return {"event": event_name, "data": data}


class AgentRouterClient:
    """Production HTTP client for the AgentRouter Anthropic-compatible proxy."""

    def __init__(
        self,
        settings: Settings | None = None,
        session: requests.Session | None = None,
        on_event: StreamCallback | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        self.session = session or requests.Session()
        self.on_event = on_event
        self._resolved_model: Optional[str] = self.settings.model or None
        self._models_cache: Optional[List[Dict[str, Any]]] = None

    def close(self) -> None:
        self.session.close()

    def set_auth(self, api_key: str, base_url: str | None = None, source: str = "runtime") -> None:
        """Swap credentials at runtime and drop any cached model discovery."""
        self.settings.set_auth(api_key, base_url, source=source)
        self._models_cache = None
        self._resolved_model = self.settings.model or None

    def check_auth(self) -> tuple[bool, str]:
        """Cheap round-trip against /v1/models to validate the key. Never raises."""
        if not self.settings.auth_token.strip():
            return False, "No API key set. Run `omni-agent --login` or set ANTHROPIC_AUTH_TOKEN."
        try:
            models = self.discover_models(force=True)
        except AgentRouterError as exc:
            return False, str(exc)
        except Exception as exc:  # noqa: BLE001
            return False, f"Unexpected error contacting {self.settings.base_url}: {exc}"
        return True, f"Authenticated against {self.settings.base_url} ({len(models)} models available)"

    def __enter__(self) -> "AgentRouterClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def discover_models(self, force: bool = False) -> List[Dict[str, Any]]:
        if self._models_cache is not None and not force:
            return self._models_cache
        response = self._request("GET", self.settings.models_url, stream=False)
        payload = response.json()
        models: List[Dict[str, Any]]
        if isinstance(payload, dict) and isinstance(payload.get("data"), list):
            models = payload["data"]
        elif isinstance(payload, list):
            models = payload
        else:
            models = []
        self._models_cache = models
        return models

    def resolve_model(self, preferred: str | None = None) -> str:
        if preferred:
            self._resolved_model = preferred
            return preferred
        if self._resolved_model:
            return self._resolved_model
        discovered = []
        try:
            discovered = self.discover_models()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Model discovery failed (%s); falling back to candidates", exc)
        ids: List[str] = []
        for item in discovered:
            if isinstance(item, dict):
                mid = item.get("id") or item.get("name")
                if isinstance(mid, str):
                    ids.append(mid)
            elif isinstance(item, str):
                ids.append(item)
        if self.settings.model and (not ids or self.settings.model in ids):
            self._resolved_model = self.settings.model
            return self._resolved_model
        for candidate in DEFAULT_MODEL_CANDIDATES:
            if candidate in ids:
                self._resolved_model = candidate
                return candidate
        if ids:
            self._resolved_model = ids[0]
            return ids[0]
        self._resolved_model = self.settings.model or DEFAULT_MODEL_CANDIDATES[0]
        return self._resolved_model

    def stream(
        self,
        messages: Sequence[Dict[str, Any]],
        *,
        system: str | Sequence[Dict[str, Any]] | None = None,
        tools: Sequence[Dict[str, Any]] | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
        thinking: Dict[str, Any] | None = None,
        extra_body: Dict[str, Any] | None = None,
        auto_continue: bool = True,
    ) -> StreamMessage:
        """Stream a completion, optionally auto-continuing on max_tokens."""
        working_messages: List[Dict[str, Any]] = list(messages)
        continuations = 0
        assembled = StreamMessage()
        while True:
            piece = self._stream_once(
                working_messages,
                system=system,
                tools=tools,
                model=model,
                max_tokens=max_tokens,
                thinking=thinking,
                extra_body=extra_body,
            )
            assembled = self._merge_messages(assembled, piece) if assembled.blocks else piece
            if (
                auto_continue
                and piece.stop_reason == "max_tokens"
                and continuations < self.settings.max_continuations
            ):
                continuations += 1
                logger.info("Hit max_tokens; auto-continuing (%s/%s)", continuations, self.settings.max_continuations)
                working_messages = list(working_messages)
                working_messages.append(piece.to_assistant_message())
                working_messages.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": (
                                    "Continue exactly from where you left off. "
                                    "Do not repeat prior text. Resume the unfinished response."
                                ),
                            }
                        ],
                    }
                )
                continue
            assembled.stop_reason = piece.stop_reason
            assembled.stop_sequence = piece.stop_sequence
            assembled.usage = self._merge_usage(assembled.usage, piece.usage)
            return assembled

    def complete(
        self,
        messages: Sequence[Dict[str, Any]],
        **kwargs: Any,
    ) -> StreamMessage:
        return self.stream(messages, **kwargs)

    def _stream_once(
        self,
        messages: Sequence[Dict[str, Any]],
        *,
        system: str | Sequence[Dict[str, Any]] | None,
        tools: Sequence[Dict[str, Any]] | None,
        model: str | None,
        max_tokens: int | None,
        thinking: Dict[str, Any] | None,
        extra_body: Dict[str, Any] | None,
    ) -> StreamMessage:
        body: Dict[str, Any] = {
            "model": self.resolve_model(model),
            "max_tokens": max_tokens or self.settings.max_tokens,
            "stream": True,
            "messages": list(messages),
        }
        if system:
            body["system"] = system
        if tools:
            body["tools"] = list(tools)
        if thinking is not None:
            body["thinking"] = thinking
        elif self.settings.enable_thinking and self.settings.thinking_budget > 0:
            budget = min(self.settings.thinking_budget, max(1024, body["max_tokens"] - 1024))
            if budget >= 1024:
                body["thinking"] = {"type": "enabled", "budget_tokens": budget}
        if extra_body:
            body.update(extra_body)

        response = self._request("POST", self.settings.messages_url, json_body=body, stream=True)
        parser = SSEParser()
        message = StreamMessage(model=body["model"])
        blocks: Dict[int, ContentBlock] = {}
        json_buffers: Dict[int, str] = {}
        last_data = time.monotonic()

        def emit(kind: str, payload: Dict[str, Any]) -> None:
            if self.on_event:
                try:
                    self.on_event(kind, payload)
                except Exception:  # noqa: BLE001
                    logger.exception("Stream callback failed")

        try:
            for raw_chunk in response.iter_content(chunk_size=4096, decode_unicode=False):
                if not raw_chunk:
                    if time.monotonic() - last_data > self.settings.stream_idle_timeout:
                        raise AgentRouterError("SSE stream idle timeout exceeded")
                    continue
                last_data = time.monotonic()
                text = raw_chunk.decode("utf-8", errors="replace") if isinstance(raw_chunk, bytes) else raw_chunk
                for event in parser.feed(text):
                    self._apply_event(event, message, blocks, json_buffers, emit)
            for event in parser.flush():
                self._apply_event(event, message, blocks, json_buffers, emit)
        finally:
            response.close()

        ordered = [blocks[i] for i in sorted(blocks)]
        if ordered:
            message.blocks = ordered
        for index, buf in json_buffers.items():
            block = blocks.get(index)
            if block and block.type == "tool_use" and buf and not block.input:
                try:
                    parsed = json.loads(buf)
                    if isinstance(parsed, dict):
                        block.input = parsed
                except json.JSONDecodeError:
                    block.input = {"_raw": buf}
        return message

    def _apply_event(
        self,
        event: Dict[str, Any],
        message: StreamMessage,
        blocks: Dict[int, ContentBlock],
        json_buffers: Dict[int, str],
        emit: StreamCallback,
    ) -> None:
        data = event.get("data") or {}
        if not isinstance(data, dict):
            return
        etype = data.get("type") or event.get("event")
        message.raw_events.append(data)
        emit(str(etype), data)

        if etype == "error" or event.get("event") == "error":
            err = data.get("error") if isinstance(data.get("error"), dict) else data
            raise AgentRouterError(str(err.get("message") or err), payload=data)

        if etype == "message_start":
            inner = data.get("message") or {}
            message.id = inner.get("id") or message.id
            message.model = inner.get("model") or message.model
            message.role = inner.get("role") or message.role
            usage = inner.get("usage") or {}
            if isinstance(usage, dict):
                message.usage.update({k: int(v) for k, v in usage.items() if isinstance(v, (int, float))})
            return

        if etype == "content_block_start":
            index = int(data.get("index") or 0)
            raw_block = data.get("content_block") or {}
            btype = raw_block.get("type") or "text"
            block = ContentBlock(
                type=btype,
                text=raw_block.get("text") or "",
                thinking=raw_block.get("thinking") or "",
                id=raw_block.get("id") or "",
                name=raw_block.get("name") or "",
                input=raw_block.get("input") if isinstance(raw_block.get("input"), dict) else {},
                signature=raw_block.get("signature") or "",
            )
            blocks[index] = block
            if btype == "tool_use":
                json_buffers[index] = ""
            return

        if etype == "content_block_delta":
            index = int(data.get("index") or 0)
            delta = data.get("delta") or {}
            dtype = delta.get("type")
            block = blocks.setdefault(index, ContentBlock(type="text"))
            if dtype == "thinking_delta" or "thinking" in delta:
                block.type = "thinking"
                block.thinking += str(delta.get("thinking") or "")
                emit("thinking_delta", {"index": index, "thinking": delta.get("thinking") or ""})
            elif dtype == "text_delta" or "text" in delta:
                block.type = block.type if block.type == "thinking" else "text"
                if dtype == "text_delta" or block.type == "text":
                    block.type = "text"
                    block.text += str(delta.get("text") or "")
            elif dtype == "input_json_delta" or "partial_json" in delta:
                block.type = "tool_use"
                json_buffers[index] = json_buffers.get(index, "") + str(delta.get("partial_json") or "")
            elif dtype == "signature_delta":
                block.signature += str(delta.get("signature") or "")
            return

        if etype == "content_block_stop":
            index = int(data.get("index") or 0)
            buf = json_buffers.get(index)
            block = blocks.get(index)
            if block and block.type == "tool_use" and buf:
                try:
                    parsed = json.loads(buf)
                    if isinstance(parsed, dict):
                        block.input = parsed
                except json.JSONDecodeError:
                    logger.warning("Incomplete tool JSON for block %s", index)
            return

        if etype == "message_delta":
            delta = data.get("delta") or {}
            if "stop_reason" in delta:
                message.stop_reason = delta.get("stop_reason")
            if "stop_sequence" in delta:
                message.stop_sequence = delta.get("stop_sequence")
            usage = data.get("usage") or {}
            if isinstance(usage, dict):
                for key, value in usage.items():
                    if isinstance(value, (int, float)):
                        message.usage[key] = int(value)
            return

        if etype == "message_stop":
            if not message.stop_reason:
                message.stop_reason = "end_turn"

    def _request(
        self,
        method: str,
        url: str,
        *,
        json_body: Dict[str, Any] | None = None,
        stream: bool = False,
    ) -> requests.Response:
        if not self.settings.auth_token.strip():
            raise AgentRouterError(
                "No API key configured. Set one with any of:\n"
                "  omni-agent --login                 (prompts, then saves to ~/.omni_agent/credentials.json)\n"
                "  omni-agent --api-key <KEY> ...     (one-off, not saved)\n"
                "  export ANTHROPIC_AUTH_TOKEN=<KEY>  (or ANTHROPIC_API_KEY / AGENTROUTER_API_KEY)\n"
                "  echo 'ANTHROPIC_AUTH_TOKEN=<KEY>' >> .env",
                status_code=None,
            )
        headers = self.settings.client_headers()
        if not stream:
            headers = dict(headers)
            headers["Accept"] = "application/json"
        last_error: Exception | None = None
        attempts = max(1, self.settings.max_retries)
        for attempt in range(1, attempts + 1):
            try:
                response = self.session.request(
                    method,
                    url,
                    headers=headers,
                    json=json_body,
                    stream=stream,
                    timeout=(self.settings.connect_timeout, self.settings.request_timeout),
                )
            except (requests.ConnectionError, requests.Timeout) as exc:
                last_error = exc
                self._backoff(attempt, attempts, cause=str(exc))
                continue
            if response.status_code in RETRYABLE_STATUS_CODES:
                retry_after = self._retry_after(response)
                body_preview = self._safe_body(response)
                last_error = AgentRouterError(
                    f"HTTP {response.status_code}: {body_preview}",
                    status_code=response.status_code,
                    payload=body_preview,
                )
                response.close()
                self._backoff(attempt, attempts, retry_after=retry_after, cause=str(last_error))
                continue
            if response.status_code in AUTH_STATUS_CODES:
                payload = self._safe_body(response)
                response.close()
                raise AgentRouterError(
                    f"HTTP {response.status_code}: {self.settings.base_url} rejected the API key "
                    f"({self.settings.masked_token}, from {self.settings.auth_source or 'unknown'}).\n"
                    "Check the key is correct and still has credit, then re-enter it with "
                    "`omni-agent --login` or `/login` inside the REPL.\n"
                    f"Server said: {payload}",
                    status_code=response.status_code,
                    payload=payload,
                )
            if response.status_code == 404:
                payload = self._safe_body(response)
                response.close()
                raise AgentRouterError(
                    f"HTTP 404 for {url}. The base URL looks wrong — it must be the provider origin "
                    f"only (e.g. https://agentrouter.org), not a full endpoint path. "
                    f"Current base_url: {self.settings.base_url}\nServer said: {payload}",
                    status_code=404,
                    payload=payload,
                )
            if response.status_code >= 400:
                payload = self._safe_body(response)
                response.close()
                raise AgentRouterError(
                    f"HTTP {response.status_code}: {payload}",
                    status_code=response.status_code,
                    payload=payload,
                )
            return response
        raise AgentRouterError(f"Exhausted retries for {method} {url}: {last_error}") from last_error

    def _backoff(self, attempt: int, attempts: int, retry_after: float | None = None, cause: str = "") -> None:
        if attempt >= attempts:
            return
        base = min(
            self.settings.retry_max_seconds,
            self.settings.retry_base_seconds * (2 ** (attempt - 1)),
        )
        delay = retry_after if retry_after is not None else base
        delay = delay + random.uniform(0, min(0.4, delay * 0.2))
        logger.warning("Retry %s/%s in %.2fs (%s)", attempt, attempts, delay, cause)
        time.sleep(delay)

    @staticmethod
    def _retry_after(response: requests.Response) -> float | None:
        raw = response.headers.get("Retry-After")
        if not raw:
            return None
        try:
            return float(raw)
        except ValueError:
            return None

    @staticmethod
    def _safe_body(response: requests.Response) -> str:
        try:
            text = response.text
        except Exception:  # noqa: BLE001
            return "<unreadable body>"
        return text[:4000]

    @staticmethod
    def _merge_usage(left: Dict[str, int], right: Dict[str, int]) -> Dict[str, int]:
        merged = dict(left)
        for key, value in right.items():
            merged[key] = merged.get(key, 0) + int(value)
        return merged

    @staticmethod
    def _merge_messages(head: StreamMessage, tail: StreamMessage) -> StreamMessage:
        merged = StreamMessage(
            id=tail.id or head.id,
            model=tail.model or head.model,
            role=tail.role or head.role,
            stop_reason=tail.stop_reason,
            stop_sequence=tail.stop_sequence,
            usage=AgentRouterClient._merge_usage(head.usage, tail.usage),
            blocks=list(head.blocks),
            raw_events=list(head.raw_events) + list(tail.raw_events),
        )
        if not tail.blocks:
            return merged
        if merged.blocks and merged.blocks[-1].type == "text" and tail.blocks[0].type == "text":
            merged.blocks[-1].text += tail.blocks[0].text
            merged.blocks.extend(tail.blocks[1:])
        else:
            merged.blocks.extend(tail.blocks)
        return merged
