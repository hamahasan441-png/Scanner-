# Omni Agent

Autonomous software engineering agent framework. See [`omni_agent/README.md`](omni_agent/README.md) for the Python package.

This workspace also hosts the OMNI control plane — an interactive map of the architecture, tool registry, source, and a live loop console.


## v3 Web Workspace

The control plane now includes a dedicated `/workspace` file staging UI with drag-and-drop and multi-file selection. Text/code files up to 2 MiB are indexed in-browser for session context, images receive local previews, and no file is transmitted to a provider by the upload control itself. This keeps provider credentials server-side and makes the upload boundary explicit.
