"""Tool registry for the Omni autonomous engineering agent."""

from __future__ import annotations

import ast
import concurrent.futures
import difflib
import hashlib
import json
import os
import py_compile
import re
import shlex
import socket
import ipaddress
import shutil
import signal
import subprocess
import tempfile
import time
import traceback
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

from .config import Settings, load_settings

ToolHandler = Callable[[Dict[str, Any]], str]


@dataclass
class ToolSpec:
    name: str
    description: str
    input_schema: Dict[str, Any]
    handler: ToolHandler
    timeout: float | None = None


@dataclass
class ToolResult:
    name: str
    tool_use_id: str
    output: str
    is_error: bool = False
    duration_ms: int = 0


class ToolError(RuntimeError):
    pass


class _HTMLTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._chunks: List[str] = []
        self._skip = 0
        self._href: Optional[str] = None

    def handle_starttag(self, tag: str, attrs: List[tuple]) -> None:
        if tag in {"script", "style", "noscript", "svg"}:
            self._skip += 1
            return
        if tag in {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "tr", "section", "article"}:
            self._chunks.append("\n")
        if tag == "a":
            href = dict(attrs).get("href")
            self._href = href
        if tag == "img":
            alt = dict(attrs).get("alt")
            if alt:
                self._chunks.append(f" [{alt}] ")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript", "svg"} and self._skip:
            self._skip -= 1
        if tag == "a" and self._href:
            self._chunks.append(f" ({self._href})")
            self._href = None

    def handle_data(self, data: str) -> None:
        if self._skip:
            return
        text = re.sub(r"\s+", " ", data)
        if text.strip():
            self._chunks.append(text)

    def text(self) -> str:
        joined = "".join(self._chunks)
        joined = re.sub(r"[ \t]+", " ", joined)
        joined = re.sub(r"\n{3,}", "\n\n", joined)
        return joined.strip()


class DaemonSupervisor:
    """Background process supervisor with pid-file persistence."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._procs: Dict[str, subprocess.Popen] = {}
        self._meta: Dict[str, Dict[str, Any]] = {}
        self._load()

    def _load(self) -> None:
        path = self.settings.daemons_path
        if path.exists():
            try:
                self._meta = json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                self._meta = {}

    def _save(self) -> None:
        self.settings.ensure_session_dir()
        self.settings.daemons_path.write_text(
            json.dumps(self._meta, indent=2, sort_keys=True), encoding="utf-8"
        )

    def start(self, name: str, command: str, cwd: str | None = None) -> Dict[str, Any]:
        if name in self._procs and self._procs[name].poll() is None:
            raise ToolError(f"Daemon '{name}' is already running")
        log_dir = self.settings.session_dir / "daemons"
        log_dir.mkdir(parents=True, exist_ok=True)
        stdout_path = log_dir / f"{name}.out.log"
        stderr_path = log_dir / f"{name}.err.log"
        stdout = open(stdout_path, "ab")
        stderr = open(stderr_path, "ab")
        proc = subprocess.Popen(
            command,
            shell=True,
            cwd=cwd or str(self.settings.workspace),
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
        )
        self._procs[name] = proc
        self._meta[name] = {
            "name": name,
            "command": command,
            "pid": proc.pid,
            "cwd": cwd or str(self.settings.workspace),
            "started_at": time.time(),
            "stdout_log": str(stdout_path),
            "stderr_log": str(stderr_path),
            "status": "running",
        }
        self._save()
        return self._meta[name]

    def stop(self, name: str, kill: bool = False) -> Dict[str, Any]:
        meta = self._meta.get(name)
        if not meta:
            raise ToolError(f"Unknown daemon '{name}'")
        pid = int(meta.get("pid") or 0)
        proc = self._procs.get(name)
        sig = signal.SIGKILL if kill else signal.SIGTERM
        try:
            if proc and proc.poll() is None:
                os.killpg(os.getpgid(proc.pid), sig)
                proc.wait(timeout=8)
            elif pid:
                os.kill(pid, sig)
        except (ProcessLookupError, PermissionError, subprocess.TimeoutExpired):
            if pid:
                try:
                    os.kill(pid, signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    pass
        meta["status"] = "stopped"
        meta["stopped_at"] = time.time()
        self._save()
        return meta

    def status(self, name: str | None = None) -> List[Dict[str, Any]]:
        names = [name] if name else list(self._meta)
        result = []
        for item in names:
            meta = dict(self._meta.get(item) or {"name": item, "status": "unknown"})
            pid = int(meta.get("pid") or 0)
            alive = False
            if pid:
                try:
                    os.kill(pid, 0)
                    alive = True
                except OSError:
                    alive = False
            meta["status"] = "running" if alive else "stopped"
            result.append(meta)
        return result

    def logs(self, name: str, tail: int = 80, stream: str = "stdout") -> str:
        meta = self._meta.get(name)
        if not meta:
            raise ToolError(f"Unknown daemon '{name}'")
        path = Path(meta["stderr_log"] if stream == "stderr" else meta["stdout_log"])
        if not path.exists():
            return ""
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-tail:])


class TaskTracker:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._tasks: List[Dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        path = self.settings.tasks_path
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                self._tasks = payload if isinstance(payload, list) else payload.get("tasks", [])
            except json.JSONDecodeError:
                self._tasks = []

    def _save(self) -> None:
        self.settings.ensure_session_dir()
        self.settings.tasks_path.write_text(json.dumps(self._tasks, indent=2), encoding="utf-8")

    def create(self, title: str, detail: str = "", priority: str = "normal") -> Dict[str, Any]:
        task = {
            "id": hashlib.sha1(f"{time.time()}:{title}".encode()).hexdigest()[:10],
            "title": title,
            "detail": detail,
            "priority": priority,
            "status": "open",
            "created_at": time.time(),
            "updated_at": time.time(),
        }
        self._tasks.append(task)
        self._save()
        return task

    def update(self, task_id: str, **fields: Any) -> Dict[str, Any]:
        for task in self._tasks:
            if task["id"] == task_id or task["title"] == task_id:
                task.update({k: v for k, v in fields.items() if v is not None})
                task["updated_at"] = time.time()
                self._save()
                return task
        raise ToolError(f"Task not found: {task_id}")

    def list(self, status: str | None = None) -> List[Dict[str, Any]]:
        if not status:
            return list(self._tasks)
        return [t for t in self._tasks if t.get("status") == status]


class ToolRegistry:
    """Registers, schemas, and executes agent tools."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self.daemons = DaemonSupervisor(self.settings)
        self.tasks = TaskTracker(self.settings)
        self._tools: Dict[str, ToolSpec] = {}
        self._register_defaults()

    def register(self, spec: ToolSpec) -> None:
        self._tools[spec.name] = spec

    def names(self) -> List[str]:
        return sorted(self._tools)

    def get(self, name: str) -> ToolSpec:
        if name not in self._tools:
            raise ToolError(f"Unknown tool: {name}")
        return self._tools[name]

    def anthropic_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": spec.name,
                "description": spec.description,
                "input_schema": spec.input_schema,
            }
            for spec in self._tools.values()
        ]

    def execute(self, name: str, arguments: Dict[str, Any], tool_use_id: str = "") -> ToolResult:
        spec = self.get(name)
        started = time.monotonic()
        timeout = spec.timeout or self.settings.tool_timeout
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(spec.handler, arguments or {})
                output = future.result(timeout=timeout)
            is_error = False
        except concurrent.futures.TimeoutError:
            output = f"Tool '{name}' timed out after {timeout}s"
            is_error = True
        except Exception as exc:  # noqa: BLE001
            output = f"Tool '{name}' failed: {exc}\n{traceback.format_exc()}"
            is_error = True
        duration_ms = int((time.monotonic() - started) * 1000)
        text = self._clip(str(output))
        return ToolResult(
            name=name,
            tool_use_id=tool_use_id,
            output=text,
            is_error=is_error,
            duration_ms=duration_ms,
        )

    READ_ONLY_TOOLS = frozenset({
        "read_file", "syntax_check", "find_symbol", "repo_map",
        "fetch_url", "glob_search", "grep_search", "select_best_option",
    })

    def execute_blocks(self, blocks: Sequence[Any]) -> List[Dict[str, Any]]:
        items = []
        for block in blocks:
            name = getattr(block, "name", None) or block.get("name")
            tool_id = getattr(block, "id", None) or block.get("id") or ""
            arguments = getattr(block, "input", None) or block.get("input") or {}
            items.append((name, tool_id, arguments))

        # Parallelize only read-only calls. Mutating tools remain ordered to avoid
        # write/write races and to preserve the model's intended edit sequence.
        if len(items) > 1 and all(name in self.READ_ONLY_TOOLS for name, _, _ in items):
            workers = max(1, min(self.settings.max_tool_workers, len(items)))
            with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                futures = [pool.submit(self.execute, name, args, tool_use_id=tool_id) for name, tool_id, args in items]
                tool_results = [future.result() for future in futures]
        else:
            tool_results = [self.execute(name, args, tool_use_id=tool_id) for name, tool_id, args in items]

        return [
            {
                "type": "tool_result",
                "tool_use_id": result.tool_use_id,
                "content": result.output,
                "is_error": result.is_error,
            }
            for result in tool_results
        ]

    def _clip(self, text: str) -> str:
        limit = self.settings.max_tool_output_chars
        if len(text) <= limit:
            return text
        head = text[: limit // 2]
        tail = text[-(limit // 2) :]
        return f"{head}\n\n...[{len(text) - limit} chars truncated]...\n\n{tail}"

    def _resolve(self, path: str | os.PathLike[str]) -> Path:
        candidate = Path(path)
        if not candidate.is_absolute():
            candidate = self.settings.workspace / candidate
        resolved = candidate.resolve()
        workspace = self.settings.workspace.resolve()
        try:
            resolved.relative_to(workspace)
        except ValueError as exc:
            raise ToolError(f"Path escapes workspace: {resolved}") from exc
        return resolved

    def _register_defaults(self) -> None:
        self.register(
            ToolSpec(
                name="bash",
                description="Run a shell command in the workspace. Prefer non-interactive commands.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "command": {"type": "string", "description": "Shell command to execute"},
                        "cwd": {"type": "string", "description": "Optional working directory"},
                        "timeout": {"type": "number", "description": "Timeout in seconds"},
                    },
                    "required": ["command"],
                },
                handler=self._bash,
            )
        )
        self.register(
            ToolSpec(
                name="read_file",
                description="Read a UTF-8 text file. Optionally slice by 1-based line numbers.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "offset": {"type": "integer", "description": "1-based start line"},
                        "limit": {"type": "integer", "description": "Max lines to return"},
                    },
                    "required": ["path"],
                },
                handler=self._read_file,
            )
        )
        self.register(
            ToolSpec(
                name="write_file",
                description="Write a complete file. Creates parent directories. Runs a syntax check afterwards.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "content": {"type": "string"},
                    },
                    "required": ["path", "content"],
                },
                handler=self._write_file,
            )
        )
        self.register(
            ToolSpec(
                name="apply_patch",
                description=(
                    "Apply a unified diff or search/replace patch with fuzzy matching via difflib. "
                    "Use when editing existing files."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "patch": {"type": "string", "description": "Unified diff or old/new block"},
                        "old_text": {"type": "string", "description": "Exact or near-exact text to replace"},
                        "new_text": {"type": "string", "description": "Replacement text"},
                        "fuzzy_ratio": {
                            "type": "number",
                            "description": "Minimum similarity 0-1 for fuzzy match (default 0.72)",
                        },
                    },
                    "required": ["path"],
                },
                handler=self._apply_patch,
            )
        )
        self.register(
            ToolSpec(
                name="syntax_check",
                description="Syntax-check a file with py_compile or node --check.",
                input_schema={
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
                handler=self._syntax_check,
            )
        )
        self.register(
            ToolSpec(
                name="find_symbol",
                description="Search Python (AST) and text symbols across the workspace.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "kind": {
                            "type": "string",
                            "enum": ["any", "function", "class", "method", "assignment"],
                        },
                        "path": {"type": "string", "description": "Optional subdirectory or file"},
                    },
                    "required": ["name"],
                },
                handler=self._find_symbol,
            )
        )
        self.register(
            ToolSpec(
                name="repo_map",
                description="Build a compact repository map of files and top-level symbols.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "max_files": {"type": "integer"},
                        "max_depth": {"type": "integer"},
                    },
                },
                handler=self._repo_map,
            )
        )
        self.register(
            ToolSpec(
                name="fetch_url",
                description="Fetch a URL and return extracted text (HTML stripped) or raw JSON.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "url": {"type": "string"},
                        "max_chars": {"type": "integer"},
                    },
                    "required": ["url"],
                },
                handler=self._fetch_url,
            )
        )
        self.register(
            ToolSpec(
                name="daemon_control",
                description="Supervise background daemons: start, stop, status, logs.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["start", "stop", "status", "logs", "kill"]},
                        "name": {"type": "string"},
                        "command": {"type": "string"},
                        "cwd": {"type": "string"},
                        "tail": {"type": "integer"},
                        "stream": {"type": "string", "enum": ["stdout", "stderr"]},
                    },
                    "required": ["action"],
                },
                handler=self._daemon_control,
            )
        )
        self.register(
            ToolSpec(
                name="manage_tasks",
                description="Track multi-step work: create, update, list, complete, or cancel tasks.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["create", "update", "list", "complete", "cancel"],
                        },
                        "id": {"type": "string"},
                        "title": {"type": "string"},
                        "detail": {"type": "string"},
                        "priority": {"type": "string", "enum": ["low", "normal", "high", "critical"]},
                        "status": {"type": "string"},
                    },
                    "required": ["action"],
                },
                handler=self._manage_tasks,
            )
        )
        self.register(
            ToolSpec(
                name="select_best_option",
                description=(
                    "Autonomous trade-off evaluator. Score candidate options against weighted criteria "
                    "and return a ranked recommendation with rationale."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "goal": {"type": "string"},
                        "options": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "string"},
                                    "summary": {"type": "string"},
                                    "pros": {"type": "array", "items": {"type": "string"}},
                                    "cons": {"type": "array", "items": {"type": "string"}},
                                    "scores": {
                                        "type": "object",
                                        "additionalProperties": {"type": "number"},
                                    },
                                },
                                "required": ["id", "summary"],
                            },
                        },
                        "criteria": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "weight": {"type": "number"},
                                    "higher_is_better": {"type": "boolean"},
                                },
                                "required": ["name"],
                            },
                        },
                    },
                    "required": ["goal", "options"],
                },
                handler=self._select_best_option,
            )
        )
        self.register(
            ToolSpec(
                name="glob_search",
                description="Find files matching a glob pattern under the workspace.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string"},
                        "path": {"type": "string"},
                    },
                    "required": ["pattern"],
                },
                handler=self._glob_search,
            )
        )
        self.register(
            ToolSpec(
                name="grep_search",
                description="Search file contents with a regular expression.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string"},
                        "path": {"type": "string"},
                        "glob": {"type": "string"},
                        "max_matches": {"type": "integer"},
                    },
                    "required": ["pattern"],
                },
                handler=self._grep_search,
            )
        )

    def _bash(self, args: Dict[str, Any]) -> str:
        command = str(args.get("command") or "").strip()
        if not command:
            raise ToolError("command is required")
        if self.settings.is_dangerous(command):
            raise ToolError(
                f"Blocked dangerous command. Set OMNI_ALLOW_DANGEROUS=1 to override.\nCommand: {command}"
            )
        cwd = args.get("cwd")
        workdir = self._resolve(cwd) if cwd else self.settings.workspace
        timeout = float(args.get("timeout") or self.settings.tool_timeout)
        completed = subprocess.run(
            command,
            shell=True,
            cwd=str(workdir),
            capture_output=True,
            text=True,
            timeout=timeout,
            env=os.environ.copy(),
        )
        parts = [
            f"exit_code: {completed.returncode}",
            f"cwd: {workdir}",
        ]
        if completed.stdout:
            parts.append("stdout:\n" + completed.stdout)
        if completed.stderr:
            parts.append("stderr:\n" + completed.stderr)
        return "\n".join(parts)

    def _read_file(self, args: Dict[str, Any]) -> str:
        path = self._resolve(args["path"])
        if not path.exists():
            raise ToolError(f"File not found: {path}")
        if path.is_dir():
            entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            lines = []
            for entry in entries[:500]:
                suffix = "/" if entry.is_dir() else ""
                lines.append(f"{entry.name}{suffix}")
            return "\n".join(lines)
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        offset = int(args.get("offset") or 1)
        limit = args.get("limit")
        start = max(offset - 1, 0)
        end = start + int(limit) if limit else len(lines)
        sliced = lines[start:end]
        numbered = [f"{i + start + 1:>6}|{line}" for i, line in enumerate(sliced)]
        return f"{path} ({len(lines)} lines)\n" + "\n".join(numbered)

    def _write_file(self, args: Dict[str, Any]) -> str:
        path = self._resolve(args["path"])
        content = args.get("content")
        if content is None:
            raise ToolError("content is required")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(content), encoding="utf-8")
        check = self._syntax_check({"path": str(path)})
        return f"Wrote {path} ({len(str(content))} bytes)\n{check}"

    def _apply_patch(self, args: Dict[str, Any]) -> str:
        path = self._resolve(args["path"])
        if not path.exists():
            raise ToolError(f"File not found: {path}")
        original = path.read_text(encoding="utf-8", errors="replace")
        old_text = args.get("old_text")
        new_text = args.get("new_text")
        patch = args.get("patch")
        ratio = float(args.get("fuzzy_ratio") or 0.72)
        if old_text is not None and new_text is not None:
            updated = self._replace_fuzzy(original, str(old_text), str(new_text), ratio)
        elif patch:
            updated = self._apply_unified_or_block(original, str(patch), ratio)
        else:
            raise ToolError("Provide old_text/new_text or patch")
        if updated == original:
            raise ToolError("Patch produced no changes")
        path.write_text(updated, encoding="utf-8")
        check = self._syntax_check({"path": str(path)})
        diff = "".join(
            difflib.unified_diff(
                original.splitlines(True),
                updated.splitlines(True),
                fromfile=f"a/{path.name}",
                tofile=f"b/{path.name}",
            )
        )
        return f"Patched {path}\n{diff}\n{check}"

    def _replace_fuzzy(self, original: str, old: str, new: str, ratio: float) -> str:
        if old in original:
            if original.count(old) != 1:
                raise ToolError(f"old_text matched {original.count(old)} times; expected 1")
            return original.replace(old, new, 1)
        lines = original.splitlines(True)
        needle = old.splitlines(True) or [old]
        window = len(needle)
        best_i = -1
        best_score = 0.0
        for i in range(0, max(len(lines) - window + 1, 1)):
            chunk = "".join(lines[i : i + window])
            score = difflib.SequenceMatcher(None, chunk, old).ratio()
            if score > best_score:
                best_score = score
                best_i = i
        if best_i < 0 or best_score < ratio:
            raise ToolError(f"No fuzzy match above {ratio:.2f} (best={best_score:.2f})")
        return "".join(lines[:best_i]) + new + "".join(lines[best_i + window :])

    def _apply_unified_or_block(self, original: str, patch: str, ratio: float) -> str:
        if "@@" in patch or patch.lstrip().startswith(("---", "diff ")):
            return self._apply_unified_diff(original, patch)
        if "<<<<<<< SEARCH" in patch or "*** Begin Patch" in patch:
            return self._apply_search_replace_blocks(original, patch, ratio)
        raise ToolError("Unrecognized patch format")

    def _apply_unified_diff(self, original: str, patch: str) -> str:
        lines = original.splitlines(True)
        hunks = self._parse_hunks(patch)
        if not hunks:
            return self._apply_with_system_patch(original, patch)
        cursor = 0
        output: List[str] = []
        for old_start, _old_count, hunk_lines in hunks:
            target_index = max(old_start - 1, 0)
            old_buf: List[str] = []
            new_buf: List[str] = []
            for raw in hunk_lines:
                if not raw or raw.startswith("\\"):
                    continue
                tag, body = raw[0], raw[1:]
                if tag == " ":
                    old_buf.append(body)
                    new_buf.append(body)
                elif tag == "-":
                    old_buf.append(body)
                elif tag == "+":
                    new_buf.append(body)
            expected = "".join(old_buf)
            actual = "".join(lines[target_index : target_index + len(old_buf)])
            if expected and expected != actual:
                relocated = self._locate_hunk(lines, old_buf, target_index)
                if relocated is None:
                    raise ToolError("Failed to apply hunk; context mismatch")
                target_index = relocated
            if target_index < cursor:
                raise ToolError("Hunks out of order")
            output.extend(lines[cursor:target_index])
            output.extend(new_buf)
            cursor = target_index + len(old_buf)
        output.extend(lines[cursor:])
        return "".join(output)

    def _parse_hunks(self, patch: str) -> List[tuple]:
        hunks: List[tuple] = []
        hunk_re = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
        current: Optional[List[str]] = None
        old_start = 0
        old_count = 0
        for line in patch.splitlines(True):
            match = hunk_re.match(line)
            if match:
                if current is not None:
                    hunks.append((old_start, old_count, current))
                old_start = int(match.group(1))
                old_count = int(match.group(2) or "1")
                current = []
                continue
            if current is not None and (line.startswith(("+", "-", " ")) or line.startswith("\\")):
                current.append(line if line.endswith("\n") else line + "\n")
        if current is not None:
            hunks.append((old_start, old_count, current))
        return hunks

    def _locate_hunk(self, lines: List[str], old_buf: List[str], hint: int) -> Optional[int]:
        expected = "".join(old_buf)
        window = len(old_buf)
        best_i = None
        best = 0.0
        start = max(hint - 200, 0)
        end = min(hint + 200, max(len(lines) - window + 1, 1))
        for i in range(start, end):
            chunk = "".join(lines[i : i + window])
            score = difflib.SequenceMatcher(None, chunk, expected).ratio()
            if score > best:
                best = score
                best_i = i
        if best_i is not None and best >= 0.72:
            return best_i
        return None

    def _apply_with_system_patch(self, original: str, patch: str) -> str:
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "file"
            diff = Path(tmp) / "file.diff"
            src.write_text(original, encoding="utf-8")
            diff.write_text(patch, encoding="utf-8")
            completed = subprocess.run(
                ["patch", "-p0", "--fuzz=3", str(src), str(diff)],
                capture_output=True,
                text=True,
            )
            if completed.returncode != 0:
                raise ToolError(f"patch(1) failed: {completed.stderr or completed.stdout}")
            return src.read_text(encoding="utf-8")

    def _apply_search_replace_blocks(self, original: str, patch: str, ratio: float) -> str:
        text = original
        blocks = re.findall(
            r"<<<<<<< SEARCH\n(.*?)\n=======\n(.*?)\n>>>>>>> REPLACE",
            patch,
            flags=re.DOTALL,
        )
        if not blocks:
            raise ToolError("No SEARCH/REPLACE blocks found")
        for old, new in blocks:
            text = self._replace_fuzzy(text, old, new, ratio)
        return text

    def _syntax_check(self, args: Dict[str, Any]) -> str:
        path = self._resolve(args["path"])
        if not path.exists():
            raise ToolError(f"File not found: {path}")
        suffix = path.suffix.lower()
        if suffix == ".py":
            try:
                py_compile.compile(str(path), doraise=True)
                return f"syntax_ok python {path}"
            except py_compile.PyCompileError as exc:
                return f"syntax_error python {path}\n{exc}"
        if suffix in {".js", ".mjs", ".cjs", ".ts"}:
            node = shutil.which("node")
            if not node:
                return f"syntax_skipped {path} (node not found)"
            completed = subprocess.run(
                [node, "--check", str(path)],
                capture_output=True,
                text=True,
            )
            if completed.returncode == 0:
                return f"syntax_ok node {path}"
            return f"syntax_error node {path}\n{completed.stderr or completed.stdout}"
        return f"syntax_skipped {path} (no checker for {suffix or 'unknown'})"

    def _find_symbol(self, args: Dict[str, Any]) -> str:
        name = str(args.get("name") or "").strip()
        if not name:
            raise ToolError("name is required")
        kind = str(args.get("kind") or "any")
        root = self._resolve(args["path"]) if args.get("path") else self.settings.workspace
        matches: List[str] = []
        files = [root] if root.is_file() else list(root.rglob("*.py"))
        for file_path in files:
            if not file_path.is_file():
                continue
            if any(part in {".git", "node_modules", "__pycache__", ".venv", "dist"} for part in file_path.parts):
                continue
            try:
                source = file_path.read_text(encoding="utf-8")
                tree = ast.parse(source)
            except (OSError, SyntaxError, UnicodeDecodeError):
                continue
            for node in ast.walk(tree):
                found = None
                if isinstance(node, ast.FunctionDef) and node.name == name:
                    found = "method" if self._is_method(tree, node) else "function"
                elif isinstance(node, ast.AsyncFunctionDef) and node.name == name:
                    found = "method" if self._is_method(tree, node) else "function"
                elif isinstance(node, ast.ClassDef) and node.name == name:
                    found = "class"
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id == name:
                            found = "assignment"
                if found and (kind == "any" or kind == found):
                    lineno = getattr(node, "lineno", 1)
                    matches.append(f"{file_path}:{lineno} [{found}] {name}")
        if not matches:
            return f"No symbols named '{name}'"
        return "\n".join(matches[:200])

    @staticmethod
    def _is_method(tree: ast.AST, fn: ast.AST) -> bool:
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and fn in node.body:
                return True
        return False

    def _repo_map(self, args: Dict[str, Any]) -> str:
        root = self._resolve(args["path"]) if args.get("path") else self.settings.workspace
        max_files = int(args.get("max_files") or 400)
        max_depth = int(args.get("max_depth") or 8)
        skip = {".git", "node_modules", "__pycache__", ".venv", "dist", "build", ".omni_agent"}
        rows: List[str] = [f"repo_map {root}"]
        count = 0
        for dirpath, dirnames, filenames in os.walk(root):
            rel_dir = Path(dirpath).relative_to(root)
            depth = 0 if str(rel_dir) == "." else len(rel_dir.parts)
            if depth > max_depth:
                dirnames[:] = []
                continue
            dirnames[:] = [d for d in dirnames if d not in skip and not d.startswith(".")]
            for filename in sorted(filenames):
                if filename.startswith("."):
                    continue
                path = Path(dirpath) / filename
                rel = path.relative_to(root)
                symbols = self._top_symbols(path)
                suffix = f"  :: {', '.join(symbols)}" if symbols else ""
                rows.append(f"{rel}{suffix}")
                count += 1
                if count >= max_files:
                    rows.append(f"... truncated after {max_files} files")
                    return "\n".join(rows)
        rows.append(f"{count} files")
        return "\n".join(rows)

    def _top_symbols(self, path: Path) -> List[str]:
        if path.suffix != ".py" or path.stat().st_size > 400_000:
            return []
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (OSError, SyntaxError, UnicodeDecodeError):
            return []
        names: List[str] = []
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                names.append(f"class {node.name}")
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                names.append(f"def {node.name}")
            if len(names) >= 8:
                break
        return names

    def _fetch_url(self, args: Dict[str, Any]) -> str:
        url = str(args.get("url") or "").strip()
        if not url:
            raise ToolError("url is required")
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ToolError("Only http/https URLs with a hostname are allowed")
        self._validate_fetch_host(parsed.hostname)
        max_chars = max(1, min(int(args.get("max_chars") or 20_000), self.settings.max_tool_output_chars))
        request = urllib.request.Request(
            url,
            headers={"User-Agent": "omni-agent/2.0"},
        )
        with urllib.request.urlopen(request, timeout=self.settings.fetch_timeout) as response:
            final_host = urllib.parse.urlparse(response.geturl()).hostname
            if final_host:
                self._validate_fetch_host(final_host)
            content_type = response.headers.get("Content-Type", "")
            raw = response.read(max_chars * 4)
        text = raw.decode("utf-8", errors="replace")
        if "application/json" in content_type:
            try:
                pretty = json.dumps(json.loads(text), indent=2, ensure_ascii=False)
                return pretty[:max_chars]
            except json.JSONDecodeError:
                return text[:max_chars]
        if "html" in content_type or text.lstrip().startswith("<"):
            extractor = _HTMLTextExtractor()
            extractor.feed(text)
            return extractor.text()[:max_chars]
        return text[:max_chars]

    def _validate_fetch_host(self, hostname: str) -> None:
        if self.settings.allow_private_fetch:
            return
        try:
            infos = socket.getaddrinfo(hostname, None, type=socket.SOCK_STREAM)
        except socket.gaierror as exc:
            raise ToolError(f"Could not resolve host: {hostname}") from exc
        for info in infos:
            address = info[4][0]
            ip = ipaddress.ip_address(address)
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
                raise ToolError(f"Blocked private/reserved network target: {hostname} -> {address}")

    def _daemon_control(self, args: Dict[str, Any]) -> str:
        action = str(args.get("action") or "")
        name = str(args.get("name") or "default")
        if action == "start":
            command = str(args.get("command") or "")
            if not command:
                raise ToolError("command is required to start a daemon")
            if self.settings.is_dangerous(command):
                raise ToolError("Blocked dangerous daemon command")
            return json.dumps(self.daemons.start(name, command, args.get("cwd")), indent=2)
        if action in {"stop", "kill"}:
            return json.dumps(self.daemons.stop(name, kill=action == "kill"), indent=2)
        if action == "status":
            return json.dumps(self.daemons.status(args.get("name")), indent=2)
        if action == "logs":
            return self.daemons.logs(name, tail=int(args.get("tail") or 80), stream=str(args.get("stream") or "stdout"))
        raise ToolError(f"Unknown daemon action: {action}")

    def _manage_tasks(self, args: Dict[str, Any]) -> str:
        action = str(args.get("action") or "")
        if action == "create":
            title = str(args.get("title") or "").strip()
            if not title:
                raise ToolError("title is required")
            return json.dumps(self.tasks.create(title, str(args.get("detail") or ""), str(args.get("priority") or "normal")), indent=2)
        if action == "update":
            return json.dumps(
                self.tasks.update(
                    str(args.get("id") or ""),
                    title=args.get("title"),
                    detail=args.get("detail"),
                    priority=args.get("priority"),
                    status=args.get("status"),
                ),
                indent=2,
            )
        if action == "complete":
            return json.dumps(self.tasks.update(str(args.get("id") or ""), status="complete"), indent=2)
        if action == "cancel":
            return json.dumps(self.tasks.update(str(args.get("id") or ""), status="cancelled"), indent=2)
        if action == "list":
            return json.dumps(self.tasks.list(args.get("status")), indent=2)
        raise ToolError(f"Unknown task action: {action}")

    def _select_best_option(self, args: Dict[str, Any]) -> str:
        goal = str(args.get("goal") or "").strip()
        options = args.get("options") or []
        criteria = args.get("criteria") or [
            {"name": "correctness", "weight": 0.35, "higher_is_better": True},
            {"name": "simplicity", "weight": 0.2, "higher_is_better": True},
            {"name": "risk", "weight": 0.2, "higher_is_better": False},
            {"name": "performance", "weight": 0.15, "higher_is_better": True},
            {"name": "maintainability", "weight": 0.1, "higher_is_better": True},
        ]
        if not options:
            raise ToolError("options are required")
        weights = {c["name"]: float(c.get("weight") or 1.0) for c in criteria}
        weight_sum = sum(weights.values()) or 1.0
        polarity = {c["name"]: bool(c.get("higher_is_better", True)) for c in criteria}
        ranked: List[Dict[str, Any]] = []
        for option in options:
            scores = dict(option.get("scores") or {})
            # Heuristic fill-ins from pros/cons counts when scores omitted
            pros = option.get("pros") or []
            cons = option.get("cons") or []
            if "correctness" not in scores:
                scores["correctness"] = 0.6 + 0.05 * len(pros) - 0.04 * len(cons)
            if "simplicity" not in scores:
                scores["simplicity"] = max(0.2, 0.8 - 0.05 * len(cons))
            if "risk" not in scores:
                scores["risk"] = min(0.9, 0.3 + 0.08 * len(cons))
            if "performance" not in scores:
                scores["performance"] = 0.55
            if "maintainability" not in scores:
                scores["maintainability"] = 0.5 + 0.04 * len(pros)
            total = 0.0
            breakdown = {}
            for name, weight in weights.items():
                value = float(scores.get(name, 0.5))
                value = max(0.0, min(1.0, value))
                if not polarity.get(name, True):
                    value = 1.0 - value
                contribution = value * (weight / weight_sum)
                breakdown[name] = round(contribution, 4)
                total += contribution
            ranked.append(
                {
                    "id": option.get("id"),
                    "summary": option.get("summary"),
                    "score": round(total, 4),
                    "breakdown": breakdown,
                    "pros": pros,
                    "cons": cons,
                }
            )
        ranked.sort(key=lambda item: item["score"], reverse=True)
        winner = ranked[0]
        rationale = (
            f"Goal: {goal}\n"
            f"Recommended: {winner['id']} ({winner['score']:.3f}) — {winner['summary']}\n"
            f"Why: highest weighted score across {', '.join(weights)}."
        )
        if len(ranked) > 1:
            rationale += f" Runner-up: {ranked[1]['id']} ({ranked[1]['score']:.3f})."
        return json.dumps({"recommendation": winner["id"], "rationale": rationale, "ranking": ranked}, indent=2)

    def _glob_search(self, args: Dict[str, Any]) -> str:
        pattern = str(args.get("pattern") or "")
        root = self._resolve(args["path"]) if args.get("path") else self.settings.workspace
        matches = [str(p.relative_to(self.settings.workspace)) for p in root.glob(pattern) if p.is_file()]
        if not matches:
            matches = [str(p.relative_to(self.settings.workspace)) for p in root.rglob(pattern) if p.is_file()]
        return "\n".join(matches[:500]) or "No files matched"

    def _grep_search(self, args: Dict[str, Any]) -> str:
        pattern = re.compile(str(args.get("pattern") or ""))
        root = self._resolve(args["path"]) if args.get("path") else self.settings.workspace
        glob_pat = args.get("glob") or "*"
        max_matches = int(args.get("max_matches") or 80)
        hits: List[str] = []
        files = [root] if root.is_file() else root.rglob(glob_pat)
        for path in files:
            if not path.is_file():
                continue
            if any(part in {".git", "node_modules", "__pycache__", ".venv"} for part in path.parts):
                continue
            try:
                if path.stat().st_size > 1_000_000:
                    continue
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for i, line in enumerate(text.splitlines(), 1):
                if pattern.search(line):
                    rel = path.relative_to(self.settings.workspace)
                    hits.append(f"{rel}:{i}:{line.strip()}")
                    if len(hits) >= max_matches:
                        return "\n".join(hits)
        return "\n".join(hits) or "No matches"
