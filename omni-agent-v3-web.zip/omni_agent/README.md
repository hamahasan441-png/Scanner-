# Omni Agent

Production-grade autonomous software engineering agent (`omni_agent`) with provider-safe Anthropic Messages support, resilient streaming, bounded tool execution, safe compaction, and performance-aware concurrency.

The framework talks to the AgentRouter Anthropic-compatible proxy with live SSE streaming, extended thinking (`thinking_delta`), model auto-discovery, and auto-continuation on `max_tokens`.

## Package layout

| Module | Responsibility |
| --- | --- |
| `config.py` | Environment, endpoints, token budgets, dangerous-command patterns |
| `client.py` | Resilient HTTP + SSE, retries, thinking blocks, `/v1/models` |
| `tools.py` | Tool registry: bash, files, fuzzy patch, AST search, repo map, fetch, daemons, tasks, trade-offs |
| `memory.py` | Compaction, session JSON, base64 images, `CLAUDE.md` / `AGENT.md` injection |
| `diagnostics.py` | `git stash create` checkpoints and `/undo` rollback |
| `test_runner.py` | Detect tests, capture logs, iterate patches until green |
| `agent.py` | Tool-use loop with compaction, bounded rounds, and continuation safety |
| `cli.py` | REPL, history, slash commands |

## Protocol

- Base URL: `ANTHROPIC_BASE_URL` or `https://agentrouter.org`
- Messages: `/v1/messages`
- Models: `/v1/models`
- Headers: `Authorization`, `x-api-key`, `anthropic-version: 2023-06-01`, `anthropic-beta: claude-code-20250219,interleaved-thinking-2025-05-14`, `x-app: cli`, `User-Agent: claude-cli/2.1.158 (external, sdk-cli)`

## Environment

| Variable | Purpose |
| --- | --- |
| `ANTHROPIC_AUTH_TOKEN` | Bearer and x-api-key token |
| `ANTHROPIC_BASE_URL` | Proxy origin |
| `OMNI_MODEL` | Preferred model id |
| `OMNI_MAX_TOKENS` | Completion budget |
| `OMNI_THINKING_BUDGET` | Extended thinking budget |
| `OMNI_ALLOW_DANGEROUS` | Permit blocked shell patterns |
| `OMNI_SESSION_DIR` | Persistence directory |

## Slash commands

`/test` `/plan` `/image` `/commit` `/undo` `/diff` `/stats` `/clear` `/model` `/help` `/exit`

## Tools

`bash` `read_file` `write_file` `apply_patch` `syntax_check` `find_symbol` `repo_map` `fetch_url` `daemon_control` `manage_tasks` `select_best_option` `glob_search` `grep_search`

`apply_patch` uses exact then difflib fuzzy matching. `syntax_check` runs `py_compile` or `node --check`. `find_symbol` walks Python ASTs. `select_best_option` ranks weighted trade-offs.

## Provider-safe defaults

- Default AgentRouter Anthropic endpoint is `https://co.agentrouter.org` (Anthropic Messages; no `/v1` in the configured base URL).
- Uses standard Anthropic authentication headers without pretending to be the official Claude Code client.
- Does not bypass provider authentication, rate limits, safety controls, or access controls.
- Retries only transport/provider failures that are explicitly retryable; streaming responses are not duplicated after content has started.
- Automatic continuation is disabled for partial tool calls, preventing malformed tool-use transcripts.

## Performance and security upgrades

- Model discovery is cached with TTL and output-token limits are honored when advertised by the provider.
- Streaming read timeout follows the configured SSE idle timeout.
- Independent read-only tool calls can execute concurrently while mutating tools remain ordered.
- Context compaction preserves user-turn/tool-result boundaries.
- Web fetch blocks private/reserved network targets by default to reduce SSRF risk.
- Tool output is bounded and API error previews redact the configured API key.

### New environment variables

`OMNI_MAX_TOOL_WORKERS`, `OMNI_MODEL_CACHE_SECONDS`, `OMNI_FETCH_TIMEOUT`, `OMNI_ALLOW_PRIVATE_FETCH`, and `OMNI_USER_AGENT`.
