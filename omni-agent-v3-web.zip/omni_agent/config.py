"""Environment configuration, API endpoints, token constraints, and safety patterns."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Pattern, Sequence


DEFAULT_BASE_URL = "https://co.agentrouter.org"
DEFAULT_ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_ANTHROPIC_BETA = "interleaved-thinking-2025-05-14"
DEFAULT_USER_AGENT = "omni-agent/2.0"

DEFAULT_MODEL_CANDIDATES: Sequence[str] = (
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "claude-opus-4-5",
    "claude-sonnet-4-5",
    "claude-opus-4-1",
    "claude-sonnet-4",
    "claude-3-7-sonnet-latest",
    "claude-3-5-sonnet-latest",
)

DEFAULT_MAX_TOKENS = 16_384
DEFAULT_THINKING_BUDGET = 10_240
DEFAULT_COMPACTION_THRESHOLD = 96_000
DEFAULT_COMPACTION_KEEP = 24
DEFAULT_REQUEST_TIMEOUT = 300.0
DEFAULT_CONNECT_TIMEOUT = 20.0
DEFAULT_MAX_RETRIES = 6
DEFAULT_RETRY_BASE_SECONDS = 1.25
DEFAULT_RETRY_MAX_SECONDS = 32.0
DEFAULT_STREAM_IDLE_TIMEOUT = 90.0
DEFAULT_MAX_CONTINUATIONS = 8
DEFAULT_MAX_TOOL_ROUNDS = 80
DEFAULT_TOOL_TIMEOUT = 120.0
DEFAULT_MAX_TOOL_OUTPUT_CHARS = 60_000
DEFAULT_MAX_TOOL_WORKERS = 4
DEFAULT_MODEL_CACHE_SECONDS = 600
DEFAULT_FETCH_TIMEOUT = 20.0
DEFAULT_ALLOW_PRIVATE_FETCH = False
DEFAULT_SESSION_DIRNAME = ".omni_agent"
DEFAULT_HISTORY_FILE = "history"
DEFAULT_SESSION_FILE = "session.json"
DEFAULT_TASKS_FILE = "tasks.json"
DEFAULT_DAEMONS_FILE = "daemons.json"
DEFAULT_CHECKPOINTS_FILE = "checkpoints.json"

RETRYABLE_STATUS_CODES = frozenset({408, 409, 425, 429, 500, 502, 503, 504, 529})

DANGEROUS_COMMAND_PATTERNS: Sequence[str] = (
    r"\brm\s+(-[a-zA-Z]*f[a-zA-Z]*\s+)*(/\s*($|\s)|/\*|~|/home|/Users|/var|/usr|/etc|/boot)",
    r"\bmkfs(\.\w+)?\b",
    r"\bdd\s+if=",
    r":\(\)\s*\{\s*:\s*\|\s*:\s*&\s*;\s*\}",
    r"\bchmod\s+-R\s+777\s+/",
    r"\bchown\s+-R\s+[^\n]+?\s+/\s*$",
    r"\b(shutdown|reboot|halt|poweroff)\b",
    r"\b(mkfs|fdisk|parted|diskpart)\b",
    r">\s*/dev/sd[a-z]",
    r"\bcurl\b[^\n]*\|\s*(ba)?sh\b",
    r"\bwget\b[^\n]*\|\s*(ba)?sh\b",
    r"\bgit\s+push\b[^\n]*--force[^\n]*\b(main|master)\b",
    r"\bgit\s+reset\s+--hard\b",
    r"\bDROP\s+(DATABASE|SCHEMA|TABLE)\b",
    r"\bTRUNCATE\s+TABLE\b",
    r"\bsudo\s+rm\b",
    r"\bkill\s+-9\s+1\b",
    r"\biptables\s+-F\b",
    r"\bfork\s*\(\s*\)\s*while",
    r"\bnc\s+-l\b[^\n]*-e\b",
    r"\bpython\s+-c\s+['\"]import\s+socket[^\n]*subprocess",
)

COMPILED_DANGEROUS_PATTERNS: List[Pattern[str]] = [
    re.compile(p, re.IGNORECASE | re.MULTILINE) for p in DANGEROUS_COMMAND_PATTERNS
]

PROJECT_RULE_FILENAMES: Sequence[str] = (
    "CLAUDE.md",
    "AGENT.md",
    "AGENTS.md",
    "OMNI.md",
    ".omni_agent/rules.md",
)


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return float(raw)
    except ValueError:
        return default


@dataclass
class Settings:
    """Runtime configuration resolved from the process environment."""

    auth_token: str = ""
    base_url: str = DEFAULT_BASE_URL
    model: str = ""
    max_tokens: int = DEFAULT_MAX_TOKENS
    thinking_budget: int = DEFAULT_THINKING_BUDGET
    enable_thinking: bool = True
    compaction_threshold: int = DEFAULT_COMPACTION_THRESHOLD
    compaction_keep: int = DEFAULT_COMPACTION_KEEP
    request_timeout: float = DEFAULT_REQUEST_TIMEOUT
    connect_timeout: float = DEFAULT_CONNECT_TIMEOUT
    max_retries: int = DEFAULT_MAX_RETRIES
    retry_base_seconds: float = DEFAULT_RETRY_BASE_SECONDS
    retry_max_seconds: float = DEFAULT_RETRY_MAX_SECONDS
    stream_idle_timeout: float = DEFAULT_STREAM_IDLE_TIMEOUT
    max_continuations: int = DEFAULT_MAX_CONTINUATIONS
    max_tool_rounds: int = DEFAULT_MAX_TOOL_ROUNDS
    tool_timeout: float = DEFAULT_TOOL_TIMEOUT
    max_tool_output_chars: int = DEFAULT_MAX_TOOL_OUTPUT_CHARS
    max_tool_workers: int = DEFAULT_MAX_TOOL_WORKERS
    model_cache_seconds: float = DEFAULT_MODEL_CACHE_SECONDS
    fetch_timeout: float = DEFAULT_FETCH_TIMEOUT
    allow_private_fetch: bool = DEFAULT_ALLOW_PRIVATE_FETCH
    workspace: Path = field(default_factory=lambda: Path.cwd())
    session_dir: Path = field(default_factory=lambda: Path.cwd() / DEFAULT_SESSION_DIRNAME)
    allow_dangerous: bool = False
    extra_headers: Dict[str, str] = field(default_factory=dict)

    @property
    def messages_url(self) -> str:
        base = self.base_url.rstrip("/")
        if base.lower().endswith("/v1"):
            base = base[:-3].rstrip("/")
        return f"{base}/v1/messages"

    @property
    def models_url(self) -> str:
        base = self.base_url.rstrip("/")
        if base.lower().endswith("/v1"):
            base = base[:-3].rstrip("/")
        return f"{base}/v1/models"

    @property
    def history_path(self) -> Path:
        return self.session_dir / DEFAULT_HISTORY_FILE

    @property
    def session_path(self) -> Path:
        return self.session_dir / DEFAULT_SESSION_FILE

    @property
    def tasks_path(self) -> Path:
        return self.session_dir / DEFAULT_TASKS_FILE

    @property
    def daemons_path(self) -> Path:
        return self.session_dir / DEFAULT_DAEMONS_FILE

    @property
    def checkpoints_path(self) -> Path:
        return self.session_dir / DEFAULT_CHECKPOINTS_FILE

    def client_headers(self) -> Dict[str, str]:
        token = self.auth_token
        headers = {
            "Authorization": f"Bearer {token}",
            "x-api-key": token,
            "anthropic-version": DEFAULT_ANTHROPIC_VERSION,
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "User-Agent": os.getenv("OMNI_USER_AGENT", DEFAULT_USER_AGENT),
        }
        if DEFAULT_ANTHROPIC_BETA:
            headers["anthropic-beta"] = DEFAULT_ANTHROPIC_BETA
        headers.update(self.extra_headers)
        return headers

    def ensure_session_dir(self) -> Path:
        self.session_dir.mkdir(parents=True, exist_ok=True)
        return self.session_dir

    def is_dangerous(self, command: str) -> bool:
        if self.allow_dangerous:
            return False
        return any(p.search(command) for p in COMPILED_DANGEROUS_PATTERNS)


def load_settings(workspace: str | Path | None = None) -> Settings:
    """Load settings from environment variables and optional workspace path."""
    root = Path(workspace).resolve() if workspace else Path.cwd().resolve()
    token = (
        os.getenv("ANTHROPIC_AUTH_TOKEN")
        or os.getenv("ANTHROPIC_API_KEY")
        or os.getenv("AGENTROUTER_API_KEY")
        or ""
    ).strip()
    base_url = os.getenv("ANTHROPIC_BASE_URL", DEFAULT_BASE_URL).strip() or DEFAULT_BASE_URL
    session_dir = Path(os.getenv("OMNI_SESSION_DIR", str(root / DEFAULT_SESSION_DIRNAME))).resolve()
    return Settings(
        auth_token=token,
        base_url=base_url.rstrip("/"),
        model=os.getenv("OMNI_MODEL", os.getenv("ANTHROPIC_MODEL", "")).strip(),
        max_tokens=_env_int("OMNI_MAX_TOKENS", DEFAULT_MAX_TOKENS),
        thinking_budget=_env_int("OMNI_THINKING_BUDGET", DEFAULT_THINKING_BUDGET),
        enable_thinking=_env_bool("OMNI_ENABLE_THINKING", True),
        compaction_threshold=_env_int("OMNI_COMPACTION_THRESHOLD", DEFAULT_COMPACTION_THRESHOLD),
        compaction_keep=_env_int("OMNI_COMPACTION_KEEP", DEFAULT_COMPACTION_KEEP),
        request_timeout=_env_float("OMNI_REQUEST_TIMEOUT", DEFAULT_REQUEST_TIMEOUT),
        connect_timeout=_env_float("OMNI_CONNECT_TIMEOUT", DEFAULT_CONNECT_TIMEOUT),
        max_retries=_env_int("OMNI_MAX_RETRIES", DEFAULT_MAX_RETRIES),
        retry_base_seconds=_env_float("OMNI_RETRY_BASE", DEFAULT_RETRY_BASE_SECONDS),
        retry_max_seconds=_env_float("OMNI_RETRY_MAX", DEFAULT_RETRY_MAX_SECONDS),
        stream_idle_timeout=_env_float("OMNI_STREAM_IDLE_TIMEOUT", DEFAULT_STREAM_IDLE_TIMEOUT),
        max_continuations=_env_int("OMNI_MAX_CONTINUATIONS", DEFAULT_MAX_CONTINUATIONS),
        max_tool_rounds=_env_int("OMNI_MAX_TOOL_ROUNDS", DEFAULT_MAX_TOOL_ROUNDS),
        tool_timeout=_env_float("OMNI_TOOL_TIMEOUT", DEFAULT_TOOL_TIMEOUT),
        max_tool_output_chars=_env_int("OMNI_MAX_TOOL_OUTPUT", DEFAULT_MAX_TOOL_OUTPUT_CHARS),
        max_tool_workers=_env_int("OMNI_MAX_TOOL_WORKERS", DEFAULT_MAX_TOOL_WORKERS),
        model_cache_seconds=_env_float("OMNI_MODEL_CACHE_SECONDS", DEFAULT_MODEL_CACHE_SECONDS),
        fetch_timeout=_env_float("OMNI_FETCH_TIMEOUT", DEFAULT_FETCH_TIMEOUT),
        allow_private_fetch=_env_bool("OMNI_ALLOW_PRIVATE_FETCH", DEFAULT_ALLOW_PRIVATE_FETCH),
        workspace=root,
        session_dir=session_dir,
        allow_dangerous=_env_bool("OMNI_ALLOW_DANGEROUS", False),
    )
