"""Git snapshot checkpoints and instant rollback for the /undo command."""

from __future__ import annotations

import json
import logging
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import Settings, load_settings

logger = logging.getLogger("omni_agent.diagnostics")


class DiagnosticsError(RuntimeError):
    pass


@dataclass
class Checkpoint:
    id: str
    created_at: float
    label: str
    method: str
    ref: str
    files: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "created_at": self.created_at,
            "label": self.label,
            "method": self.method,
            "ref": self.ref,
            "files": self.files,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "Checkpoint":
        return cls(
            id=str(payload.get("id") or ""),
            created_at=float(payload.get("created_at") or 0),
            label=str(payload.get("label") or ""),
            method=str(payload.get("method") or ""),
            ref=str(payload.get("ref") or ""),
            files=list(payload.get("files") or []),
        )


class Diagnostics:
    """Create restore points with `git stash create` and roll them back."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self._history: List[Checkpoint] = []
        self._load()

    def _load(self) -> None:
        path = self.settings.checkpoints_path
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                items = payload if isinstance(payload, list) else payload.get("checkpoints", [])
                self._history = [Checkpoint.from_dict(item) for item in items]
            except json.JSONDecodeError:
                self._history = []

    def _save(self) -> None:
        self.settings.ensure_session_dir()
        self.settings.checkpoints_path.write_text(
            json.dumps([item.to_dict() for item in self._history], indent=2),
            encoding="utf-8",
        )

    def _git(self, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args],
            cwd=str(self.settings.workspace),
            capture_output=True,
            text=True,
            check=check,
        )

    def is_git_repo(self) -> bool:
        result = self._git("rev-parse", "--is-inside-work-tree", check=False)
        return result.returncode == 0 and result.stdout.strip() == "true"

    def snapshot(self, label: str = "omni-checkpoint") -> Checkpoint:
        """Create a checkpoint. Prefers `git stash create` so the working tree is untouched."""
        created_at = time.time()
        ident = f"{int(created_at)}-{label.replace(' ', '-')[:24]}"
        files = self.changed_files()
        if self.is_git_repo():
            self._git("add", "-A", check=False)
            created = self._git("stash", "create", label, check=False)
            ref = created.stdout.strip()
            if created.returncode != 0 or not ref:
                # Fall back to a stash push that we immediately apply to restore the tree.
                pushed = self._git("stash", "push", "-u", "-m", label, check=False)
                if pushed.returncode != 0:
                    raise DiagnosticsError(pushed.stderr or "git stash push failed")
                ref = self._git("rev-parse", "stash@{0}").stdout.strip()
                self._git("stash", "apply", "stash@{0}", check=False)
            method = "git-stash-create"
        else:
            archive_dir = self.settings.session_dir / "snapshots" / ident
            archive_dir.mkdir(parents=True, exist_ok=True)
            self._copy_workspace(archive_dir)
            ref = str(archive_dir)
            method = "filesystem"
        checkpoint = Checkpoint(
            id=ident,
            created_at=created_at,
            label=label,
            method=method,
            ref=ref,
            files=files,
        )
        self._history.append(checkpoint)
        self._save()
        logger.info("Checkpoint %s via %s (%s)", checkpoint.id, method, ref)
        return checkpoint

    def undo(self, checkpoint_id: str | None = None) -> Checkpoint:
        if not self._history:
            raise DiagnosticsError("No checkpoints to undo")
        checkpoint = self._history[-1]
        if checkpoint_id:
            found = next((item for item in reversed(self._history) if item.id == checkpoint_id), None)
            if not found:
                raise DiagnosticsError(f"Unknown checkpoint: {checkpoint_id}")
            checkpoint = found
        if checkpoint.method.startswith("git"):
            if not self.is_git_repo():
                raise DiagnosticsError("Not a git repository; cannot restore git checkpoint")
            result = self._git("stash", "show", "-p", checkpoint.ref, check=False)
            apply = self._git("checkout", checkpoint.ref, "--", ".", check=False)
            if apply.returncode != 0:
                apply = self._git("stash", "apply", checkpoint.ref, check=False)
            if apply.returncode != 0:
                raise DiagnosticsError(apply.stderr or result.stderr or "Failed to restore checkpoint")
            self._git("reset", "HEAD", check=False)
        else:
            archive = Path(checkpoint.ref)
            if not archive.exists():
                raise DiagnosticsError(f"Snapshot directory missing: {archive}")
            self._restore_workspace(archive)
        logger.info("Rolled back to checkpoint %s", checkpoint.id)
        return checkpoint

    def diff(self) -> str:
        if self.is_git_repo():
            staged = self._git("diff", "--stat", check=False).stdout
            unstaged = self._git("diff", "--stat", "HEAD", check=False).stdout
            return (unstaged or staged or "Working tree clean").strip()
        files = self.changed_files()
        return "\n".join(files) if files else "No tracked changes (non-git workspace)"

    def changed_files(self) -> List[str]:
        if not self.is_git_repo():
            return []
        result = self._git("status", "--porcelain", check=False)
        files = []
        for line in result.stdout.splitlines():
            path = line[3:].strip()
            if " -> " in path:
                path = path.split(" -> ", 1)[1]
            if path:
                files.append(path)
        return files

    def history(self) -> List[Checkpoint]:
        return list(self._history)

    def _copy_workspace(self, dest: Path) -> None:
        skip = {".git", ".omni_agent", "node_modules", "__pycache__", ".venv", "dist"}
        root = self.settings.workspace
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            if any(part in skip for part in rel.parts):
                continue
            target = dest / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())

    def _restore_workspace(self, archive: Path) -> None:
        skip = {".git", ".omni_agent", "node_modules", "__pycache__", ".venv", "dist"}
        root = self.settings.workspace
        for path in archive.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(archive)
            if any(part in skip for part in rel.parts):
                continue
            target = root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())
