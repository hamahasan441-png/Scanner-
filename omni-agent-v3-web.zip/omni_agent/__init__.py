"""Omni Agent — production-grade autonomous software engineering framework."""

from .agent import OmniAgent, TurnResult
from .client import AgentRouterClient, AgentRouterError, StreamMessage
from .config import Settings, load_settings
from .diagnostics import Checkpoint, Diagnostics
from .memory import MemoryStore, SessionState
from .test_runner import TestReport, TestRunner
from .tools import ToolRegistry, ToolResult

__version__ = "2.0.0"
__all__ = [
    "OmniAgent",
    "TurnResult",
    "AgentRouterClient",
    "AgentRouterError",
    "StreamMessage",
    "Settings",
    "load_settings",
    "Checkpoint",
    "Diagnostics",
    "MemoryStore",
    "SessionState",
    "TestReport",
    "TestRunner",
    "ToolRegistry",
    "ToolResult",
    "__version__",
]
