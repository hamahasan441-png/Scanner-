"""Interactive REPL with command history and slash-command routing."""

from __future__ import annotations

import argparse
import logging
import os
import shlex
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

from .agent import OmniAgent, TurnResult
from .config import Settings, load_settings
from .diagnostics import Diagnostics
from .memory import MemoryStore, estimate_messages_tokens
from .test_runner import TestRunner

try:
    import readline  # noqa: F401
except ImportError:  # pragma: no cover - Windows
    readline = None  # type: ignore[assignment]


logger = logging.getLogger("omni_agent.cli")

SLASH_COMMANDS = {
    "/help": "Show available slash commands",
    "/test": "Run the autonomous self-healing test runner",
    "/plan": "Ask the agent for an implementation plan without editing",
    "/image": "Attach an image to the next prompt: /image path/to/file.png prompt...",
    "/commit": "Create a git commit from the current diff",
    "/undo": "Roll back to the last checkpoint",
    "/diff": "Show the working tree diff",
    "/stats": "Print session statistics",
    "/clear": "Clear conversation memory",
    "/model": "Show or set the active model: /model [name]",
    "/exit": "Leave the REPL",
}


class OmniREPL:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self.settings.ensure_session_dir()
        self._configure_logging()
        self.memory = MemoryStore(self.settings)
        self.diagnostics = Diagnostics(self.settings)
        self.agent = OmniAgent(
            settings=self.settings,
            memory=self.memory,
            diagnostics=self.diagnostics,
            on_event=self._on_event,
        )
        self.tests = TestRunner(
            settings=self.settings,
            tools=self.agent.tools,
            diagnostics=self.diagnostics,
            fixer=self._heal_fixer,
        )
        self._setup_history()

    def _configure_logging(self) -> None:
        logging.basicConfig(
            level=os.getenv("OMNI_LOG_LEVEL", "INFO"),
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        )

    def _setup_history(self) -> None:
        if readline is None:
            return
        history = str(self.settings.history_path)
        try:
            readline.read_history_file(history)
        except FileNotFoundError:
            pass
        readline.set_history_length(1000)
        self._history_path = history

    def _save_history(self) -> None:
        if readline is None:
            return
        try:
            readline.write_history_file(getattr(self, "_history_path", str(self.settings.history_path)))
        except OSError:
            pass

    def _on_event(self, kind: str, payload: Dict[str, Any]) -> None:
        if kind == "thinking_delta":
            sys.stdout.write("")
            sys.stdout.flush()
        elif kind == "content_block_delta":
            delta = payload.get("delta") or {}
            if delta.get("type") == "text_delta":
                sys.stdout.write(str(delta.get("text") or ""))
                sys.stdout.flush()
        elif kind == "tool_round":
            print(f"\n[tools] round {payload.get('round')} ({payload.get('count')} calls)")
        elif kind == "tool_result":
            name = payload.get("tool_use_id")
            flag = "error" if payload.get("is_error") else "ok"
            preview = str(payload.get("content") or "").splitlines()[:1]
            print(f"[tool {flag}] {name} {preview[0][:120] if preview else ''}")

    def run_forever(self) -> int:
        print("Omni Agent REPL. Type /help for commands, /exit to quit.")
        if not self.settings.auth_token:
            print("Warning: ANTHROPIC_AUTH_TOKEN is not set. Network calls will fail.")
        try:
            while True:
                try:
                    raw = input("omni> ").strip()
                except EOFError:
                    print()
                    break
                if not raw:
                    continue
                if raw.startswith("/"):
                    if self._dispatch_slash(raw):
                        break
                    continue
                self._chat(raw)
        finally:
            self._save_history()
        return 0

    def _dispatch_slash(self, raw: str) -> bool:
        parts = shlex.split(raw)
        command = parts[0]
        args = parts[1:]
        if command in {"/exit", "/quit"}:
            return True
        handlers = {
            "/help": self._cmd_help,
            "/test": self._cmd_test,
            "/plan": self._cmd_plan,
            "/image": self._cmd_image,
            "/commit": self._cmd_commit,
            "/undo": self._cmd_undo,
            "/diff": self._cmd_diff,
            "/stats": self._cmd_stats,
            "/clear": self._cmd_clear,
            "/model": self._cmd_model,
        }
        handler = handlers.get(command)
        if handler is None:
            print(f"Unknown command {command}. Try /help")
            return False
        try:
            handler(args)
        except Exception as exc:  # noqa: BLE001
            print(f"Command failed: {exc}")
            logger.debug(traceback.format_exc())
        return False

    def _cmd_help(self, _args: List[str]) -> None:
        width = max(len(k) for k in SLASH_COMMANDS)
        for name, desc in SLASH_COMMANDS.items():
            print(f"{name.ljust(width)}  {desc}")

    def _cmd_test(self, args: List[str]) -> None:
        command = args or None
        print("Running self-healing test loop...")
        report = self.tests.heal(command=command, max_attempts=5)
        print(report.log_text())
        print("PASS" if report.passed else "FAIL")

    def _heal_fixer(self, log_text: str, report: Any) -> Optional[str]:
        prompt = (
            "The test suite failed. Inspect the log, edit the repository with tools, "
            "and stop when you believe tests will pass. Do not explain at length.\n\n"
            f"{log_text}"
        )
        result = self.agent.run(prompt, snapshot=False)
        return result.text or "attempted-fix"

    def _cmd_plan(self, args: List[str]) -> None:
        prompt = " ".join(args) or "Plan the next implementation steps for this repository."
        result = self.agent.plan(prompt)
        self._print_result(result)

    def _cmd_image(self, args: List[str]) -> None:
        if not args:
            print("Usage: /image path/to/file.png [prompt]")
            return
        image = args[0]
        prompt = " ".join(args[1:]) or "Describe this image and apply any implied engineering task."
        result = self.agent.run(prompt, images=[image])
        self._print_result(result)

    def _cmd_commit(self, args: List[str]) -> None:
        message = " ".join(args) or "chore: omni agent checkpoint"
        diff = self.diagnostics.diff()
        print(diff)
        self.agent.tools.execute("bash", {"command": "git add -A"})
        quoted = message.replace('"', '\\"')
        result = self.agent.tools.execute("bash", {"command": f'git commit -m "{quoted}"'})
        print(result.output)

    def _cmd_undo(self, args: List[str]) -> None:
        ident = args[0] if args else None
        checkpoint = self.diagnostics.undo(ident)
        print(f"Restored checkpoint {checkpoint.id} ({checkpoint.method})")

    def _cmd_diff(self, _args: List[str]) -> None:
        print(self.diagnostics.diff())

    def _cmd_stats(self, _args: List[str]) -> None:
        tokens = estimate_messages_tokens(self.memory.state.messages)
        print(f"model: {self.memory.state.model or self.agent.client.resolve_model()}")
        print(f"messages: {len(self.memory.state.messages)}")
        print(f"estimated_tokens: {tokens}")
        print(f"turns: {self.agent.stats['turns']}")
        print(f"tool_calls: {self.agent.stats['tool_calls']}")
        print(f"errors: {self.agent.stats['errors']}")
        print(f"input_tokens: {self.agent.stats['input_tokens']}")
        print(f"output_tokens: {self.agent.stats['output_tokens']}")
        print(f"checkpoints: {len(self.diagnostics.history())}")

    def _cmd_clear(self, _args: List[str]) -> None:
        self.memory.clear()
        print("Session memory cleared")

    def _cmd_model(self, args: List[str]) -> None:
        if not args:
            try:
                models = self.agent.client.discover_models()
            except Exception as exc:  # noqa: BLE001
                print(f"Could not list models: {exc}")
                models = []
            current = self.memory.state.model or self.settings.model or "(auto)"
            print(f"current: {current}")
            for item in models[:40]:
                ident = item.get("id") if isinstance(item, dict) else item
                print(f"- {ident}")
            return
        resolved = self.agent.set_model(args[0])
        print(f"model set to {resolved}")

    def _chat(self, prompt: str) -> None:
        try:
            result = self.agent.run(prompt)
            self._print_result(result)
        except Exception as exc:  # noqa: BLE001
            print(f"\nAgent error: {exc}")
            logger.debug(traceback.format_exc())

    def _print_result(self, result: TurnResult) -> None:
        if result.text and not result.text.endswith("\n"):
            print()
        if result.thinking:
            print(f"\n[thinking {len(result.thinking)} chars]")
        print(f"[stop={result.stop_reason} tools={result.tool_rounds} {result.duration_ms}ms]")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="omni_agent", description="Omni autonomous engineering agent")
    parser.add_argument("prompt", nargs="*", help="Optional one-shot prompt")
    parser.add_argument("--workspace", default=None, help="Workspace root")
    parser.add_argument("--model", default=None, help="Model id override")
    parser.add_argument("--repl", action="store_true", help="Force interactive REPL")
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    settings = load_settings(args.workspace)
    repl = OmniREPL(settings)
    if args.model:
        repl.agent.set_model(args.model)
    if args.prompt and not args.repl:
        result = repl.agent.run(" ".join(args.prompt))
        if result.text:
            print(result.text)
        return 0
    return repl.run_forever()
