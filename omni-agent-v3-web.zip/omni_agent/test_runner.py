"""Autonomous self-healing test runner that iterates until tests pass."""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

from .config import Settings, load_settings
from .diagnostics import Diagnostics
from .tools import ToolRegistry

logger = logging.getLogger("omni_agent.test_runner")

FixCallback = Callable[[str, "TestReport"], Optional[str]]


@dataclass
class TestReport:
    command: List[str]
    passed: bool
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int
    failures: List[str] = field(default_factory=list)
    attempts: int = 1

    def log_text(self) -> str:
        parts = [
            f"command: {' '.join(self.command)}",
            f"exit_code: {self.exit_code}",
            f"duration_ms: {self.duration_ms}",
            f"passed: {self.passed}",
        ]
        if self.stdout:
            parts.append("stdout:\n" + self.stdout)
        if self.stderr:
            parts.append("stderr:\n" + self.stderr)
        if self.failures:
            parts.append("failures:\n- " + "\n- ".join(self.failures))
        return "\n".join(parts)


class TestRunner:
    """Detect, execute, and optionally self-heal a project's test suite."""

    def __init__(
        self,
        settings: Settings | None = None,
        tools: ToolRegistry | None = None,
        diagnostics: Diagnostics | None = None,
        fixer: FixCallback | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        self.tools = tools or ToolRegistry(self.settings)
        self.diagnostics = diagnostics or Diagnostics(self.settings)
        self.fixer = fixer

    def detect_command(self, explicit: Sequence[str] | None = None) -> List[str]:
        if explicit:
            return list(explicit)
        env_cmd = os.getenv("OMNI_TEST_COMMAND")
        if env_cmd:
            return env_cmd.split()
        root = self.settings.workspace
        if (root / "pyproject.toml").exists() or (root / "pytest.ini").exists() or list(root.glob("test_*.py")):
            if (root / "pyproject.toml").exists() or (root / "pytest.ini").exists() or (root / "tests").exists():
                return ["python", "-m", "pytest", "-q"]
        if (root / "package.json").exists():
            try:
                payload = json.loads((root / "package.json").read_text(encoding="utf-8"))
                scripts = payload.get("scripts") or {}
                if "test" in scripts:
                    return ["npm", "test", "--silent"]
            except json.JSONDecodeError:
                pass
        if (root / "Cargo.toml").exists():
            return ["cargo", "test"]
        if (root / "go.mod").exists():
            return ["go", "test", "./..."]
        python_tests = list(root.rglob("test_*.py"))
        if python_tests:
            return ["python", "-m", "unittest", "discover", "-q"]
        raise RuntimeError("Could not detect a test command. Pass one explicitly.")

    def run(self, command: Sequence[str] | None = None, timeout: float | None = None) -> TestReport:
        cmd = self.detect_command(command)
        started = time.monotonic()
        completed = subprocess.run(
            cmd,
            cwd=str(self.settings.workspace),
            capture_output=True,
            text=True,
            timeout=timeout or max(self.settings.tool_timeout, 180.0),
            env=os.environ.copy(),
        )
        duration_ms = int((time.monotonic() - started) * 1000)
        stdout = completed.stdout or ""
        stderr = completed.stderr or ""
        failures = self.parse_failures(stdout + "\n" + stderr)
        report = TestReport(
            command=cmd,
            passed=completed.returncode == 0,
            exit_code=completed.returncode,
            stdout=stdout,
            stderr=stderr,
            duration_ms=duration_ms,
            failures=failures,
        )
        log_path = self._write_log(report)
        logger.info("Tests %s (log %s)", "passed" if report.passed else "failed", log_path)
        return report

    def heal(
        self,
        command: Sequence[str] | None = None,
        max_attempts: int = 5,
        fixer: FixCallback | None = None,
    ) -> TestReport:
        """Run tests, apply patches via fixer, and iterate until passing or attempts exhausted."""
        callback = fixer or self.fixer
        last: Optional[TestReport] = None
        checkpoint = None
        try:
            checkpoint = self.diagnostics.snapshot(label="pre-heal")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not snapshot before heal: %s", exc)
        for attempt in range(1, max_attempts + 1):
            report = self.run(command)
            report.attempts = attempt
            last = report
            if report.passed:
                return report
            if callback is None:
                return report
            logger.info("Heal attempt %s/%s with %s failure(s)", attempt, max_attempts, len(report.failures))
            patch_or_note = callback(report.log_text(), report)
            if not patch_or_note:
                logger.info("Fixer declined to patch; stopping")
                return report
            self._apply_fixer_output(patch_or_note)
        assert last is not None
        if checkpoint and not last.passed:
            logger.warning("Heal failed; leaving last patches in place (undo via diagnostics)")
        return last

    def parse_failures(self, log: str) -> List[str]:
        failures: List[str] = []
        patterns = [
            re.compile(r"^E\s+.+$", re.MULTILINE),
            re.compile(r"FAIL:\s+.+$", re.MULTILINE),
            re.compile(r"FAILED\s+\S+"),
            re.compile(r"AssertionError:.*"),
            re.compile(r"Error:\s+.+$", re.MULTILINE),
            re.compile(r"●\s+.+$", re.MULTILINE),
        ]
        for pattern in patterns:
            for match in pattern.findall(log):
                text = match.strip()
                if text and text not in failures:
                    failures.append(text)
        return failures[:50]

    def _apply_fixer_output(self, output: str) -> None:
        text = output.strip()
        if text.startswith("{") and text.endswith("}"):
            try:
                payload = json.loads(text)
            except json.JSONDecodeError:
                payload = None
            if isinstance(payload, dict) and payload.get("path"):
                if payload.get("old_text") is not None and payload.get("new_text") is not None:
                    self.tools.execute(
                        "apply_patch",
                        {
                            "path": payload["path"],
                            "old_text": payload["old_text"],
                            "new_text": payload["new_text"],
                        },
                    )
                    return
                if payload.get("content") is not None:
                    self.tools.execute("write_file", {"path": payload["path"], "content": payload["content"]})
                    return
        if "<<<<<<< SEARCH" in text or "@@" in text:
            path_match = re.search(r"^(?:\+\+\+|---|\*\*\* Update File:)\s+([^\s]+)", text, re.MULTILINE)
            if path_match:
                rel = path_match.group(1)
                rel = re.sub(r"^[ab]/", "", rel)
                self.tools.execute("apply_patch", {"path": rel, "patch": text})
                return
        logger.info("Fixer output treated as note only")

    def _write_log(self, report: TestReport) -> Path:
        log_dir = self.settings.session_dir / "test-logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        path = log_dir / f"test-{int(time.time())}.log"
        path.write_text(report.log_text(), encoding="utf-8")
        return path
