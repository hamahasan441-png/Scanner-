from setuptools import find_packages, setup

setup(
    name="omni_agent",
    version="2.0.0",
    description="Production-grade autonomous software engineering agent framework",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Omni Agent",
    license="MIT",
    packages=find_packages(exclude=("tests", "tests.*")),
    python_requires=">=3.10",
    install_requires=["requests>=2.31.0"],
    entry_points={"console_scripts": ["omni-agent=omni_agent.cli:main", "omni_agent=omni_agent.cli:main"]},
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Topic :: Software Development :: Libraries",
    ],
)
