import { createFileRoute } from "@tanstack/react-router";
import { ToolCatalog } from "@/components/tool-catalog";

export const Route = createFileRoute("/tools")({ component: ToolsPage });

function ToolsPage() {
  return <ToolCatalog />;
}
