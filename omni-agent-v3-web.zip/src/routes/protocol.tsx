import { createFileRoute } from "@tanstack/react-router";
import { ProtocolSpec } from "@/components/protocol-spec";

export const Route = createFileRoute("/protocol")({ component: ProtocolPage });

function ProtocolPage() {
  return <ProtocolSpec />;
}
