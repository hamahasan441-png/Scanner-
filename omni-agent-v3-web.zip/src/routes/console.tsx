import { createFileRoute } from "@tanstack/react-router";
import { AgentConsole } from "@/components/agent-console";

export const Route = createFileRoute("/console")({ component: ConsolePage });

function ConsolePage() {
  return <AgentConsole />;
}
