import { createFileRoute } from "@tanstack/react-router";
import { ArchitectureMap } from "@/components/architecture-map";

export const Route = createFileRoute("/architecture")({ component: ArchitecturePage });

function ArchitecturePage() {
  return <ArchitectureMap />;
}
