import { createFileRoute } from "@tanstack/react-router";
import { FileWorkspace } from "@/components/file-workspace";

export const Route = createFileRoute("/workspace")({ component: WorkspacePage });

function WorkspacePage() {
  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="text-4xl sm:text-5xl">Workspace</h1>
      <p className="mt-3 max-w-2xl text-muted">Upload and stage files for an agent session. Files remain in the browser until your application explicitly sends them to a backend.</p>
      <div className="mt-8"><FileWorkspace /></div>
    </div>
  );
}
