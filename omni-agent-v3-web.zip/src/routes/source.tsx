import { createFileRoute } from "@tanstack/react-router";
import { SourceExplorer } from "@/components/source-explorer";

export const Route = createFileRoute("/source")({ component: SourcePage });

function SourcePage() {
  return <SourceExplorer />;
}
