export type DemoKind = "thinking" | "text" | "tool" | "result" | "system";

export type DemoEvent = {
  kind: DemoKind;
  text: string;
  name?: string;
  delay: number;
};

export const HELP_TEXT = [
  "/test   self-healing test loop",
  "/plan   implementation plan, no edits",
  "/diff   working tree summary",
  "/undo   restore last checkpoint",
  "/stats  tokens, tools, turns",
  "/model  list discovered models",
  "/clear  reset this console",
  "/help   this list",
].join("\n");

export function eventsFor(input: string): DemoEvent[] {
  const trimmed = input.trim();
  const cmd = trimmed.split(/\s+/)[0];
  if (cmd === "/help") return [{ kind: "system", text: HELP_TEXT, delay: 40 }];
  if (cmd === "/stats") {
    return [
      {
        kind: "system",
        text: "model: claude-sonnet-4-6\nmessages: 12\nestimated_tokens: 18420\nturns: 4\ntool_calls: 17\ncheckpoints: 3",
        delay: 40,
      },
    ];
  }
  if (cmd === "/model") {
    return [
      {
        kind: "system",
        text: "current: claude-sonnet-4-6\n- claude-opus-4-6\n- claude-sonnet-4-6\n- claude-sonnet-4-5",
        delay: 40,
      },
    ];
  }
  if (cmd === "/diff") {
    return [
      {
        kind: "system",
        text: " omni_agent/tools.py | 24 ++++\n tests/test_omni_agent.py |  8 ++\n 2 files changed, 32 insertions(+)",
        delay: 40,
      },
    ];
  }
  if (cmd === "/undo") {
    return [{ kind: "system", text: "Restored checkpoint 1725100000-pre-turn (git-stash-create)", delay: 40 }];
  }
  if (cmd === "/clear") return [{ kind: "system", text: "Session memory cleared", delay: 20 }];
  if (cmd === "/plan" || trimmed.toLowerCase().includes("plan")) return planEvents(trimmed);
  if (cmd === "/test" || trimmed.toLowerCase().includes("test")) return healEvents();
  return defaultEvents(trimmed);
}

function planEvents(prompt: string): DemoEvent[] {
  return [
    { kind: "thinking", text: "Inspect layout, then list a sequence that avoids extra abstractions.", delay: 18 },
    {
      kind: "tool",
      name: "repo_map",
      text: 'repo_map .\nomni_agent/agent.py  :: class OmniAgent, def run\nomni_agent/tools.py  :: class ToolRegistry\ntests/test_omni_agent.py',
      delay: 12,
    },
    {
      kind: "text",
      text:
        "Plan for: " +
        (prompt.replace(/^\/plan\s*/, "") || "next implementation steps") +
        "\n\n1. Read agent.py and tools.py.\n2. Add a failing test first.\n3. Patch with apply_patch, then syntax_check.\n4. Run /test and keep the git checkpoint from diagnostics.snapshot.",
      delay: 10,
    },
  ];
}

function healEvents(): DemoEvent[] {
  return [
    { kind: "thinking", text: "Tests failed on greet(). Read the file, patch, re-run.", delay: 16 },
    {
      kind: "tool",
      name: "bash",
      text: "exit_code: 1\nFAILED tests/test_omni_agent.py::ToolTests::test_fuzzy_patch_and_symbol",
      delay: 10,
    },
    {
      kind: "tool",
      name: "apply_patch",
      text: "Patched mod.py\n-    return 'hi ' + name\n+    return f'hello {name}'\nsyntax_ok python mod.py",
      delay: 12,
    },
    {
      kind: "tool",
      name: "syntax_check",
      text: "syntax_ok python mod.py",
      delay: 8,
    },
    {
      kind: "result",
      name: "test_runner",
      text: "attempt 2/5  passed=true  duration_ms=412",
      delay: 10,
    },
    { kind: "text", text: "Suite is green. Checkpoint pre-heal remains available via /undo.", delay: 10 },
  ];
}

function defaultEvents(prompt: string): DemoEvent[] {
  return [
    { kind: "thinking", text: `Need a repo map before touching files for: ${prompt.slice(0, 80)}`, delay: 16 },
    {
      kind: "tool",
      name: "find_symbol",
      text: "omni_agent/agent.py:36 [class] OmniAgent\nomni_agent/agent.py:64 [function] run",
      delay: 12,
    },
    {
      kind: "tool",
      name: "select_best_option",
      text: '{\n  "recommendation": "apply_patch",\n  "rationale": "Prefer a minimal fuzzy patch over rewriting the file."\n}',
      delay: 12,
    },
    {
      kind: "text",
      text: "I would snapshot with git stash create, apply a focused patch, syntax-check, then let the test runner iterate. Open Source to read the real loop in agent.py.",
      delay: 10,
    },
  ];
}
