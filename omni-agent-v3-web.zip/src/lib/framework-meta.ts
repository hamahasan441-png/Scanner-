export const APP_NAME = "OMNI";

export const MODULES = [
  {
    id: "config",
    file: "omni_agent/config.py",
    title: "Config",
    summary: "Environment, AgentRouter endpoints, token budgets, dangerous-command patterns.",
  },
  {
    id: "client",
    file: "omni_agent/client.py",
    title: "Client",
    summary: "Resilient HTTP, SSE streaming, thinking_delta, model discovery, max_tokens continuation.",
  },
  {
    id: "tools",
    file: "omni_agent/tools.py",
    title: "Tools",
    summary: "Registry with fuzzy patches, AST search, repo maps, daemons, tasks, and trade-off scoring.",
  },
  {
    id: "memory",
    file: "omni_agent/memory.py",
    title: "Memory",
    summary: "Session JSON, context compaction, base64 images, CLAUDE.md / AGENT.md injection.",
  },
  {
    id: "diagnostics",
    file: "omni_agent/diagnostics.py",
    title: "Diagnostics",
    summary: "git stash create checkpoints and instant /undo rollback.",
  },
  {
    id: "test_runner",
    file: "omni_agent/test_runner.py",
    title: "Test runner",
    summary: "Detects the suite, captures logs, applies patches, iterates until green.",
  },
  {
    id: "agent",
    file: "omni_agent/agent.py",
    title: "Agent loop",
    summary: "Stream → tool_use → execute → compact → continue until end_turn.",
  },
  {
    id: "cli",
    file: "omni_agent/cli.py",
    title: "REPL",
    summary: "Interactive shell with history and slash-command routing.",
  },
] as const;

export const TOOLS = [
  { name: "bash", group: "exec", summary: "Workspace shell with dangerous-pattern blocking." },
  { name: "read_file", group: "fs", summary: "Numbered reads with offset/limit slicing." },
  { name: "write_file", group: "fs", summary: "Atomic write plus automatic syntax check." },
  { name: "apply_patch", group: "fs", summary: "Unified diff or search/replace with difflib fuzzy match." },
  { name: "syntax_check", group: "verify", summary: "py_compile for Python, node --check for JS/TS." },
  { name: "find_symbol", group: "nav", summary: "AST walk for functions, classes, methods, assignments." },
  { name: "repo_map", group: "nav", summary: "Compact file tree with top-level Python symbols." },
  { name: "grep_search", group: "nav", summary: "Regex content search with glob filters." },
  { name: "glob_search", group: "nav", summary: "Filename glob under the workspace root." },
  { name: "fetch_url", group: "net", summary: "HTTP fetch with HTML stripping and JSON pretty-print." },
  { name: "daemon_control", group: "ops", summary: "Start, stop, status, and tailed logs for background jobs." },
  { name: "manage_tasks", group: "ops", summary: "Persistent task tracker for multi-step work." },
  { name: "select_best_option", group: "reason", summary: "Weighted trade-off evaluator with ranked rationale." },
] as const;

export const SLASH = [
  { cmd: "/test", detail: "Self-healing test loop" },
  { cmd: "/plan", detail: "Implementation plan, no edits" },
  { cmd: "/image", detail: "Attach a multimodal image" },
  { cmd: "/commit", detail: "Commit the current diff" },
  { cmd: "/undo", detail: "Restore last checkpoint" },
  { cmd: "/diff", detail: "Working tree summary" },
  { cmd: "/stats", detail: "Tokens, tools, turns" },
  { cmd: "/clear", detail: "Reset session memory" },
  { cmd: "/model", detail: "Discover or set model" },
] as const;

export const HEADERS = [
  { key: "Authorization", value: "Bearer <ANTHROPIC_AUTH_TOKEN>" },
  { key: "x-api-key", value: "<ANTHROPIC_AUTH_TOKEN>" },
  { key: "anthropic-version", value: "2023-06-01" },
  { key: "anthropic-beta", value: "claude-code-20250219,interleaved-thinking-2025-05-14" },
  { key: "x-app", value: "cli" },
  { key: "User-Agent", value: "claude-cli/2.1.158 (external, sdk-cli)" },
  { key: "Content-Type", value: "application/json" },
] as const;

export const EVENTS = [
  { type: "message_start", detail: "Stream opens with model, id, usage" },
  { type: "content_block_start", detail: "thinking | text | tool_use" },
  { type: "thinking_delta", detail: "Extended thinking tokens" },
  { type: "text_delta", detail: "Visible assistant text" },
  { type: "input_json_delta", detail: "Partial tool arguments" },
  { type: "message_delta", detail: "stop_reason, usage" },
  { type: "message_stop", detail: "end_turn | tool_use | max_tokens" },
] as const;

export const NAV = [
  { to: "/", label: "Overview", short: "Home" },
  { to: "/architecture", label: "Architecture", short: "Arch" },
  { to: "/source", label: "Source", short: "Source" },
  { to: "/tools", label: "Tools", short: "Tools" },
  { to: "/console", label: "Console", short: "REPL" },
  { to: "/workspace", label: "Workspace", short: "Files" },
  { to: "/protocol", label: "Protocol", short: "Spec" },
] as const;
