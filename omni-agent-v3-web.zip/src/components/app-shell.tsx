import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { NAV } from "@/lib/framework-meta";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-7xl">
        <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border px-5 py-8 md:flex">
          <Link to="/" className="mb-10 block">
            <p className="font-display text-3xl leading-none text-fg">OMNI</p>
            <p className="mt-2 font-mono text-xs uppercase tracking-widest text-muted">
              Control plane
            </p>
          </Link>
          <nav className="flex flex-1 flex-col gap-1">
            {NAV.map((item) => {
              const active = pathname === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "rounded-sm px-3 py-2.5 text-sm transition-colors duration-150",
                    active ? "bg-elevated text-fg" : "text-muted hover:bg-surface hover:text-fg",
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <a
            href="/omni_agent_framework.zip"
            download
            className="mt-6 inline-flex h-11 items-center justify-center gap-2 rounded-sm bg-accent px-3 text-sm font-medium text-accent-fg"
          >
            <Download className="size-4" />
            Package
          </a>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex items-center justify-between border-b border-border px-4 py-3 md:hidden">
            <Link to="/" className="font-display text-2xl">
              OMNI
            </Link>
            <a
              href="/omni_agent_framework.zip"
              download
              className="inline-flex h-11 w-11 items-center justify-center rounded-sm border border-border"
              aria-label="Download package"
            >
              <Download className="size-4" />
            </a>
          </header>
          <main className="flex-1 px-4 py-8 pb-24 sm:px-8 sm:py-10 md:pb-10">{children}</main>
          <nav className="sticky bottom-0 grid grid-cols-3 gap-1 border-t border-border bg-bg/95 px-2 py-2 backdrop-blur md:hidden">
            {NAV.map((item) => {
              const active = pathname === item.to;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex min-h-11 items-center justify-center rounded-sm px-1 text-center font-mono text-xs uppercase tracking-wide whitespace-nowrap",
                    active ? "bg-elevated text-fg" : "text-muted",
                  )}
                >
                  {item.short}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>
    </div>
  );
}
