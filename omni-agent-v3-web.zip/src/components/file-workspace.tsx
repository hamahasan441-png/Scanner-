import { useCallback, useRef, useState } from "react";
import { FileUp, FileText, Image as ImageIcon, X, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export type UploadedFile = {
  id: string;
  file: File;
  preview?: string;
  text?: string;
};

const TEXT_EXTENSIONS = /\.(txt|md|markdown|json|yaml|yml|xml|csv|tsv|js|jsx|tsx|ts|py|java|kt|go|rs|rb|php|css|scss|html|htm|sql|sh|bash|toml|ini|env)$/i;
const MAX_TEXT_BYTES = 2 * 1024 * 1024;

export function FileWorkspace({ onFiles }: { onFiles?: (files: UploadedFile[]) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState("");

  const addFiles = useCallback(async (incoming: File[]) => {
    setError("");
    const accepted = incoming.filter(Boolean);
    const next: UploadedFile[] = [];
    for (const file of accepted) {
      try {
        const item: UploadedFile = { id: `${file.name}:${file.size}:${file.lastModified}:${crypto.randomUUID()}`, file };
        if (file.type.startsWith("image/") && file.size <= 8 * 1024 * 1024) {
          item.preview = URL.createObjectURL(file);
        } else if (TEXT_EXTENSIONS.test(file.name) || file.type.startsWith("text/")) {
          if (file.size <= MAX_TEXT_BYTES) item.text = await file.text();
        }
        next.push(item);
      } catch {
        setError(`Could not read ${file.name}. The file is still available as an upload.`);
        next.push({ id: `${file.name}:${file.size}:${file.lastModified}`, file });
      }
    }
    setFiles((current) => {
      const merged = [...current, ...next];
      onFiles?.(merged);
      return merged;
    });
  }, [onFiles]);

  function remove(id: string) {
    setFiles((current) => {
      const item = current.find((f) => f.id === id);
      if (item?.preview) URL.revokeObjectURL(item.preview);
      const next = current.filter((f) => f.id !== id);
      onFiles?.(next);
      return next;
    });
  }

  return (
    <section className="rounded-xl border border-border bg-surface">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div>
          <p className="font-mono text-xs uppercase tracking-wide text-muted">workspace files</p>
          <p className="mt-1 text-xs text-subtle">Attach source, documents, images, logs, and datasets to the agent session.</p>
        </div>
        <Button type="button" variant="outline" className="h-10" onClick={() => inputRef.current?.click()}>
          <FileUp className="mr-2 size-4" /> Add files
        </Button>
      </div>

      <input
        ref={inputRef}
        type="file"
        multiple
        className="hidden"
        onChange={(e) => {
          void addFiles(Array.from(e.target.files ?? []));
          e.currentTarget.value = "";
        }}
      />

      <div
        role="button"
        tabIndex={0}
        onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") inputRef.current?.click(); }}
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => { e.preventDefault(); setDragging(false); void addFiles(Array.from(e.dataTransfer.files)); }}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "mx-4 my-4 flex min-h-32 cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed px-5 text-center transition-colors",
          dragging ? "border-accent bg-elevated" : "border-border hover:bg-elevated",
        )}
      >
        <FileUp className="size-6 text-muted" />
        <p className="mt-3 text-sm text-fg">Drop files here or click to browse</p>
        <p className="mt-1 text-xs text-subtle">Multiple files supported · text files are indexed locally</p>
      </div>

      {error && <p className="px-4 pb-3 text-xs text-amber-400">{error}</p>}

      {files.length > 0 && (
        <div className="border-t border-border divide-y divide-border">
          {files.map((item) => (
            <div key={item.id} className="flex items-center gap-3 px-4 py-3">
              {item.preview ? <img src={item.preview} alt="" className="size-10 rounded object-cover" /> : item.file.type.startsWith("image/") ? <ImageIcon className="size-5 text-muted" /> : <FileText className="size-5 text-muted" />}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm">{item.file.name}</p>
                <p className="font-mono text-[11px] text-subtle">{formatBytes(item.file.size)} · {item.file.type || "unknown type"}{item.text !== undefined ? " · indexed" : ""}</p>
              </div>
              {item.text !== undefined && <CheckCircle2 className="size-4 text-sage" aria-label="Indexed" />}
              <button type="button" onClick={() => remove(item.id)} className="rounded p-2 text-subtle hover:bg-elevated hover:text-fg" aria-label={`Remove ${item.file.name}`}><X className="size-4" /></button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB"];
  let value = bytes / 1024;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) { value /= 1024; unit += 1; }
  return `${value.toFixed(value >= 10 ? 0 : 1)} ${units[unit]}`;
}
