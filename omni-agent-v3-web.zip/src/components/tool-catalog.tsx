import { TOOLS, SLASH } from "@/lib/framework-meta";

const GROUPS: Record<string, string> = {
  exec: "Execution",
  fs: "Filesystem",
  verify: "Verification",
  nav: "Navigation",
  net: "Network",
  ops: "Operations",
  reason: "Reasoning",
};

export function ToolCatalog() {
  const groups = Array.from(new Set(TOOLS.map((t) => t.group)));
  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="text-4xl sm:text-5xl">Tools</h1>
      <p className="mt-3 max-w-2xl text-muted">
        Every tool returns clipped text, records duration, and is exposed to the model as an Anthropic JSON schema.
      </p>
      <div className="mt-10 space-y-10">
        {groups.map((group) => (
          <section key={group}>
            <h2 className="font-mono text-xs uppercase tracking-wide text-muted">{GROUPS[group]}</h2>
            <ul className="mt-3 grid gap-3 sm:grid-cols-2">
              {TOOLS.filter((t) => t.group === group).map((tool) => (
                <li key={tool.name} className="rounded-lg border border-border bg-surface p-5">
                  <p className="font-mono text-sm text-sage">{tool.name}</p>
                  <p className="mt-2 text-sm text-muted">{tool.summary}</p>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
      <section className="mt-12">
        <h2 className="text-2xl">Slash commands</h2>
        <ul className="mt-4 divide-y divide-border rounded-lg border border-border bg-surface">
          {SLASH.map((item) => (
            <li key={item.cmd} className="flex items-center justify-between gap-4 px-5 py-4">
              <span className="font-mono text-sm">{item.cmd}</span>
              <span className="text-sm text-muted">{item.detail}</span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
