import { Link } from "@tanstack/react-router";
import { MODULES } from "@/lib/framework-meta";

const FLOW = [
  { from: "cli.py", via: "slash commands", to: "agent.py" },
  { from: "agent.py", via: "messages + tools", to: "client.py" },
  { from: "client.py", via: "SSE /v1/messages", to: "AgentRouter" },
  { from: "agent.py", via: "tool_use", to: "tools.py" },
  { from: "agent.py", via: "compact / persist", to: "memory.py" },
  { from: "agent.py", via: "stash create", to: "diagnostics.py" },
  { from: "cli.py", via: "/test", to: "test_runner.py" },
];

export function ArchitectureMap() {
  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="text-4xl sm:text-5xl">Architecture</h1>
      <p className="mt-3 max-w-2xl text-muted">
        Eight modules, one loop. The client never blocks the tool registry; memory
        and diagnostics sit beside the turn, not inside the HTTP layer.
      </p>

      <div className="mt-8 overflow-x-auto rounded-xl border border-border bg-surface p-4 sm:p-6">
        <div className="sm:min-w-full">
          <div className="grid grid-cols-4 gap-3">
            {["REPL", "Loop", "Transport", "Effects"].map((label) => (
              <p key={label} className="font-mono text-xs uppercase tracking-wide text-muted">
                {label}
              </p>
            ))}
            {["cli.py", "agent.py", "client.py", "tools.py"].map((file) => (
              <div key={file} className="rounded-md border border-border bg-bg px-3 py-4">
                <p className="font-mono text-sm">{file}</p>
              </div>
            ))}
            <div className="rounded-md border border-border bg-bg px-3 py-4">
              <p className="font-mono text-sm">config.py</p>
            </div>
            <div className="rounded-md border border-border bg-bg px-3 py-4">
              <p className="font-mono text-sm">memory.py</p>
            </div>
            <div className="rounded-md border border-border-strong bg-elevated px-3 py-4">
              <p className="font-mono text-sm">AgentRouter</p>
              <p className="mt-1 font-mono text-xs text-muted">/v1/messages</p>
            </div>
            <div className="rounded-md border border-border bg-bg px-3 py-4">
              <p className="font-mono text-sm">diagnostics.py</p>
              <p className="mt-1 font-mono text-xs text-muted">test_runner.py</p>
            </div>
          </div>
        </div>
      </div>

      <ul className="mt-8 space-y-2">
        {FLOW.map((edge) => (
          <li
            key={`${edge.from}-${edge.to}`}
            className="flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b border-border py-3 font-mono text-sm"
          >
            <span>{edge.from}</span>
            <span className="text-subtle">{edge.via}</span>
            <span className="text-sage">→ {edge.to}</span>
          </li>
        ))}
      </ul>

      <div className="mt-10 grid gap-3 sm:grid-cols-2">
        {MODULES.map((mod) => (
          <Link
            key={mod.id}
            to="/source"
            className="rounded-lg border border-border bg-surface p-5 transition-colors duration-150 hover:bg-elevated"
          >
            <p className="font-mono text-xs text-muted">{mod.file}</p>
            <p className="mt-2 text-lg font-medium">{mod.title}</p>
            <p className="mt-1 text-sm text-muted">{mod.summary}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
