import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { MODULES, TOOLS } from "@/lib/framework-meta";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const STATS = [
  { label: "Modules", value: String(MODULES.length) },
  { label: "Tools", value: String(TOOLS.length) },
  { label: "Protocol", value: "SSE" },
  { label: "Thinking", value: "On" },
];

export function Overview() {
  return (
    <div className="mx-auto max-w-4xl">
      <div className="rounded-xl border border-border bg-surface p-6 sm:p-10">
        <div className="rounded-lg border border-border bg-bg px-5 py-8 sm:px-10 sm:py-12">
          <Badge>AgentRouter · Anthropic messages</Badge>
          <h1 className="mt-6 max-w-xl text-4xl text-fg sm:text-6xl">
            Autonomous software engineering, instrumented.
          </h1>
          <p className="mt-5 max-w-xl text-base text-muted sm:text-lg">
            Omni is a modular Python agent: live SSE streaming, extended thinking,
            fuzzy patches, git checkpoints, and a self-healing test loop.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button asChild>
              <Link to="/console">
                Open console
                <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/architecture">Inspect architecture</Link>
            </Button>
          </div>
        </div>
      </div>

      <dl className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {STATS.map((stat) => (
          <div key={stat.label} className="rounded-lg border border-border bg-surface px-4 py-4">
            <dt className="font-mono text-xs uppercase tracking-wide text-muted">{stat.label}</dt>
            <dd className="mt-1 font-display text-3xl tabular-nums">{stat.value}</dd>
          </div>
        ))}
      </dl>

      <section className="mt-12">
        <h2 className="text-2xl">Loop</h2>
        <ol className="mt-5 grid gap-3 sm:grid-cols-2">
          {[
            ["01", "Prompt", "REPL injects project rules from CLAUDE.md / AGENT.md."],
            ["02", "Think", "Extended thinking streams as thinking_delta blocks."],
            ["03", "Act", "Tool calls execute against the workspace with syntax checks."],
            ["04", "Heal", "Tests run; failures patch and retry until green or budget."],
          ].map(([n, title, copy]) => (
            <li key={n} className="rounded-lg border border-border bg-surface p-5">
              <p className="font-mono text-xs text-sage">{n}</p>
              <p className="mt-2 text-lg font-medium">{title}</p>
              <p className="mt-1 text-sm text-muted">{copy}</p>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
