import { EVENTS, HEADERS } from "@/lib/framework-meta";

export function ProtocolSpec() {
  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="text-4xl sm:text-5xl">Protocol</h1>
      <p className="mt-3 max-w-2xl text-muted">
        AgentRouter proxy, Anthropic Messages API, Server-Sent Events. Headers are exact.
      </p>

      <section className="mt-10">
        <h2 className="text-2xl">Endpoints</h2>
        <ul className="mt-4 divide-y divide-border rounded-lg border border-border bg-surface font-mono text-sm">
          <li className="px-5 py-4">
            <span className="text-muted">BASE</span>
            <p className="mt-1">https://agentrouter.org</p>
          </li>
          <li className="px-5 py-4">
            <span className="text-muted">POST</span>
            <p className="mt-1">/v1/messages</p>
          </li>
          <li className="px-5 py-4">
            <span className="text-muted">GET</span>
            <p className="mt-1">/v1/models</p>
          </li>
        </ul>
      </section>

      <section className="mt-10">
        <h2 className="text-2xl">Headers</h2>
        <ul className="mt-4 divide-y divide-border rounded-lg border border-border bg-surface">
          {HEADERS.map((row) => (
            <li key={row.key} className="grid gap-1 px-5 py-4 sm:grid-cols-[200px_minmax(0,1fr)]">
              <span className="font-mono text-sm text-sage">{row.key}</span>
              <span className="font-mono text-sm text-muted">{row.value}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-10">
        <h2 className="text-2xl">Stream events</h2>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {EVENTS.map((ev) => (
            <li key={ev.type} className="rounded-lg border border-border bg-surface p-5">
              <p className="font-mono text-sm">{ev.type}</p>
              <p className="mt-2 text-sm text-muted">{ev.detail}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
