import { useMemo, useState } from "react";
import { FRAMEWORK_SOURCE } from "@/lib/framework-source";
import { cn } from "@/lib/utils";

const FILES = Object.keys(FRAMEWORK_SOURCE).sort();

export function SourceExplorer({ initialFile }: { initialFile?: string }) {
  const start = initialFile && FRAMEWORK_SOURCE[initialFile] ? initialFile : "omni_agent/agent.py";
  const [active, setActive] = useState(start);
  const source = FRAMEWORK_SOURCE[active] ?? "";
  const lines = useMemo(() => source.split("\n"), [source]);

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="text-4xl sm:text-5xl">Source</h1>
      <p className="mt-3 max-w-2xl text-muted">
        Complete package, no stubs. Select a module to read the implementation that ships in the zip.
      </p>
      <div className="mt-8 grid gap-4 lg:grid-cols-4">
        <div className="rounded-lg border border-border bg-surface p-2 lg:col-span-1">
          <ul className="max-h-56 overflow-auto lg:max-h-screen">
            {FILES.map((file) => (
              <li key={file}>
                <button
                  type="button"
                  onClick={() => setActive(file)}
                  className={cn(
                    "flex min-h-11 w-full items-center rounded-sm px-3 py-2 text-left font-mono text-xs",
                    active === file ? "bg-elevated text-fg" : "text-muted hover:text-fg",
                  )}
                >
                  {file.replace("omni_agent/", "")}
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div className="overflow-hidden rounded-lg border border-border bg-bg lg:col-span-3">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <p className="truncate font-mono text-xs text-muted">{active}</p>
            <p className="font-mono text-xs tabular-nums text-subtle">{lines.length} lines</p>
          </div>
            <pre className="max-h-screen overflow-auto p-4 font-mono text-xs leading-5 text-fg">
            {lines.map((line, i) => (
              <div key={i} className="flex gap-4">
                <span className="w-8 shrink-0 select-none text-right text-subtle tabular-nums">
                  {i + 1}
                </span>
                <span className="whitespace-pre">{line || " "}</span>
              </div>
            ))}
          </pre>
        </div>
      </div>
    </div>
  );
}
