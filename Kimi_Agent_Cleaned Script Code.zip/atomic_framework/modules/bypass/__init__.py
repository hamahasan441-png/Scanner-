# ATOMIC Framework - Bypass Modules
