# ATOMIC Framework - Core Module
