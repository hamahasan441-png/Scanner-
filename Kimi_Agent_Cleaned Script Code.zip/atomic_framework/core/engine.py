#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ATOMIC FRAMEWORK - Core Engine
Main orchestration module
"""

import os
import sys
import time
import json
import hashlib
import random
import threading
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urljoin, urlparse, parse_qs
from typing import List, Dict, Set, Optional, Tuple, Any

# Import config
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import Config, Colors, Payloads, MITRE_CWE_MAP
from utils.database import Database
from utils.requester import Requester
from core.banner import print_section


class Finding:
    """Finding data class"""
    
    def __init__(self, technique: str, url: str, severity: str, 
                 confidence: float = 0.5, param: str = "", 
                 payload: str = "", evidence: str = "",
                 extracted_data: str = ""):
        self.technique = technique
        self.url = url
        self.severity = severity
        self.confidence = confidence
        self.param = param
        self.payload = payload
        self.evidence = evidence
        self.extracted_data = extracted_data
        self.timestamp = datetime.utcnow()
        self.mitre_id, self.cwe_id = MITRE_CWE_MAP.get(technique, ('T1595', 'CWE-0'))
        self.cvss = self._calculate_cvss()
    
    def _calculate_cvss(self) -> float:
        """Calculate CVSS score"""
        scores = {'CRITICAL': 9.0, 'HIGH': 7.5, 'MEDIUM': 5.5, 'LOW': 3.5, 'INFO': 0.0}
        base = scores.get(self.severity.upper(), 5.0)
        return min(10.0, base + (self.confidence * 1.5))
    
    def to_dict(self) -> Dict:
        return {
            'technique': self.technique,
            'url': self.url,
            'severity': self.severity,
            'confidence': self.confidence,
            'param': self.param,
            'payload': self.payload,
            'evidence': self.evidence,
            'extracted_data': self.extracted_data,
            'timestamp': self.timestamp.isoformat(),
            'mitre_id': self.mitre_id,
            'cwe_id': self.cwe_id,
            'cvss': self.cvss,
        }


class AtomicEngine:
    """Main Atomic Framework Engine"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.modules = config.get('modules', {})
        self.scan_id = hashlib.md5(f"{time.time()}{random.randint(1000,9999)}".encode()).hexdigest()[:16]
        
        # Stats
        self.stats = {
            'start_time': datetime.utcnow(),
            'total_requests': 0,
            'findings': {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0, 'INFO': 0},
            'urls_crawled': 0,
            'params_tested': 0,
        }
        
        # Data storage
        self.findings: List[Finding] = []
        self.visited_urls: Set[str] = set()
        self.forms: List[Dict] = []
        self.parameters: List[Tuple] = []
        self.cookies: Dict = {}
        
        # Initialize components
        self.db = Database()
        self.requester = Requester(config)
        
        # Load modules
        self._load_modules()
    
    def _load_modules(self):
        """Dynamically load attack modules"""
        self.exploit_modules = {}
        
        # Import modules based on configuration
        if self.modules.get('sqli'):
            from modules.exploits.sqli import SQLiModule
            self.exploit_modules['sqli'] = SQLiModule(self)
        
        if self.modules.get('xss'):
            from modules.exploits.xss import XSSModule
            self.exploit_modules['xss'] = XSSModule(self)
        
        if self.modules.get('lfi'):
            from modules.exploits.lfi import LFIModule
            self.exploit_modules['lfi'] = LFIModule(self)
        
        if self.modules.get('cmdi'):
            from modules.exploits.cmdi import CommandInjectionModule
            self.exploit_modules['cmdi'] = CommandInjectionModule(self)
        
        if self.modules.get('ssrf'):
            from modules.exploits.ssrf import SSRFModule
            self.exploit_modules['ssrf'] = SSRFModule(self)
        
        if self.modules.get('ssti'):
            from modules.exploits.ssti import SSTIModule
            self.exploit_modules['ssti'] = SSTIModule(self)
        
        if self.modules.get('xxe'):
            from modules.exploits.xxe import XXEModule
            self.exploit_modules['xxe'] = XXEModule(self)
        
        if self.modules.get('idor'):
            from modules.exploits.idor import IDORModule
            self.exploit_modules['idor'] = IDORModule(self)
        
        if self.modules.get('nosql'):
            from modules.exploits.nosqli import NoSQLModule
            self.exploit_modules['nosql'] = NoSQLModule(self)
        
        if self.modules.get('cors'):
            from modules.exploits.cors import CORSModule
            self.exploit_modules['cors'] = CORSModule(self)
        
        if self.modules.get('jwt'):
            from modules.exploits.jwt import JWTModule
            self.exploit_modules['jwt'] = JWTModule(self)
        
        if self.modules.get('upload'):
            from modules.exploits.upload import UploadModule
            self.exploit_modules['upload'] = UploadModule(self)
        
        # Advanced modules
        if self.modules.get('shell'):
            from modules.shell.uploader import ShellUploader
            self.shell_uploader = ShellUploader(self)
        
        if self.modules.get('dump'):
            from modules.dump.dumper import DataDumper
            self.data_dumper = DataDumper(self)
        
        if self.modules.get('waf_bypass'):
            from modules.bypass.waf import WAFBypass
            self.waf_bypass = WAFBypass(self)
        
        # Recon modules
        if self.modules.get('recon'):
            from modules.recon.reconnaissance import ReconModule
            self.recon_module = ReconModule(self)
        
        if self.modules.get('subdomains'):
            from modules.recon.subdomains import SubdomainEnumerator
            self.subdomain_enum = SubdomainEnumerator(self)
        
        if self.modules.get('dir_brute'):
            from modules.recon.dirbrute import DirBruteModule
            self.dir_brute = DirBruteModule(self)
    
    def scan(self, target: str):
        """Main scan function"""
        self.target = target
        self.base_url = target.rstrip('/')
        
        print_section("INITIALIZING SCAN")
        print(f"{Colors.info(f'Scan ID: {self.scan_id}')}")
        print(f"{Colors.info(f'Target: {target}')}")
        print(f"{Colors.info(f'Modules: {list(self.exploit_modules.keys())}')}")
        print(f"{Colors.info(f'Threads: {self.config["threads"]}')}")
        print(f"{Colors.info(f'Evasion: {self.config["evasion"]}')}")
        
        # Phase 1: Reconnaissance
        if self.modules.get('recon') or self.modules.get('subdomains'):
            self._phase_recon()
        
        # Phase 2: Crawling
        self._phase_crawl()
        
        # Phase 3: Attack Execution
        self._phase_attack()
        
        # Phase 4: Exploitation (if enabled)
        if self.modules.get('shell') or self.modules.get('dump'):
            self._phase_exploit()
        
        # Phase 5: Post-processing
        self._phase_post_process()
    
    def _phase_recon(self):
        """Phase 1: Reconnaissance"""
        print_section("PHASE 1: RECONNAISSANCE")
        
        if hasattr(self, 'recon_module'):
            self.recon_module.run(self.target)
        
        if hasattr(self, 'subdomain_enum'):
            self.subdomain_enum.run(self.target)
        
        if hasattr(self, 'dir_brute'):
            self.dir_brute.run(self.target)
    
    def _phase_crawl(self):
        """Phase 2: Web Crawling"""
        print_section("PHASE 2: WEB CRAWLING")
        
        from modules.recon.crawler import Crawler
        crawler = Crawler(self)
        
        urls, forms, params = crawler.crawl(self.target, depth=self.config['depth'])
        
        self.visited_urls = urls
        self.forms = forms
        self.parameters = params
        
        self.stats['urls_crawled'] = len(urls)
        self.stats['params_tested'] = len(params)
        
        print(f"{Colors.success(f'Found {len(urls)} URLs, {len(forms)} forms, {len(params)} parameters')}')
    
    def _phase_attack(self):
        """Phase 3: Attack Execution"""
        print_section("PHASE 3: ATTACK EXECUTION")
        
        # Prepare attack tasks
        tasks = []
        
        # Add URL parameters
        for url, method, param, value, context in self.parameters:
            tasks.append(('param', url, method, param, value, context))
        
        # Add forms
        for form in self.forms:
            for inp in form.get('inputs', []):
                tasks.append(('form', form['url'], form['method'], 
                            inp['name'], inp.get('value', ''), 'form'))
        
        # Add discovered URLs for specific tests
        for url in self.visited_urls:
            tasks.append(('url', url, 'get', '', '', 'url'))
        
        print(f"{Colors.info(f'Total attack tasks: {len(tasks)}')}')
        
        # Execute attacks with thread pool
        max_workers = min(self.config['threads'], len(tasks)) if tasks else 1
        completed = 0
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(self._execute_attack, task): task for task in tasks}
            
            for future in as_completed(futures):
                completed += 1
                if completed % 10 == 0 and not self.config.get('quiet'):
                    print(f"{Colors.info(f'Progress: {completed}/{len(tasks)} tasks completed')}", end='\r')
                
                try:
                    future.result()
                except Exception as e:
                    if self.config.get('verbose'):
                        print(f"{Colors.error(f'Task error: {e}')}")
        
        print(f"\n{Colors.success(f'Attack phase completed. Total findings: {len(self.findings)}')}')
    
    def _execute_attack(self, task):
        """Execute attack on a single target"""
        task_type, url, method, param, value, context = task
        
        # Run all enabled exploit modules
        for name, module in self.exploit_modules.items():
            try:
                if task_type == 'param' or task_type == 'form':
                    module.test(url, method, param, value)
                elif task_type == 'url':
                    module.test_url(url)
            except Exception as e:
                if self.config.get('verbose'):
                    print(f"{Colors.error(f'{name} module error: {e}')}")
    
    def _phase_exploit(self):
        """Phase 4: Advanced Exploitation"""
        print_section("PHASE 4: ADVANCED EXPLOITATION")
        
        # Data dumping
        if self.modules.get('dump') and hasattr(self, 'data_dumper'):
            print(f"{Colors.info('Attempting data extraction...')}')
            self.data_dumper.run(self.findings)
        
        # Shell upload
        if self.modules.get('shell') and hasattr(self, 'shell_uploader'):
            print(f"{Colors.info('Attempting shell upload...')}')
            self.shell_uploader.run(self.findings, self.forms)
    
    def _phase_post_process(self):
        """Phase 5: Post-processing"""
        print_section("PHASE 5: POST-PROCESSING")
        
        # Save findings to database
        for finding in self.findings:
            self.db.save_finding(self.scan_id, finding)
        
        # Save scan metadata
        self.db.save_scan(
            scan_id=self.scan_id,
            target=self.target,
            start_time=self.stats['start_time'],
            end_time=datetime.utcnow(),
            total_requests=self.stats['total_requests'],
            findings_count=len(self.findings),
            config=json.dumps(self.config)
        )
        
        # Print summary
        self._print_summary()
    
    def _print_summary(self):
        """Print scan summary"""
        print_section("SCAN SUMMARY")
        
        print(f"{Colors.BOLD}Scan ID:{Colors.RESET} {self.scan_id}")
        print(f"{Colors.BOLD}Target:{Colors.RESET} {self.target}")
        print(f"{Colors.BOLD}Duration:{Colors.RESET} {datetime.utcnow() - self.stats['start_time']}")
        print(f"{Colors.BOLD}Total Requests:{Colors.RESET} {self.stats['total_requests']}")
        print(f"{Colors.BOLD}URLs Crawled:{Colors.RESET} {self.stats['urls_crawled']}")
        print(f"{Colors.BOLD}Parameters Tested:{Colors.RESET} {self.stats['params_tested']}")
        
        print(f"\n{Colors.BOLD}Findings by Severity:{Colors.RESET}")
        for severity, count in self.stats['findings'].items():
            if count > 0:
                color = Colors.RED if severity == 'CRITICAL' else Colors.YELLOW if severity == 'HIGH' else Colors.CYAN
                print(f"  {color}{severity}:{Colors.RESET} {count}")
        
        print(f"\n{Colors.BOLD}Total Findings:{Colors.RESET} {len(self.findings)}")
    
    def add_finding(self, finding: Finding):
        """Add a finding"""
        self.findings.append(finding)
        self.stats['findings'][finding.severity.upper()] = self.stats['findings'].get(finding.severity.upper(), 0) + 1
        
        # Print finding
        if not self.config.get('quiet'):
            from core.banner import print_finding
            print_finding(finding.severity, finding.technique, finding.url, 
                         finding.param, finding.payload)
    
    def generate_reports(self):
        """Generate all reports"""
        from core.reporter import ReportGenerator
        
        generator = ReportGenerator(self.scan_id)
        generator.generate_all(self.findings, self.stats)
