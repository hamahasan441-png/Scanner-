#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ATOMIC FRAMEWORK - Report Generator Module
"""

import os
import json
import csv
from datetime import datetime
from collections import Counter
from config import Config, Colors


class ReportGenerator:
    """Security Report Generator"""
    
    def __init__(self, scan_id: str):
        self.scan_id = scan_id
        self.reports_dir = Config.REPORTS_DIR
        os.makedirs(self.reports_dir, exist_ok=True)
    
    def generate_all(self, findings: list, stats: dict):
        """Generate all report formats"""
        print(f"{Colors.info('Generating reports...')}")
        
        self.generate_html(findings, stats)
        self.generate_json(findings, stats)
        self.generate_csv(findings, stats)
        self.generate_txt(findings, stats)
        
        print(f"{Colors.success('All reports generated')}")
    
    def generate(self, format: str, findings: list = None, stats: dict = None):
        """Generate specific report format"""
        if format == 'html':
            return self.generate_html(findings, stats)
        elif format == 'json':
            return self.generate_json(findings, stats)
        elif format == 'csv':
            return self.generate_csv(findings, stats)
        elif format == 'pdf':
            return self.generate_pdf(findings, stats)
        elif format == 'txt':
            return self.generate_txt(findings, stats)
    
    def generate_html(self, findings: list, stats: dict) -> str:
        """Generate HTML report"""
        severity_counts = Counter(f.severity for f in findings)
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATOMIC Framework Report - {self.scan_id}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #0a0c10;
            color: #e6edf3;
            line-height: 1.6;
        }}
        .header {{
            background: linear-gradient(135deg, #ff4444, #ff8844);
            padding: 40px;
            text-align: center;
        }}
        .header h1 {{ color: white; font-size: 2.5em; margin-bottom: 10px; }}
        .header p {{ color: rgba(255,255,255,0.9); }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 30px; }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: #161b22;
            border-radius: 16px;
            padding: 25px;
            text-align: center;
            border: 1px solid #30363d;
        }}
        .stat-value {{ font-size: 3em; font-weight: bold; margin-bottom: 10px; }}
        .stat-label {{ color: #8b949e; font-size: 0.9em; text-transform: uppercase; }}
        .critical {{ color: #ff4444; }}
        .high {{ color: #ff8844; }}
        .medium {{ color: #ffdd44; }}
        .low {{ color: #44ff44; }}
        .section {{
            background: #161b22;
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 25px;
            border: 1px solid #30363d;
        }}
        .section h2 {{ color: #f0883e; margin-bottom: 20px; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #30363d;
        }}
        th {{
            background: rgba(240, 136, 62, 0.2);
            color: #f0883e;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85em;
        }}
        tr:hover {{ background: rgba(255,255,255,0.05); }}
        .badge {{
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.75em;
            font-weight: bold;
            text-transform: uppercase;
        }}
        .badge-critical {{ background: rgba(255, 68, 68, 0.3); color: #ff4444; }}
        .badge-high {{ background: rgba(255, 136, 68, 0.3); color: #ff8844; }}
        .badge-medium {{ background: rgba(255, 221, 68, 0.3); color: #ffdd44; }}
        .badge-low {{ background: rgba(68, 255, 68, 0.3); color: #44ff44; }}
        pre {{
            background: rgba(0,0,0,0.3);
            padding: 15px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            color: #7ee787;
        }}
        .footer {{
            text-align: center;
            padding: 30px;
            color: #8b949e;
            border-top: 1px solid #30363d;
            margin-top: 30px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>💀 ATOMIC FRAMEWORK</h1>
        <p>Security Assessment Report</p>
        <p>Scan ID: {self.scan_id} | Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC</p>
    </div>
    
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value critical">{severity_counts.get('CRITICAL', 0)}</div>
                <div class="stat-label">Critical</div>
            </div>
            <div class="stat-card">
                <div class="stat-value high">{severity_counts.get('HIGH', 0)}</div>
                <div class="stat-label">High</div>
            </div>
            <div class="stat-card">
                <div class="stat-value medium">{severity_counts.get('MEDIUM', 0)}</div>
                <div class="stat-label">Medium</div>
            </div>
            <div class="stat-card">
                <div class="stat-value low">{severity_counts.get('LOW', 0)}</div>
                <div class="stat-label">Low</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" style="color: #58a6ff;">{len(findings)}</div>
                <div class="stat-label">Total Findings</div>
            </div>
        </div>
        
        <div class="section">
            <h2>🐛 Detailed Findings</h2>
            <table>
                <tr>
                    <th>Severity</th>
                    <th>Technique</th>
                    <th>MITRE</th>
                    <th>CVSS</th>
                    <th>URL</th>
                    <th>Parameter</th>
                </tr>
"""
        
        for f in findings:
            badge_class = f'badge-{f.severity.lower()}'
            html += f"""
                <tr>
                    <td><span class="badge {badge_class}">{f.severity}</span></td>
                    <td>{f.technique}</td>
                    <td>{f.mitre_id}</td>
                    <td>{f.cvss:.1f}</td>
                    <td>{f.url[:50]}...</td>
                    <td>{f.param or '-'}</td>
                </tr>
            """
        
        html += """
            </table>
        </div>
    </div>
    
    <div class="footer">
        <p>Generated by ATOMIC Framework v7.0</p>
        <p>For authorized security testing only</p>
    </div>
</body>
</html>
        """
        
        filename = f"report_{self.scan_id}.html"
        filepath = os.path.join(self.reports_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html)
        
        print(f"{Colors.success(f'HTML report saved: {filepath}')}')
        return filepath
    
    def generate_json(self, findings: list, stats: dict) -> str:
        """Generate JSON report"""
        report = {
            'scan_id': self.scan_id,
            'generated_at': datetime.utcnow().isoformat(),
            'stats': stats,
            'findings': [f.to_dict() for f in findings],
        }
        
        filename = f"report_{self.scan_id}.json"
        filepath = os.path.join(self.reports_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, default=str)
        
        print(f"{Colors.success(f'JSON report saved: {filepath}')}')
        return filepath
    
    def generate_csv(self, findings: list, stats: dict) -> str:
        """Generate CSV report"""
        filename = f"report_{self.scan_id}.csv"
        filepath = os.path.join(self.reports_dir, filename)
        
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Severity', 'Technique', 'MITRE ID', 'CWE ID', 'CVSS', 
                           'URL', 'Parameter', 'Payload', 'Evidence'])
            
            for finding in findings:
                writer.writerow([
                    finding.severity,
                    finding.technique,
                    finding.mitre_id,
                    finding.cwe_id,
                    finding.cvss,
                    finding.url,
                    finding.param,
                    finding.payload[:100] if finding.payload else '',
                    finding.evidence[:200] if finding.evidence else '',
                ])
        
        print(f"{Colors.success(f'CSV report saved: {filepath}')}')
        return filepath
    
    def generate_pdf(self, findings: list, stats: dict) -> str:
        """Generate PDF report"""
        try:
            from fpdf import FPDF
            
            pdf = FPDF()
            pdf.add_page()
            
            pdf.set_font('Arial', 'B', 24)
            pdf.set_text_color(255, 68, 68)
            pdf.cell(0, 20, 'ATOMIC Framework', 0, 1, 'C')
            pdf.set_font('Arial', 'B', 16)
            pdf.cell(0, 10, 'Security Assessment Report', 0, 1, 'C')
            pdf.set_font('Arial', '', 12)
            pdf.set_text_color(0, 0, 0)
            pdf.cell(0, 10, f'Scan ID: {self.scan_id}', 0, 1, 'C')
            pdf.cell(0, 10, f'Generated: {datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")} UTC', 0, 1, 'C')
            pdf.ln(20)
            
            severity_counts = Counter(f.severity for f in findings)
            pdf.set_font('Arial', 'B', 14)
            pdf.cell(0, 10, 'Executive Summary', 0, 1)
            pdf.set_font('Arial', '', 12)
            pdf.cell(0, 8, f"Total Findings: {len(findings)}", 0, 1)
            pdf.cell(0, 8, f"Critical: {severity_counts.get('CRITICAL', 0)}", 0, 1)
            pdf.cell(0, 8, f"High: {severity_counts.get('HIGH', 0)}", 0, 1)
            pdf.cell(0, 8, f"Medium: {severity_counts.get('MEDIUM', 0)}", 0, 1)
            pdf.cell(0, 8, f"Low: {severity_counts.get('LOW', 0)}", 0, 1)
            pdf.ln(10)
            
            pdf.set_font('Arial', 'B', 14)
            pdf.cell(0, 10, 'Detailed Findings', 0, 1)
            pdf.set_font('Arial', 'B', 10)
            pdf.cell(35, 8, 'Technique', 1)
            pdf.cell(25, 8, 'Severity', 1)
            pdf.cell(30, 8, 'MITRE ID', 1)
            pdf.cell(100, 8, 'URL', 1)
            pdf.ln()
            
            pdf.set_font('Arial', '', 9)
            for f in findings[:50]:
                pdf.cell(35, 6, f.technique[:20], 1)
                pdf.cell(25, 6, f.severity, 1)
                pdf.cell(30, 6, f.mitre_id, 1)
                pdf.cell(100, 6, f.url[:45], 1)
                pdf.ln()
            
            filename = f"report_{self.scan_id}.pdf"
            filepath = os.path.join(self.reports_dir, filename)
            pdf.output(filepath)
            
            print(f"{Colors.success(f'PDF report saved: {filepath}')}")
            return filepath
            
        except ImportError:
            print(f"{Colors.warning('FPDF not installed. PDF report skipped.')}")
            return None
    
    def generate_txt(self, findings: list, stats: dict) -> str:
        """Generate text report"""
        filename = f"report_{self.scan_id}.txt"
        filepath = os.path.join(self.reports_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("ATOMIC FRAMEWORK - Security Assessment Report\n")
            f.write("="*80 + "\n\n")
            f.write(f"Scan ID: {self.scan_id}\n")
            f.write(f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC\n\n")
            
            severity_counts = Counter(find.severity for find in findings)
            f.write("Summary:\n")
            f.write(f"  Total Findings: {len(findings)}\n")
            f.write(f"  Critical: {severity_counts.get('CRITICAL', 0)}\n")
            f.write(f"  High: {severity_counts.get('HIGH', 0)}\n")
            f.write(f"  Medium: {severity_counts.get('MEDIUM', 0)}\n")
            f.write(f"  Low: {severity_counts.get('LOW', 0)}\n\n")
            
            f.write("="*80 + "\n")
            f.write("Detailed Findings:\n")
            f.write("="*80 + "\n\n")
            
            for finding in findings:
                f.write(f"[{finding.severity}] {finding.technique}\n")
                f.write(f"  URL: {finding.url}\n")
                f.write(f"  Param: {finding.param}\n")
                f.write(f"  Payload: {finding.payload}\n")
                f.write(f"  Evidence: {finding.evidence}\n")
                f.write(f"  MITRE: {finding.mitre_id} | CWE: {finding.cwe_id} | CVSS: {finding.cvss:.1f}\n\n")
        
        print(f"{Colors.success(f'Text report saved: {filepath}')}')
        return filepath
