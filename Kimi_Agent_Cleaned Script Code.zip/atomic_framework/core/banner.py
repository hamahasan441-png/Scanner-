#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ATOMIC FRAMEWORK - Banner Module
"""

import random
from config import Colors, Config

BANNERS = [
    f"""
{Colors.RED}    _    _   _   ___ _____ __  __  ___  ____  _   _ _____ _____ ____  
   / \\  | | | | |_ _| ____|  \/  |/ _ \\|  _ \\| | | |_   _| ____|  _ \\ 
  / _ \\ | | | |  | ||  _| | |\\/| | | | | |_) | | | | | | |  _| | |_) |
 / ___ \\| |_| |  | || |___| |  | | |_| |  _ <| |_| | | | | |___|  _ < 
/_/   \\_\\___/  |___|_____|_|  |_|\\___/|_| \\_\\___/  |_| |_____|_| \\_\\{Colors.RESET}
{Colors.YELLOW}                                                                    
     ULTIMATE EDITION v{Config.VERSION} - {Config.CODENAME} - Termux Edition{Colors.RESET}
{Colors.CYAN}     ⚠️  FOR AUTHORIZED TESTING ONLY  ⚠️{Colors.RESET}
    """,
    f"""
{Colors.RED}    ╔═══════════════════════════════════════════════════════════════════╗
    ║                                                                   ║
    ║   {Colors.YELLOW}█████╗ ████████╗ ██████╗ ███╗   ███╗██╗ ██████╗{Colors.RED}                 ║
    ║   {Colors.YELLOW}██╔══██╗╚══██╔══╝██╔═══██╗████╗ ████║██║██╔════╝{Colors.RED}                 ║
    ║   {Colors.YELLOW}███████║   ██║   ██║   ██║██╔████╔██║██║██║     {Colors.RED}                 ║
    ║   {Colors.YELLOW}██╔══██║   ██║   ██║   ██║██║╚██╔╝██║██║██║     {Colors.RED}                 ║
    ║   {Colors.YELLOW}██║  ██║   ██║   ╚██████╔╝██║ ╚═╝ ██║██║╚██████╗{Colors.RED}                 ║
    ║   {Colors.YELLOW}╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝     ╚═╝╚═╝ ╚═════╝{Colors.RED}                 ║
    ║                                                                   ║
    ║              {Colors.CYAN}ULTIMATE EDITION v{Config.VERSION} - {Config.CODENAME}{Colors.RED}              ║
    ║                  {Colors.GREEN}Termux Optimized Framework{Colors.RED}                      ║
    ║                                                                   ║
    ║         {Colors.MAGENTA}⚠️  FOR AUTHORIZED TESTING ONLY  ⚠️{Colors.RED}                    ║
    ║                                                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝{Colors.RESET}
    """,
    f"""
{Colors.RED}
    ░█████╗░████████╗░█████╗░███╗░░░███╗██╗░█████╗░
    ██╔══██╗╚══██╔══╝██╔══██╗████╗░████║██║██╔══██╗
    ███████║░░░██║░░░██║░░██║██╔████╔██║██║██║░░╚═╝
    ██╔══██║░░░██║░░░██║░░██║██║╚██╔╝██║██║██║░░██╗
    ██║░░██║░░░██║░░░╚█████╔╝██║░╚═╝░██║██║╚█████╔╝
    ╚═╝░░╚═╝░░░╚═╝░░░░╚════╝░╚═╝░░░░░╚═╝╚═╝░╚════╝░
{Colors.YELLOW}
         ULTIMATE EDITION v{Config.VERSION} - {Config.CODENAME}
              Termux Optimized Framework
{Colors.CYAN}
              ⚠️  FOR AUTHORIZED TESTING ONLY  ⚠️
{Colors.RESET}
    """,
]

TIPS = [
    "Use --full for comprehensive scanning",
    "Use --evasion insane for maximum stealth",
    "Use --shell to attempt shell upload",
    "Use --dump to extract database contents",
    "Use --waf-bypass to bypass WAF protection",
    "Use --tor to route traffic through Tor",
    "Use --threads 100 for faster scanning",
    "Check --list-scans to view previous scans",
    "Use --shell-manager to manage active shells",
]


def print_banner():
    """Print random banner"""
    print(random.choice(BANNERS))
    print(f"{Colors.CYAN}    💡 Tip: {random.choice(TIPS)}{Colors.RESET}\n")


def print_section(title):
    """Print section header"""
    print(f"\n{Colors.BOLD}{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.YELLOW}[ {title} ]{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}{'='*60}{Colors.RESET}\n")


def print_finding(severity, technique, url, param="", payload=""):
    """Print finding with colors"""
    colors = {
        'CRITICAL': Colors.RED + Colors.BOLD,
        'HIGH': Colors.RED,
        'MEDIUM': Colors.YELLOW,
        'LOW': Colors.GREEN,
        'INFO': Colors.CYAN,
    }
    color = colors.get(severity.upper(), Colors.WHITE)
    
    print(f"{color}[{severity.upper()}]{Colors.RESET} {Colors.BOLD}{technique}{Colors.RESET}")
    print(f"    URL: {url}")
    if param:
        print(f"    Param: {param}")
    if payload:
        print(f"    Payload: {payload[:100]}...")
    print()
