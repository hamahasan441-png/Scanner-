# ATOMIC Framework - Utilities
