# Omni Agent

Autonomous software engineering agent framework. See [`omni_agent/README.md`](omni_agent/README.md) for the Python package.

This workspace also hosts the OMNI control plane — an interactive map of the architecture, tool registry, source, and a live loop console.
