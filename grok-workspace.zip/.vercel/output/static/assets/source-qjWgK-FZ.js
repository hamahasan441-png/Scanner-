import{d as e,f as t,t as n,u as r}from"./index-DcUb8NoJ.js";var i=t(e(),1),a={"omni_agent/__init__.py":`"""Omni Agent — production-grade autonomous software engineering framework."""

from .agent import OmniAgent, TurnResult
from .client import AgentRouterClient, AgentRouterError, StreamMessage
from .config import Settings, load_settings
from .diagnostics import Checkpoint, Diagnostics
from .memory import MemoryStore, SessionState
from .test_runner import TestReport, TestRunner
from .tools import ToolRegistry, ToolResult

__version__ = "1.0.0"
__all__ = [
    "OmniAgent",
    "TurnResult",
    "AgentRouterClient",
    "AgentRouterError",
    "StreamMessage",
    "Settings",
    "load_settings",
    "Checkpoint",
    "Diagnostics",
    "MemoryStore",
    "SessionState",
    "TestReport",
    "TestRunner",
    "ToolRegistry",
    "ToolResult",
    "__version__",
]
`,"omni_agent/__main__.py":`"""python -m omni_agent entry point."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
`,"omni_agent/config.py":`"""Environment configuration, API endpoints, token constraints, and safety patterns."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Pattern, Sequence


DEFAULT_BASE_URL = "https://agentrouter.org"
DEFAULT_ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_ANTHROPIC_BETA = "claude-code-20250219,interleaved-thinking-2025-05-14"
DEFAULT_USER_AGENT = "claude-cli/2.1.158 (external, sdk-cli)"
DEFAULT_APP_HEADER = "cli"

DEFAULT_MODEL_CANDIDATES: Sequence[str] = (
    "claude-opus-4-6",
    "claude-sonnet-4-6",
    "claude-opus-4-5",
    "claude-sonnet-4-5",
    "claude-opus-4-1",
    "claude-sonnet-4",
    "claude-3-7-sonnet-latest",
    "claude-3-5-sonnet-latest",
)

DEFAULT_MAX_TOKENS = 16_384
DEFAULT_THINKING_BUDGET = 10_240
DEFAULT_COMPACTION_THRESHOLD = 96_000
DEFAULT_COMPACTION_KEEP = 24
DEFAULT_REQUEST_TIMEOUT = 300.0
DEFAULT_CONNECT_TIMEOUT = 20.0
DEFAULT_MAX_RETRIES = 6
DEFAULT_RETRY_BASE_SECONDS = 1.25
DEFAULT_RETRY_MAX_SECONDS = 32.0
DEFAULT_STREAM_IDLE_TIMEOUT = 90.0
DEFAULT_MAX_CONTINUATIONS = 8
DEFAULT_MAX_TOOL_ROUNDS = 80
DEFAULT_TOOL_TIMEOUT = 120.0
DEFAULT_MAX_TOOL_OUTPUT_CHARS = 80_000
DEFAULT_SESSION_DIRNAME = ".omni_agent"
DEFAULT_HISTORY_FILE = "history"
DEFAULT_SESSION_FILE = "session.json"
DEFAULT_TASKS_FILE = "tasks.json"
DEFAULT_DAEMONS_FILE = "daemons.json"
DEFAULT_CHECKPOINTS_FILE = "checkpoints.json"

RETRYABLE_STATUS_CODES = frozenset({408, 409, 425, 429, 500, 502, 503, 504, 529})

DANGEROUS_COMMAND_PATTERNS: Sequence[str] = (
    r"\\brm\\s+(-[a-zA-Z]*f[a-zA-Z]*\\s+)*(/\\s*($|\\s)|/\\*|~|/home|/Users|/var|/usr|/etc|/boot)",
    r"\\bmkfs(\\.\\w+)?\\b",
    r"\\bdd\\s+if=",
    r":\\(\\)\\s*\\{\\s*:\\s*\\|\\s*:\\s*&\\s*;\\s*\\}",
    r"\\bchmod\\s+-R\\s+777\\s+/",
    r"\\bchown\\s+-R\\s+[^\\n]+?\\s+/\\s*$",
    r"\\b(shutdown|reboot|halt|poweroff)\\b",
    r"\\b(mkfs|fdisk|parted|diskpart)\\b",
    r">\\s*/dev/sd[a-z]",
    r"\\bcurl\\b[^\\n]*\\|\\s*(ba)?sh\\b",
    r"\\bwget\\b[^\\n]*\\|\\s*(ba)?sh\\b",
    r"\\bgit\\s+push\\b[^\\n]*--force[^\\n]*\\b(main|master)\\b",
    r"\\bgit\\s+reset\\s+--hard\\b",
    r"\\bDROP\\s+(DATABASE|SCHEMA|TABLE)\\b",
    r"\\bTRUNCATE\\s+TABLE\\b",
    r"\\bsudo\\s+rm\\b",
    r"\\bkill\\s+-9\\s+1\\b",
    r"\\biptables\\s+-F\\b",
    r"\\bfork\\s*\\(\\s*\\)\\s*while",
    r"\\bnc\\s+-l\\b[^\\n]*-e\\b",
    r"\\bpython\\s+-c\\s+['\\"]import\\s+socket[^\\n]*subprocess",
)

COMPILED_DANGEROUS_PATTERNS: List[Pattern[str]] = [
    re.compile(p, re.IGNORECASE | re.MULTILINE) for p in DANGEROUS_COMMAND_PATTERNS
]

PROJECT_RULE_FILENAMES: Sequence[str] = (
    "CLAUDE.md",
    "AGENT.md",
    "AGENTS.md",
    "OMNI.md",
    ".omni_agent/rules.md",
)


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or not raw.strip():
        return default
    try:
        return float(raw)
    except ValueError:
        return default


@dataclass
class Settings:
    """Runtime configuration resolved from the process environment."""

    auth_token: str = ""
    base_url: str = DEFAULT_BASE_URL
    model: str = ""
    max_tokens: int = DEFAULT_MAX_TOKENS
    thinking_budget: int = DEFAULT_THINKING_BUDGET
    enable_thinking: bool = True
    compaction_threshold: int = DEFAULT_COMPACTION_THRESHOLD
    compaction_keep: int = DEFAULT_COMPACTION_KEEP
    request_timeout: float = DEFAULT_REQUEST_TIMEOUT
    connect_timeout: float = DEFAULT_CONNECT_TIMEOUT
    max_retries: int = DEFAULT_MAX_RETRIES
    retry_base_seconds: float = DEFAULT_RETRY_BASE_SECONDS
    retry_max_seconds: float = DEFAULT_RETRY_MAX_SECONDS
    stream_idle_timeout: float = DEFAULT_STREAM_IDLE_TIMEOUT
    max_continuations: int = DEFAULT_MAX_CONTINUATIONS
    max_tool_rounds: int = DEFAULT_MAX_TOOL_ROUNDS
    tool_timeout: float = DEFAULT_TOOL_TIMEOUT
    max_tool_output_chars: int = DEFAULT_MAX_TOOL_OUTPUT_CHARS
    workspace: Path = field(default_factory=lambda: Path.cwd())
    session_dir: Path = field(default_factory=lambda: Path.cwd() / DEFAULT_SESSION_DIRNAME)
    allow_dangerous: bool = False
    extra_headers: Dict[str, str] = field(default_factory=dict)

    @property
    def messages_url(self) -> str:
        return f"{self.base_url.rstrip('/')}/v1/messages"

    @property
    def models_url(self) -> str:
        return f"{self.base_url.rstrip('/')}/v1/models"

    @property
    def history_path(self) -> Path:
        return self.session_dir / DEFAULT_HISTORY_FILE

    @property
    def session_path(self) -> Path:
        return self.session_dir / DEFAULT_SESSION_FILE

    @property
    def tasks_path(self) -> Path:
        return self.session_dir / DEFAULT_TASKS_FILE

    @property
    def daemons_path(self) -> Path:
        return self.session_dir / DEFAULT_DAEMONS_FILE

    @property
    def checkpoints_path(self) -> Path:
        return self.session_dir / DEFAULT_CHECKPOINTS_FILE

    def client_headers(self) -> Dict[str, str]:
        token = self.auth_token
        headers = {
            "Authorization": f"Bearer {token}",
            "x-api-key": token,
            "anthropic-version": DEFAULT_ANTHROPIC_VERSION,
            "anthropic-beta": DEFAULT_ANTHROPIC_BETA,
            "x-app": DEFAULT_APP_HEADER,
            "User-Agent": DEFAULT_USER_AGENT,
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        headers.update(self.extra_headers)
        return headers

    def ensure_session_dir(self) -> Path:
        self.session_dir.mkdir(parents=True, exist_ok=True)
        return self.session_dir

    def is_dangerous(self, command: str) -> bool:
        if self.allow_dangerous:
            return False
        return any(p.search(command) for p in COMPILED_DANGEROUS_PATTERNS)


def load_settings(workspace: str | Path | None = None) -> Settings:
    """Load settings from environment variables and optional workspace path."""
    root = Path(workspace).resolve() if workspace else Path.cwd().resolve()
    token = (
        os.getenv("ANTHROPIC_AUTH_TOKEN")
        or os.getenv("ANTHROPIC_API_KEY")
        or os.getenv("AGENTROUTER_API_KEY")
        or ""
    ).strip()
    base_url = os.getenv("ANTHROPIC_BASE_URL", DEFAULT_BASE_URL).strip() or DEFAULT_BASE_URL
    session_dir = Path(os.getenv("OMNI_SESSION_DIR", str(root / DEFAULT_SESSION_DIRNAME))).resolve()
    return Settings(
        auth_token=token,
        base_url=base_url.rstrip("/"),
        model=os.getenv("OMNI_MODEL", os.getenv("ANTHROPIC_MODEL", "")).strip(),
        max_tokens=_env_int("OMNI_MAX_TOKENS", DEFAULT_MAX_TOKENS),
        thinking_budget=_env_int("OMNI_THINKING_BUDGET", DEFAULT_THINKING_BUDGET),
        enable_thinking=_env_bool("OMNI_ENABLE_THINKING", True),
        compaction_threshold=_env_int("OMNI_COMPACTION_THRESHOLD", DEFAULT_COMPACTION_THRESHOLD),
        compaction_keep=_env_int("OMNI_COMPACTION_KEEP", DEFAULT_COMPACTION_KEEP),
        request_timeout=_env_float("OMNI_REQUEST_TIMEOUT", DEFAULT_REQUEST_TIMEOUT),
        connect_timeout=_env_float("OMNI_CONNECT_TIMEOUT", DEFAULT_CONNECT_TIMEOUT),
        max_retries=_env_int("OMNI_MAX_RETRIES", DEFAULT_MAX_RETRIES),
        retry_base_seconds=_env_float("OMNI_RETRY_BASE", DEFAULT_RETRY_BASE_SECONDS),
        retry_max_seconds=_env_float("OMNI_RETRY_MAX", DEFAULT_RETRY_MAX_SECONDS),
        stream_idle_timeout=_env_float("OMNI_STREAM_IDLE_TIMEOUT", DEFAULT_STREAM_IDLE_TIMEOUT),
        max_continuations=_env_int("OMNI_MAX_CONTINUATIONS", DEFAULT_MAX_CONTINUATIONS),
        max_tool_rounds=_env_int("OMNI_MAX_TOOL_ROUNDS", DEFAULT_MAX_TOOL_ROUNDS),
        tool_timeout=_env_float("OMNI_TOOL_TIMEOUT", DEFAULT_TOOL_TIMEOUT),
        max_tool_output_chars=_env_int("OMNI_MAX_TOOL_OUTPUT", DEFAULT_MAX_TOOL_OUTPUT_CHARS),
        workspace=root,
        session_dir=session_dir,
        allow_dangerous=_env_bool("OMNI_ALLOW_DANGEROUS", False),
    )
`,"omni_agent/client.py":`"""Resilient AgentRouter HTTP client with SSE streaming, thinking blocks, and auto-continuation."""

from __future__ import annotations

import json
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence

import requests

from .config import DEFAULT_MODEL_CANDIDATES, RETRYABLE_STATUS_CODES, Settings, load_settings

logger = logging.getLogger("omni_agent.client")

StreamCallback = Callable[[str, Dict[str, Any]], None]


class AgentRouterError(RuntimeError):
    """Raised when the AgentRouter proxy returns an unrecoverable error."""

    def __init__(self, message: str, status_code: int | None = None, payload: Any = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


@dataclass
class ContentBlock:
    type: str
    text: str = ""
    thinking: str = ""
    id: str = ""
    name: str = ""
    input: Dict[str, Any] = field(default_factory=dict)
    signature: str = ""

    def to_api(self) -> Dict[str, Any]:
        if self.type == "text":
            return {"type": "text", "text": self.text}
        if self.type == "thinking":
            block: Dict[str, Any] = {"type": "thinking", "thinking": self.thinking}
            if self.signature:
                block["signature"] = self.signature
            return block
        if self.type == "tool_use":
            return {"type": "tool_use", "id": self.id, "name": self.name, "input": self.input}
        if self.type == "redacted_thinking":
            return {"type": "redacted_thinking", "data": self.text}
        return {"type": self.type}


@dataclass
class StreamMessage:
    id: str = ""
    model: str = ""
    role: str = "assistant"
    stop_reason: Optional[str] = None
    stop_sequence: Optional[str] = None
    usage: Dict[str, int] = field(default_factory=dict)
    blocks: List[ContentBlock] = field(default_factory=list)
    raw_events: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def text(self) -> str:
        return "".join(b.text for b in self.blocks if b.type == "text")

    @property
    def thinking(self) -> str:
        return "".join(b.thinking for b in self.blocks if b.type == "thinking")

    @property
    def tool_calls(self) -> List[ContentBlock]:
        return [b for b in self.blocks if b.type == "tool_use"]

    def to_assistant_message(self) -> Dict[str, Any]:
        content: List[Dict[str, Any]] = []
        for block in self.blocks:
            api = block.to_api()
            if block.type == "text" and not block.text:
                continue
            if block.type == "thinking" and not block.thinking:
                continue
            content.append(api)
        if not content:
            content = [{"type": "text", "text": self.text or ""}]
        return {"role": "assistant", "content": content}


class SSEParser:
    """Incremental Server-Sent Events parser for Anthropic-compatible streams."""

    def __init__(self) -> None:
        self._buffer = ""

    def feed(self, chunk: str) -> Iterator[Dict[str, Any]]:
        self._buffer += chunk
        while "\\n\\n" in self._buffer or "\\r\\n\\r\\n" in self._buffer:
            if "\\r\\n\\r\\n" in self._buffer and (
                "\\n\\n" not in self._buffer
                or self._buffer.find("\\r\\n\\r\\n") < self._buffer.find("\\n\\n")
            ):
                raw, self._buffer = self._buffer.split("\\r\\n\\r\\n", 1)
            else:
                raw, self._buffer = self._buffer.split("\\n\\n", 1)
            event = self._parse_event(raw)
            if event is not None:
                yield event

    def flush(self) -> Iterator[Dict[str, Any]]:
        if self._buffer.strip():
            event = self._parse_event(self._buffer)
            self._buffer = ""
            if event is not None:
                yield event

    @staticmethod
    def _parse_event(raw: str) -> Optional[Dict[str, Any]]:
        event_name = "message"
        data_lines: List[str] = []
        for line in raw.splitlines():
            if not line or line.startswith(":"):
                continue
            if line.startswith("event:"):
                event_name = line[6:].strip()
            elif line.startswith("data:"):
                data_lines.append(line[5:].lstrip())
            elif line.startswith("id:") or line.startswith("retry:"):
                continue
        if not data_lines:
            return None
        payload = "\\n".join(data_lines)
        if payload == "[DONE]":
            return {"event": "done", "data": {"type": "done"}}
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            data = {"type": "raw", "data": payload}
        if isinstance(data, dict) and "type" not in data:
            data["type"] = event_name
        return {"event": event_name, "data": data}


class AgentRouterClient:
    """Production HTTP client for the AgentRouter Anthropic-compatible proxy."""

    def __init__(
        self,
        settings: Settings | None = None,
        session: requests.Session | None = None,
        on_event: StreamCallback | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        self.session = session or requests.Session()
        self.on_event = on_event
        self._resolved_model: Optional[str] = self.settings.model or None
        self._models_cache: Optional[List[Dict[str, Any]]] = None

    def close(self) -> None:
        self.session.close()

    def __enter__(self) -> "AgentRouterClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def discover_models(self, force: bool = False) -> List[Dict[str, Any]]:
        if self._models_cache is not None and not force:
            return self._models_cache
        response = self._request("GET", self.settings.models_url, stream=False)
        payload = response.json()
        models: List[Dict[str, Any]]
        if isinstance(payload, dict) and isinstance(payload.get("data"), list):
            models = payload["data"]
        elif isinstance(payload, list):
            models = payload
        else:
            models = []
        self._models_cache = models
        return models

    def resolve_model(self, preferred: str | None = None) -> str:
        if preferred:
            self._resolved_model = preferred
            return preferred
        if self._resolved_model:
            return self._resolved_model
        discovered = []
        try:
            discovered = self.discover_models()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Model discovery failed (%s); falling back to candidates", exc)
        ids: List[str] = []
        for item in discovered:
            if isinstance(item, dict):
                mid = item.get("id") or item.get("name")
                if isinstance(mid, str):
                    ids.append(mid)
            elif isinstance(item, str):
                ids.append(item)
        if self.settings.model and (not ids or self.settings.model in ids):
            self._resolved_model = self.settings.model
            return self._resolved_model
        for candidate in DEFAULT_MODEL_CANDIDATES:
            if candidate in ids:
                self._resolved_model = candidate
                return candidate
        if ids:
            self._resolved_model = ids[0]
            return ids[0]
        self._resolved_model = self.settings.model or DEFAULT_MODEL_CANDIDATES[0]
        return self._resolved_model

    def stream(
        self,
        messages: Sequence[Dict[str, Any]],
        *,
        system: str | Sequence[Dict[str, Any]] | None = None,
        tools: Sequence[Dict[str, Any]] | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
        thinking: Dict[str, Any] | None = None,
        extra_body: Dict[str, Any] | None = None,
        auto_continue: bool = True,
    ) -> StreamMessage:
        """Stream a completion, optionally auto-continuing on max_tokens."""
        working_messages: List[Dict[str, Any]] = list(messages)
        continuations = 0
        assembled = StreamMessage()
        while True:
            piece = self._stream_once(
                working_messages,
                system=system,
                tools=tools,
                model=model,
                max_tokens=max_tokens,
                thinking=thinking,
                extra_body=extra_body,
            )
            assembled = self._merge_messages(assembled, piece) if assembled.blocks else piece
            if (
                auto_continue
                and piece.stop_reason == "max_tokens"
                and continuations < self.settings.max_continuations
            ):
                continuations += 1
                logger.info("Hit max_tokens; auto-continuing (%s/%s)", continuations, self.settings.max_continuations)
                working_messages = list(working_messages)
                working_messages.append(piece.to_assistant_message())
                working_messages.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": (
                                    "Continue exactly from where you left off. "
                                    "Do not repeat prior text. Resume the unfinished response."
                                ),
                            }
                        ],
                    }
                )
                continue
            assembled.stop_reason = piece.stop_reason
            assembled.stop_sequence = piece.stop_sequence
            assembled.usage = self._merge_usage(assembled.usage, piece.usage)
            return assembled

    def complete(
        self,
        messages: Sequence[Dict[str, Any]],
        **kwargs: Any,
    ) -> StreamMessage:
        return self.stream(messages, **kwargs)

    def _stream_once(
        self,
        messages: Sequence[Dict[str, Any]],
        *,
        system: str | Sequence[Dict[str, Any]] | None,
        tools: Sequence[Dict[str, Any]] | None,
        model: str | None,
        max_tokens: int | None,
        thinking: Dict[str, Any] | None,
        extra_body: Dict[str, Any] | None,
    ) -> StreamMessage:
        body: Dict[str, Any] = {
            "model": self.resolve_model(model),
            "max_tokens": max_tokens or self.settings.max_tokens,
            "stream": True,
            "messages": list(messages),
        }
        if system:
            body["system"] = system
        if tools:
            body["tools"] = list(tools)
        if thinking is not None:
            body["thinking"] = thinking
        elif self.settings.enable_thinking and self.settings.thinking_budget > 0:
            budget = min(self.settings.thinking_budget, max(1024, body["max_tokens"] - 1024))
            if budget >= 1024:
                body["thinking"] = {"type": "enabled", "budget_tokens": budget}
        if extra_body:
            body.update(extra_body)

        response = self._request("POST", self.settings.messages_url, json_body=body, stream=True)
        parser = SSEParser()
        message = StreamMessage(model=body["model"])
        blocks: Dict[int, ContentBlock] = {}
        json_buffers: Dict[int, str] = {}
        last_data = time.monotonic()

        def emit(kind: str, payload: Dict[str, Any]) -> None:
            if self.on_event:
                try:
                    self.on_event(kind, payload)
                except Exception:  # noqa: BLE001
                    logger.exception("Stream callback failed")

        try:
            for raw_chunk in response.iter_content(chunk_size=4096, decode_unicode=False):
                if not raw_chunk:
                    if time.monotonic() - last_data > self.settings.stream_idle_timeout:
                        raise AgentRouterError("SSE stream idle timeout exceeded")
                    continue
                last_data = time.monotonic()
                text = raw_chunk.decode("utf-8", errors="replace") if isinstance(raw_chunk, bytes) else raw_chunk
                for event in parser.feed(text):
                    self._apply_event(event, message, blocks, json_buffers, emit)
            for event in parser.flush():
                self._apply_event(event, message, blocks, json_buffers, emit)
        finally:
            response.close()

        ordered = [blocks[i] for i in sorted(blocks)]
        if ordered:
            message.blocks = ordered
        for index, buf in json_buffers.items():
            block = blocks.get(index)
            if block and block.type == "tool_use" and buf and not block.input:
                try:
                    parsed = json.loads(buf)
                    if isinstance(parsed, dict):
                        block.input = parsed
                except json.JSONDecodeError:
                    block.input = {"_raw": buf}
        return message

    def _apply_event(
        self,
        event: Dict[str, Any],
        message: StreamMessage,
        blocks: Dict[int, ContentBlock],
        json_buffers: Dict[int, str],
        emit: StreamCallback,
    ) -> None:
        data = event.get("data") or {}
        if not isinstance(data, dict):
            return
        etype = data.get("type") or event.get("event")
        message.raw_events.append(data)
        emit(str(etype), data)

        if etype == "error" or event.get("event") == "error":
            err = data.get("error") if isinstance(data.get("error"), dict) else data
            raise AgentRouterError(str(err.get("message") or err), payload=data)

        if etype == "message_start":
            inner = data.get("message") or {}
            message.id = inner.get("id") or message.id
            message.model = inner.get("model") or message.model
            message.role = inner.get("role") or message.role
            usage = inner.get("usage") or {}
            if isinstance(usage, dict):
                message.usage.update({k: int(v) for k, v in usage.items() if isinstance(v, (int, float))})
            return

        if etype == "content_block_start":
            index = int(data.get("index") or 0)
            raw_block = data.get("content_block") or {}
            btype = raw_block.get("type") or "text"
            block = ContentBlock(
                type=btype,
                text=raw_block.get("text") or "",
                thinking=raw_block.get("thinking") or "",
                id=raw_block.get("id") or "",
                name=raw_block.get("name") or "",
                input=raw_block.get("input") if isinstance(raw_block.get("input"), dict) else {},
                signature=raw_block.get("signature") or "",
            )
            blocks[index] = block
            if btype == "tool_use":
                json_buffers[index] = ""
            return

        if etype == "content_block_delta":
            index = int(data.get("index") or 0)
            delta = data.get("delta") or {}
            dtype = delta.get("type")
            block = blocks.setdefault(index, ContentBlock(type="text"))
            if dtype == "thinking_delta" or "thinking" in delta:
                block.type = "thinking"
                block.thinking += str(delta.get("thinking") or "")
                emit("thinking_delta", {"index": index, "thinking": delta.get("thinking") or ""})
            elif dtype == "text_delta" or "text" in delta:
                block.type = block.type if block.type == "thinking" else "text"
                if dtype == "text_delta" or block.type == "text":
                    block.type = "text"
                    block.text += str(delta.get("text") or "")
            elif dtype == "input_json_delta" or "partial_json" in delta:
                block.type = "tool_use"
                json_buffers[index] = json_buffers.get(index, "") + str(delta.get("partial_json") or "")
            elif dtype == "signature_delta":
                block.signature += str(delta.get("signature") or "")
            return

        if etype == "content_block_stop":
            index = int(data.get("index") or 0)
            buf = json_buffers.get(index)
            block = blocks.get(index)
            if block and block.type == "tool_use" and buf:
                try:
                    parsed = json.loads(buf)
                    if isinstance(parsed, dict):
                        block.input = parsed
                except json.JSONDecodeError:
                    logger.warning("Incomplete tool JSON for block %s", index)
            return

        if etype == "message_delta":
            delta = data.get("delta") or {}
            if "stop_reason" in delta:
                message.stop_reason = delta.get("stop_reason")
            if "stop_sequence" in delta:
                message.stop_sequence = delta.get("stop_sequence")
            usage = data.get("usage") or {}
            if isinstance(usage, dict):
                for key, value in usage.items():
                    if isinstance(value, (int, float)):
                        message.usage[key] = int(value)
            return

        if etype == "message_stop":
            if not message.stop_reason:
                message.stop_reason = "end_turn"

    def _request(
        self,
        method: str,
        url: str,
        *,
        json_body: Dict[str, Any] | None = None,
        stream: bool = False,
    ) -> requests.Response:
        if not self.settings.auth_token:
            raise AgentRouterError(
                "Missing ANTHROPIC_AUTH_TOKEN (or ANTHROPIC_API_KEY / AGENTROUTER_API_KEY)"
            )
        headers = self.settings.client_headers()
        if not stream:
            headers = dict(headers)
            headers["Accept"] = "application/json"
        last_error: Exception | None = None
        attempts = max(1, self.settings.max_retries)
        for attempt in range(1, attempts + 1):
            try:
                response = self.session.request(
                    method,
                    url,
                    headers=headers,
                    json=json_body,
                    stream=stream,
                    timeout=(self.settings.connect_timeout, self.settings.request_timeout),
                )
            except (requests.ConnectionError, requests.Timeout) as exc:
                last_error = exc
                self._backoff(attempt, attempts, cause=str(exc))
                continue
            if response.status_code in RETRYABLE_STATUS_CODES:
                retry_after = self._retry_after(response)
                body_preview = self._safe_body(response)
                last_error = AgentRouterError(
                    f"HTTP {response.status_code}: {body_preview}",
                    status_code=response.status_code,
                    payload=body_preview,
                )
                response.close()
                self._backoff(attempt, attempts, retry_after=retry_after, cause=str(last_error))
                continue
            if response.status_code >= 400:
                payload = self._safe_body(response)
                response.close()
                raise AgentRouterError(
                    f"HTTP {response.status_code}: {payload}",
                    status_code=response.status_code,
                    payload=payload,
                )
            return response
        raise AgentRouterError(f"Exhausted retries for {method} {url}: {last_error}") from last_error

    def _backoff(self, attempt: int, attempts: int, retry_after: float | None = None, cause: str = "") -> None:
        if attempt >= attempts:
            return
        base = min(
            self.settings.retry_max_seconds,
            self.settings.retry_base_seconds * (2 ** (attempt - 1)),
        )
        delay = retry_after if retry_after is not None else base
        delay = delay + random.uniform(0, min(0.4, delay * 0.2))
        logger.warning("Retry %s/%s in %.2fs (%s)", attempt, attempts, delay, cause)
        time.sleep(delay)

    @staticmethod
    def _retry_after(response: requests.Response) -> float | None:
        raw = response.headers.get("Retry-After")
        if not raw:
            return None
        try:
            return float(raw)
        except ValueError:
            return None

    @staticmethod
    def _safe_body(response: requests.Response) -> str:
        try:
            text = response.text
        except Exception:  # noqa: BLE001
            return "<unreadable body>"
        return text[:4000]

    @staticmethod
    def _merge_usage(left: Dict[str, int], right: Dict[str, int]) -> Dict[str, int]:
        merged = dict(left)
        for key, value in right.items():
            merged[key] = merged.get(key, 0) + int(value)
        return merged

    @staticmethod
    def _merge_messages(head: StreamMessage, tail: StreamMessage) -> StreamMessage:
        merged = StreamMessage(
            id=tail.id or head.id,
            model=tail.model or head.model,
            role=tail.role or head.role,
            stop_reason=tail.stop_reason,
            stop_sequence=tail.stop_sequence,
            usage=AgentRouterClient._merge_usage(head.usage, tail.usage),
            blocks=list(head.blocks),
            raw_events=list(head.raw_events) + list(tail.raw_events),
        )
        if not tail.blocks:
            return merged
        if merged.blocks and merged.blocks[-1].type == "text" and tail.blocks[0].type == "text":
            merged.blocks[-1].text += tail.blocks[0].text
            merged.blocks.extend(tail.blocks[1:])
        else:
            merged.blocks.extend(tail.blocks)
        return merged
`,"omni_agent/tools.py":`"""Tool registry for the Omni autonomous engineering agent."""

from __future__ import annotations

import ast
import concurrent.futures
import difflib
import hashlib
import json
import os
import py_compile
import re
import shlex
import shutil
import signal
import subprocess
import tempfile
import time
import traceback
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence

from .config import Settings, load_settings

ToolHandler = Callable[[Dict[str, Any]], str]


@dataclass
class ToolSpec:
    name: str
    description: str
    input_schema: Dict[str, Any]
    handler: ToolHandler
    timeout: float | None = None


@dataclass
class ToolResult:
    name: str
    tool_use_id: str
    output: str
    is_error: bool = False
    duration_ms: int = 0


class ToolError(RuntimeError):
    pass


class _HTMLTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._chunks: List[str] = []
        self._skip = 0
        self._href: Optional[str] = None

    def handle_starttag(self, tag: str, attrs: List[tuple]) -> None:
        if tag in {"script", "style", "noscript", "svg"}:
            self._skip += 1
            return
        if tag in {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "tr", "section", "article"}:
            self._chunks.append("\\n")
        if tag == "a":
            href = dict(attrs).get("href")
            self._href = href
        if tag == "img":
            alt = dict(attrs).get("alt")
            if alt:
                self._chunks.append(f" [{alt}] ")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript", "svg"} and self._skip:
            self._skip -= 1
        if tag == "a" and self._href:
            self._chunks.append(f" ({self._href})")
            self._href = None

    def handle_data(self, data: str) -> None:
        if self._skip:
            return
        text = re.sub(r"\\s+", " ", data)
        if text.strip():
            self._chunks.append(text)

    def text(self) -> str:
        joined = "".join(self._chunks)
        joined = re.sub(r"[ \\t]+", " ", joined)
        joined = re.sub(r"\\n{3,}", "\\n\\n", joined)
        return joined.strip()


class DaemonSupervisor:
    """Background process supervisor with pid-file persistence."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._procs: Dict[str, subprocess.Popen] = {}
        self._meta: Dict[str, Dict[str, Any]] = {}
        self._load()

    def _load(self) -> None:
        path = self.settings.daemons_path
        if path.exists():
            try:
                self._meta = json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                self._meta = {}

    def _save(self) -> None:
        self.settings.ensure_session_dir()
        self.settings.daemons_path.write_text(
            json.dumps(self._meta, indent=2, sort_keys=True), encoding="utf-8"
        )

    def start(self, name: str, command: str, cwd: str | None = None) -> Dict[str, Any]:
        if name in self._procs and self._procs[name].poll() is None:
            raise ToolError(f"Daemon '{name}' is already running")
        log_dir = self.settings.session_dir / "daemons"
        log_dir.mkdir(parents=True, exist_ok=True)
        stdout_path = log_dir / f"{name}.out.log"
        stderr_path = log_dir / f"{name}.err.log"
        stdout = open(stdout_path, "ab")
        stderr = open(stderr_path, "ab")
        proc = subprocess.Popen(
            command,
            shell=True,
            cwd=cwd or str(self.settings.workspace),
            stdout=stdout,
            stderr=stderr,
            start_new_session=True,
        )
        self._procs[name] = proc
        self._meta[name] = {
            "name": name,
            "command": command,
            "pid": proc.pid,
            "cwd": cwd or str(self.settings.workspace),
            "started_at": time.time(),
            "stdout_log": str(stdout_path),
            "stderr_log": str(stderr_path),
            "status": "running",
        }
        self._save()
        return self._meta[name]

    def stop(self, name: str, kill: bool = False) -> Dict[str, Any]:
        meta = self._meta.get(name)
        if not meta:
            raise ToolError(f"Unknown daemon '{name}'")
        pid = int(meta.get("pid") or 0)
        proc = self._procs.get(name)
        sig = signal.SIGKILL if kill else signal.SIGTERM
        try:
            if proc and proc.poll() is None:
                os.killpg(os.getpgid(proc.pid), sig)
                proc.wait(timeout=8)
            elif pid:
                os.kill(pid, sig)
        except (ProcessLookupError, PermissionError, subprocess.TimeoutExpired):
            if pid:
                try:
                    os.kill(pid, signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    pass
        meta["status"] = "stopped"
        meta["stopped_at"] = time.time()
        self._save()
        return meta

    def status(self, name: str | None = None) -> List[Dict[str, Any]]:
        names = [name] if name else list(self._meta)
        result = []
        for item in names:
            meta = dict(self._meta.get(item) or {"name": item, "status": "unknown"})
            pid = int(meta.get("pid") or 0)
            alive = False
            if pid:
                try:
                    os.kill(pid, 0)
                    alive = True
                except OSError:
                    alive = False
            meta["status"] = "running" if alive else "stopped"
            result.append(meta)
        return result

    def logs(self, name: str, tail: int = 80, stream: str = "stdout") -> str:
        meta = self._meta.get(name)
        if not meta:
            raise ToolError(f"Unknown daemon '{name}'")
        path = Path(meta["stderr_log"] if stream == "stderr" else meta["stdout_log"])
        if not path.exists():
            return ""
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\\n".join(lines[-tail:])


class TaskTracker:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._tasks: List[Dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        path = self.settings.tasks_path
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                self._tasks = payload if isinstance(payload, list) else payload.get("tasks", [])
            except json.JSONDecodeError:
                self._tasks = []

    def _save(self) -> None:
        self.settings.ensure_session_dir()
        self.settings.tasks_path.write_text(json.dumps(self._tasks, indent=2), encoding="utf-8")

    def create(self, title: str, detail: str = "", priority: str = "normal") -> Dict[str, Any]:
        task = {
            "id": hashlib.sha1(f"{time.time()}:{title}".encode()).hexdigest()[:10],
            "title": title,
            "detail": detail,
            "priority": priority,
            "status": "open",
            "created_at": time.time(),
            "updated_at": time.time(),
        }
        self._tasks.append(task)
        self._save()
        return task

    def update(self, task_id: str, **fields: Any) -> Dict[str, Any]:
        for task in self._tasks:
            if task["id"] == task_id or task["title"] == task_id:
                task.update({k: v for k, v in fields.items() if v is not None})
                task["updated_at"] = time.time()
                self._save()
                return task
        raise ToolError(f"Task not found: {task_id}")

    def list(self, status: str | None = None) -> List[Dict[str, Any]]:
        if not status:
            return list(self._tasks)
        return [t for t in self._tasks if t.get("status") == status]


class ToolRegistry:
    """Registers, schemas, and executes agent tools."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self.daemons = DaemonSupervisor(self.settings)
        self.tasks = TaskTracker(self.settings)
        self._tools: Dict[str, ToolSpec] = {}
        self._register_defaults()

    def register(self, spec: ToolSpec) -> None:
        self._tools[spec.name] = spec

    def names(self) -> List[str]:
        return sorted(self._tools)

    def get(self, name: str) -> ToolSpec:
        if name not in self._tools:
            raise ToolError(f"Unknown tool: {name}")
        return self._tools[name]

    def anthropic_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": spec.name,
                "description": spec.description,
                "input_schema": spec.input_schema,
            }
            for spec in self._tools.values()
        ]

    def execute(self, name: str, arguments: Dict[str, Any], tool_use_id: str = "") -> ToolResult:
        spec = self.get(name)
        started = time.monotonic()
        timeout = spec.timeout or self.settings.tool_timeout
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(spec.handler, arguments or {})
                output = future.result(timeout=timeout)
            is_error = False
        except concurrent.futures.TimeoutError:
            output = f"Tool '{name}' timed out after {timeout}s"
            is_error = True
        except Exception as exc:  # noqa: BLE001
            output = f"Tool '{name}' failed: {exc}\\n{traceback.format_exc()}"
            is_error = True
        duration_ms = int((time.monotonic() - started) * 1000)
        text = self._clip(str(output))
        return ToolResult(
            name=name,
            tool_use_id=tool_use_id,
            output=text,
            is_error=is_error,
            duration_ms=duration_ms,
        )

    def execute_blocks(self, blocks: Sequence[Any]) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        for block in blocks:
            name = getattr(block, "name", None) or block.get("name")
            tool_id = getattr(block, "id", None) or block.get("id") or ""
            arguments = getattr(block, "input", None) or block.get("input") or {}
            result = self.execute(name, arguments, tool_use_id=tool_id)
            results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": tool_id,
                    "content": result.output,
                    "is_error": result.is_error,
                }
            )
        return results

    def _clip(self, text: str) -> str:
        limit = self.settings.max_tool_output_chars
        if len(text) <= limit:
            return text
        head = text[: limit // 2]
        tail = text[-(limit // 2) :]
        return f"{head}\\n\\n...[{len(text) - limit} chars truncated]...\\n\\n{tail}"

    def _resolve(self, path: str | os.PathLike[str]) -> Path:
        candidate = Path(path)
        if not candidate.is_absolute():
            candidate = self.settings.workspace / candidate
        resolved = candidate.resolve()
        workspace = self.settings.workspace.resolve()
        try:
            resolved.relative_to(workspace)
        except ValueError as exc:
            raise ToolError(f"Path escapes workspace: {resolved}") from exc
        return resolved

    def _register_defaults(self) -> None:
        self.register(
            ToolSpec(
                name="bash",
                description="Run a shell command in the workspace. Prefer non-interactive commands.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "command": {"type": "string", "description": "Shell command to execute"},
                        "cwd": {"type": "string", "description": "Optional working directory"},
                        "timeout": {"type": "number", "description": "Timeout in seconds"},
                    },
                    "required": ["command"],
                },
                handler=self._bash,
            )
        )
        self.register(
            ToolSpec(
                name="read_file",
                description="Read a UTF-8 text file. Optionally slice by 1-based line numbers.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "offset": {"type": "integer", "description": "1-based start line"},
                        "limit": {"type": "integer", "description": "Max lines to return"},
                    },
                    "required": ["path"],
                },
                handler=self._read_file,
            )
        )
        self.register(
            ToolSpec(
                name="write_file",
                description="Write a complete file. Creates parent directories. Runs a syntax check afterwards.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "content": {"type": "string"},
                    },
                    "required": ["path", "content"],
                },
                handler=self._write_file,
            )
        )
        self.register(
            ToolSpec(
                name="apply_patch",
                description=(
                    "Apply a unified diff or search/replace patch with fuzzy matching via difflib. "
                    "Use when editing existing files."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "patch": {"type": "string", "description": "Unified diff or old/new block"},
                        "old_text": {"type": "string", "description": "Exact or near-exact text to replace"},
                        "new_text": {"type": "string", "description": "Replacement text"},
                        "fuzzy_ratio": {
                            "type": "number",
                            "description": "Minimum similarity 0-1 for fuzzy match (default 0.72)",
                        },
                    },
                    "required": ["path"],
                },
                handler=self._apply_patch,
            )
        )
        self.register(
            ToolSpec(
                name="syntax_check",
                description="Syntax-check a file with py_compile or node --check.",
                input_schema={
                    "type": "object",
                    "properties": {"path": {"type": "string"}},
                    "required": ["path"],
                },
                handler=self._syntax_check,
            )
        )
        self.register(
            ToolSpec(
                name="find_symbol",
                description="Search Python (AST) and text symbols across the workspace.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "kind": {
                            "type": "string",
                            "enum": ["any", "function", "class", "method", "assignment"],
                        },
                        "path": {"type": "string", "description": "Optional subdirectory or file"},
                    },
                    "required": ["name"],
                },
                handler=self._find_symbol,
            )
        )
        self.register(
            ToolSpec(
                name="repo_map",
                description="Build a compact repository map of files and top-level symbols.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "max_files": {"type": "integer"},
                        "max_depth": {"type": "integer"},
                    },
                },
                handler=self._repo_map,
            )
        )
        self.register(
            ToolSpec(
                name="fetch_url",
                description="Fetch a URL and return extracted text (HTML stripped) or raw JSON.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "url": {"type": "string"},
                        "max_chars": {"type": "integer"},
                    },
                    "required": ["url"],
                },
                handler=self._fetch_url,
            )
        )
        self.register(
            ToolSpec(
                name="daemon_control",
                description="Supervise background daemons: start, stop, status, logs.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["start", "stop", "status", "logs", "kill"]},
                        "name": {"type": "string"},
                        "command": {"type": "string"},
                        "cwd": {"type": "string"},
                        "tail": {"type": "integer"},
                        "stream": {"type": "string", "enum": ["stdout", "stderr"]},
                    },
                    "required": ["action"],
                },
                handler=self._daemon_control,
            )
        )
        self.register(
            ToolSpec(
                name="manage_tasks",
                description="Track multi-step work: create, update, list, complete, or cancel tasks.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": ["create", "update", "list", "complete", "cancel"],
                        },
                        "id": {"type": "string"},
                        "title": {"type": "string"},
                        "detail": {"type": "string"},
                        "priority": {"type": "string", "enum": ["low", "normal", "high", "critical"]},
                        "status": {"type": "string"},
                    },
                    "required": ["action"],
                },
                handler=self._manage_tasks,
            )
        )
        self.register(
            ToolSpec(
                name="select_best_option",
                description=(
                    "Autonomous trade-off evaluator. Score candidate options against weighted criteria "
                    "and return a ranked recommendation with rationale."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "goal": {"type": "string"},
                        "options": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "id": {"type": "string"},
                                    "summary": {"type": "string"},
                                    "pros": {"type": "array", "items": {"type": "string"}},
                                    "cons": {"type": "array", "items": {"type": "string"}},
                                    "scores": {
                                        "type": "object",
                                        "additionalProperties": {"type": "number"},
                                    },
                                },
                                "required": ["id", "summary"],
                            },
                        },
                        "criteria": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "weight": {"type": "number"},
                                    "higher_is_better": {"type": "boolean"},
                                },
                                "required": ["name"],
                            },
                        },
                    },
                    "required": ["goal", "options"],
                },
                handler=self._select_best_option,
            )
        )
        self.register(
            ToolSpec(
                name="glob_search",
                description="Find files matching a glob pattern under the workspace.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string"},
                        "path": {"type": "string"},
                    },
                    "required": ["pattern"],
                },
                handler=self._glob_search,
            )
        )
        self.register(
            ToolSpec(
                name="grep_search",
                description="Search file contents with a regular expression.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {"type": "string"},
                        "path": {"type": "string"},
                        "glob": {"type": "string"},
                        "max_matches": {"type": "integer"},
                    },
                    "required": ["pattern"],
                },
                handler=self._grep_search,
            )
        )

    def _bash(self, args: Dict[str, Any]) -> str:
        command = str(args.get("command") or "").strip()
        if not command:
            raise ToolError("command is required")
        if self.settings.is_dangerous(command):
            raise ToolError(
                f"Blocked dangerous command. Set OMNI_ALLOW_DANGEROUS=1 to override.\\nCommand: {command}"
            )
        cwd = args.get("cwd")
        workdir = self._resolve(cwd) if cwd else self.settings.workspace
        timeout = float(args.get("timeout") or self.settings.tool_timeout)
        completed = subprocess.run(
            command,
            shell=True,
            cwd=str(workdir),
            capture_output=True,
            text=True,
            timeout=timeout,
            env=os.environ.copy(),
        )
        parts = [
            f"exit_code: {completed.returncode}",
            f"cwd: {workdir}",
        ]
        if completed.stdout:
            parts.append("stdout:\\n" + completed.stdout)
        if completed.stderr:
            parts.append("stderr:\\n" + completed.stderr)
        return "\\n".join(parts)

    def _read_file(self, args: Dict[str, Any]) -> str:
        path = self._resolve(args["path"])
        if not path.exists():
            raise ToolError(f"File not found: {path}")
        if path.is_dir():
            entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            lines = []
            for entry in entries[:500]:
                suffix = "/" if entry.is_dir() else ""
                lines.append(f"{entry.name}{suffix}")
            return "\\n".join(lines)
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        offset = int(args.get("offset") or 1)
        limit = args.get("limit")
        start = max(offset - 1, 0)
        end = start + int(limit) if limit else len(lines)
        sliced = lines[start:end]
        numbered = [f"{i + start + 1:>6}|{line}" for i, line in enumerate(sliced)]
        return f"{path} ({len(lines)} lines)\\n" + "\\n".join(numbered)

    def _write_file(self, args: Dict[str, Any]) -> str:
        path = self._resolve(args["path"])
        content = args.get("content")
        if content is None:
            raise ToolError("content is required")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(str(content), encoding="utf-8")
        check = self._syntax_check({"path": str(path)})
        return f"Wrote {path} ({len(str(content))} bytes)\\n{check}"

    def _apply_patch(self, args: Dict[str, Any]) -> str:
        path = self._resolve(args["path"])
        if not path.exists():
            raise ToolError(f"File not found: {path}")
        original = path.read_text(encoding="utf-8", errors="replace")
        old_text = args.get("old_text")
        new_text = args.get("new_text")
        patch = args.get("patch")
        ratio = float(args.get("fuzzy_ratio") or 0.72)
        if old_text is not None and new_text is not None:
            updated = self._replace_fuzzy(original, str(old_text), str(new_text), ratio)
        elif patch:
            updated = self._apply_unified_or_block(original, str(patch), ratio)
        else:
            raise ToolError("Provide old_text/new_text or patch")
        if updated == original:
            raise ToolError("Patch produced no changes")
        path.write_text(updated, encoding="utf-8")
        check = self._syntax_check({"path": str(path)})
        diff = "".join(
            difflib.unified_diff(
                original.splitlines(True),
                updated.splitlines(True),
                fromfile=f"a/{path.name}",
                tofile=f"b/{path.name}",
            )
        )
        return f"Patched {path}\\n{diff}\\n{check}"

    def _replace_fuzzy(self, original: str, old: str, new: str, ratio: float) -> str:
        if old in original:
            if original.count(old) != 1:
                raise ToolError(f"old_text matched {original.count(old)} times; expected 1")
            return original.replace(old, new, 1)
        lines = original.splitlines(True)
        needle = old.splitlines(True) or [old]
        window = len(needle)
        best_i = -1
        best_score = 0.0
        for i in range(0, max(len(lines) - window + 1, 1)):
            chunk = "".join(lines[i : i + window])
            score = difflib.SequenceMatcher(None, chunk, old).ratio()
            if score > best_score:
                best_score = score
                best_i = i
        if best_i < 0 or best_score < ratio:
            raise ToolError(f"No fuzzy match above {ratio:.2f} (best={best_score:.2f})")
        return "".join(lines[:best_i]) + new + "".join(lines[best_i + window :])

    def _apply_unified_or_block(self, original: str, patch: str, ratio: float) -> str:
        if "@@" in patch or patch.lstrip().startswith(("---", "diff ")):
            return self._apply_unified_diff(original, patch)
        if "<<<<<<< SEARCH" in patch or "*** Begin Patch" in patch:
            return self._apply_search_replace_blocks(original, patch, ratio)
        raise ToolError("Unrecognized patch format")

    def _apply_unified_diff(self, original: str, patch: str) -> str:
        lines = original.splitlines(True)
        hunks = self._parse_hunks(patch)
        if not hunks:
            return self._apply_with_system_patch(original, patch)
        cursor = 0
        output: List[str] = []
        for old_start, _old_count, hunk_lines in hunks:
            target_index = max(old_start - 1, 0)
            old_buf: List[str] = []
            new_buf: List[str] = []
            for raw in hunk_lines:
                if not raw or raw.startswith("\\\\"):
                    continue
                tag, body = raw[0], raw[1:]
                if tag == " ":
                    old_buf.append(body)
                    new_buf.append(body)
                elif tag == "-":
                    old_buf.append(body)
                elif tag == "+":
                    new_buf.append(body)
            expected = "".join(old_buf)
            actual = "".join(lines[target_index : target_index + len(old_buf)])
            if expected and expected != actual:
                relocated = self._locate_hunk(lines, old_buf, target_index)
                if relocated is None:
                    raise ToolError("Failed to apply hunk; context mismatch")
                target_index = relocated
            if target_index < cursor:
                raise ToolError("Hunks out of order")
            output.extend(lines[cursor:target_index])
            output.extend(new_buf)
            cursor = target_index + len(old_buf)
        output.extend(lines[cursor:])
        return "".join(output)

    def _parse_hunks(self, patch: str) -> List[tuple]:
        hunks: List[tuple] = []
        hunk_re = re.compile(r"^@@ -(\\d+)(?:,(\\d+))? \\+(\\d+)(?:,(\\d+))? @@")
        current: Optional[List[str]] = None
        old_start = 0
        old_count = 0
        for line in patch.splitlines(True):
            match = hunk_re.match(line)
            if match:
                if current is not None:
                    hunks.append((old_start, old_count, current))
                old_start = int(match.group(1))
                old_count = int(match.group(2) or "1")
                current = []
                continue
            if current is not None and (line.startswith(("+", "-", " ")) or line.startswith("\\\\")):
                current.append(line if line.endswith("\\n") else line + "\\n")
        if current is not None:
            hunks.append((old_start, old_count, current))
        return hunks

    def _locate_hunk(self, lines: List[str], old_buf: List[str], hint: int) -> Optional[int]:
        expected = "".join(old_buf)
        window = len(old_buf)
        best_i = None
        best = 0.0
        start = max(hint - 200, 0)
        end = min(hint + 200, max(len(lines) - window + 1, 1))
        for i in range(start, end):
            chunk = "".join(lines[i : i + window])
            score = difflib.SequenceMatcher(None, chunk, expected).ratio()
            if score > best:
                best = score
                best_i = i
        if best_i is not None and best >= 0.72:
            return best_i
        return None

    def _apply_with_system_patch(self, original: str, patch: str) -> str:
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "file"
            diff = Path(tmp) / "file.diff"
            src.write_text(original, encoding="utf-8")
            diff.write_text(patch, encoding="utf-8")
            completed = subprocess.run(
                ["patch", "-p0", "--fuzz=3", str(src), str(diff)],
                capture_output=True,
                text=True,
            )
            if completed.returncode != 0:
                raise ToolError(f"patch(1) failed: {completed.stderr or completed.stdout}")
            return src.read_text(encoding="utf-8")

    def _apply_search_replace_blocks(self, original: str, patch: str, ratio: float) -> str:
        text = original
        blocks = re.findall(
            r"<<<<<<< SEARCH\\n(.*?)\\n=======\\n(.*?)\\n>>>>>>> REPLACE",
            patch,
            flags=re.DOTALL,
        )
        if not blocks:
            raise ToolError("No SEARCH/REPLACE blocks found")
        for old, new in blocks:
            text = self._replace_fuzzy(text, old, new, ratio)
        return text

    def _syntax_check(self, args: Dict[str, Any]) -> str:
        path = self._resolve(args["path"])
        if not path.exists():
            raise ToolError(f"File not found: {path}")
        suffix = path.suffix.lower()
        if suffix == ".py":
            try:
                py_compile.compile(str(path), doraise=True)
                return f"syntax_ok python {path}"
            except py_compile.PyCompileError as exc:
                return f"syntax_error python {path}\\n{exc}"
        if suffix in {".js", ".mjs", ".cjs", ".ts"}:
            node = shutil.which("node")
            if not node:
                return f"syntax_skipped {path} (node not found)"
            completed = subprocess.run(
                [node, "--check", str(path)],
                capture_output=True,
                text=True,
            )
            if completed.returncode == 0:
                return f"syntax_ok node {path}"
            return f"syntax_error node {path}\\n{completed.stderr or completed.stdout}"
        return f"syntax_skipped {path} (no checker for {suffix or 'unknown'})"

    def _find_symbol(self, args: Dict[str, Any]) -> str:
        name = str(args.get("name") or "").strip()
        if not name:
            raise ToolError("name is required")
        kind = str(args.get("kind") or "any")
        root = self._resolve(args["path"]) if args.get("path") else self.settings.workspace
        matches: List[str] = []
        files = [root] if root.is_file() else list(root.rglob("*.py"))
        for file_path in files:
            if not file_path.is_file():
                continue
            if any(part in {".git", "node_modules", "__pycache__", ".venv", "dist"} for part in file_path.parts):
                continue
            try:
                source = file_path.read_text(encoding="utf-8")
                tree = ast.parse(source)
            except (OSError, SyntaxError, UnicodeDecodeError):
                continue
            for node in ast.walk(tree):
                found = None
                if isinstance(node, ast.FunctionDef) and node.name == name:
                    found = "method" if self._is_method(tree, node) else "function"
                elif isinstance(node, ast.AsyncFunctionDef) and node.name == name:
                    found = "method" if self._is_method(tree, node) else "function"
                elif isinstance(node, ast.ClassDef) and node.name == name:
                    found = "class"
                elif isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id == name:
                            found = "assignment"
                if found and (kind == "any" or kind == found):
                    lineno = getattr(node, "lineno", 1)
                    matches.append(f"{file_path}:{lineno} [{found}] {name}")
        if not matches:
            return f"No symbols named '{name}'"
        return "\\n".join(matches[:200])

    @staticmethod
    def _is_method(tree: ast.AST, fn: ast.AST) -> bool:
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and fn in node.body:
                return True
        return False

    def _repo_map(self, args: Dict[str, Any]) -> str:
        root = self._resolve(args["path"]) if args.get("path") else self.settings.workspace
        max_files = int(args.get("max_files") or 400)
        max_depth = int(args.get("max_depth") or 8)
        skip = {".git", "node_modules", "__pycache__", ".venv", "dist", "build", ".omni_agent"}
        rows: List[str] = [f"repo_map {root}"]
        count = 0
        for dirpath, dirnames, filenames in os.walk(root):
            rel_dir = Path(dirpath).relative_to(root)
            depth = 0 if str(rel_dir) == "." else len(rel_dir.parts)
            if depth > max_depth:
                dirnames[:] = []
                continue
            dirnames[:] = [d for d in dirnames if d not in skip and not d.startswith(".")]
            for filename in sorted(filenames):
                if filename.startswith("."):
                    continue
                path = Path(dirpath) / filename
                rel = path.relative_to(root)
                symbols = self._top_symbols(path)
                suffix = f"  :: {', '.join(symbols)}" if symbols else ""
                rows.append(f"{rel}{suffix}")
                count += 1
                if count >= max_files:
                    rows.append(f"... truncated after {max_files} files")
                    return "\\n".join(rows)
        rows.append(f"{count} files")
        return "\\n".join(rows)

    def _top_symbols(self, path: Path) -> List[str]:
        if path.suffix != ".py" or path.stat().st_size > 400_000:
            return []
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except (OSError, SyntaxError, UnicodeDecodeError):
            return []
        names: List[str] = []
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                names.append(f"class {node.name}")
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                names.append(f"def {node.name}")
            if len(names) >= 8:
                break
        return names

    def _fetch_url(self, args: Dict[str, Any]) -> str:
        url = str(args.get("url") or "").strip()
        if not url:
            raise ToolError("url is required")
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            raise ToolError("Only http/https URLs are allowed")
        max_chars = int(args.get("max_chars") or 20_000)
        request = urllib.request.Request(
            url,
            headers={"User-Agent": "omni-agent/1.0 (+https://agentrouter.org)"},
        )
        with urllib.request.urlopen(request, timeout=20) as response:
            content_type = response.headers.get("Content-Type", "")
            raw = response.read(max_chars * 4)
        text = raw.decode("utf-8", errors="replace")
        if "application/json" in content_type:
            try:
                pretty = json.dumps(json.loads(text), indent=2)
                return pretty[:max_chars]
            except json.JSONDecodeError:
                return text[:max_chars]
        if "html" in content_type or text.lstrip().startswith("<"):
            extractor = _HTMLTextExtractor()
            extractor.feed(text)
            return extractor.text()[:max_chars]
        return text[:max_chars]

    def _daemon_control(self, args: Dict[str, Any]) -> str:
        action = str(args.get("action") or "")
        name = str(args.get("name") or "default")
        if action == "start":
            command = str(args.get("command") or "")
            if not command:
                raise ToolError("command is required to start a daemon")
            if self.settings.is_dangerous(command):
                raise ToolError("Blocked dangerous daemon command")
            return json.dumps(self.daemons.start(name, command, args.get("cwd")), indent=2)
        if action in {"stop", "kill"}:
            return json.dumps(self.daemons.stop(name, kill=action == "kill"), indent=2)
        if action == "status":
            return json.dumps(self.daemons.status(args.get("name")), indent=2)
        if action == "logs":
            return self.daemons.logs(name, tail=int(args.get("tail") or 80), stream=str(args.get("stream") or "stdout"))
        raise ToolError(f"Unknown daemon action: {action}")

    def _manage_tasks(self, args: Dict[str, Any]) -> str:
        action = str(args.get("action") or "")
        if action == "create":
            title = str(args.get("title") or "").strip()
            if not title:
                raise ToolError("title is required")
            return json.dumps(self.tasks.create(title, str(args.get("detail") or ""), str(args.get("priority") or "normal")), indent=2)
        if action == "update":
            return json.dumps(
                self.tasks.update(
                    str(args.get("id") or ""),
                    title=args.get("title"),
                    detail=args.get("detail"),
                    priority=args.get("priority"),
                    status=args.get("status"),
                ),
                indent=2,
            )
        if action == "complete":
            return json.dumps(self.tasks.update(str(args.get("id") or ""), status="complete"), indent=2)
        if action == "cancel":
            return json.dumps(self.tasks.update(str(args.get("id") or ""), status="cancelled"), indent=2)
        if action == "list":
            return json.dumps(self.tasks.list(args.get("status")), indent=2)
        raise ToolError(f"Unknown task action: {action}")

    def _select_best_option(self, args: Dict[str, Any]) -> str:
        goal = str(args.get("goal") or "").strip()
        options = args.get("options") or []
        criteria = args.get("criteria") or [
            {"name": "correctness", "weight": 0.35, "higher_is_better": True},
            {"name": "simplicity", "weight": 0.2, "higher_is_better": True},
            {"name": "risk", "weight": 0.2, "higher_is_better": False},
            {"name": "performance", "weight": 0.15, "higher_is_better": True},
            {"name": "maintainability", "weight": 0.1, "higher_is_better": True},
        ]
        if not options:
            raise ToolError("options are required")
        weights = {c["name"]: float(c.get("weight") or 1.0) for c in criteria}
        weight_sum = sum(weights.values()) or 1.0
        polarity = {c["name"]: bool(c.get("higher_is_better", True)) for c in criteria}
        ranked: List[Dict[str, Any]] = []
        for option in options:
            scores = dict(option.get("scores") or {})
            # Heuristic fill-ins from pros/cons counts when scores omitted
            pros = option.get("pros") or []
            cons = option.get("cons") or []
            if "correctness" not in scores:
                scores["correctness"] = 0.6 + 0.05 * len(pros) - 0.04 * len(cons)
            if "simplicity" not in scores:
                scores["simplicity"] = max(0.2, 0.8 - 0.05 * len(cons))
            if "risk" not in scores:
                scores["risk"] = min(0.9, 0.3 + 0.08 * len(cons))
            if "performance" not in scores:
                scores["performance"] = 0.55
            if "maintainability" not in scores:
                scores["maintainability"] = 0.5 + 0.04 * len(pros)
            total = 0.0
            breakdown = {}
            for name, weight in weights.items():
                value = float(scores.get(name, 0.5))
                value = max(0.0, min(1.0, value))
                if not polarity.get(name, True):
                    value = 1.0 - value
                contribution = value * (weight / weight_sum)
                breakdown[name] = round(contribution, 4)
                total += contribution
            ranked.append(
                {
                    "id": option.get("id"),
                    "summary": option.get("summary"),
                    "score": round(total, 4),
                    "breakdown": breakdown,
                    "pros": pros,
                    "cons": cons,
                }
            )
        ranked.sort(key=lambda item: item["score"], reverse=True)
        winner = ranked[0]
        rationale = (
            f"Goal: {goal}\\n"
            f"Recommended: {winner['id']} ({winner['score']:.3f}) — {winner['summary']}\\n"
            f"Why: highest weighted score across {', '.join(weights)}."
        )
        if len(ranked) > 1:
            rationale += f" Runner-up: {ranked[1]['id']} ({ranked[1]['score']:.3f})."
        return json.dumps({"recommendation": winner["id"], "rationale": rationale, "ranking": ranked}, indent=2)

    def _glob_search(self, args: Dict[str, Any]) -> str:
        pattern = str(args.get("pattern") or "")
        root = self._resolve(args["path"]) if args.get("path") else self.settings.workspace
        matches = [str(p.relative_to(self.settings.workspace)) for p in root.glob(pattern) if p.is_file()]
        if not matches:
            matches = [str(p.relative_to(self.settings.workspace)) for p in root.rglob(pattern) if p.is_file()]
        return "\\n".join(matches[:500]) or "No files matched"

    def _grep_search(self, args: Dict[str, Any]) -> str:
        pattern = re.compile(str(args.get("pattern") or ""))
        root = self._resolve(args["path"]) if args.get("path") else self.settings.workspace
        glob_pat = args.get("glob") or "*"
        max_matches = int(args.get("max_matches") or 80)
        hits: List[str] = []
        files = [root] if root.is_file() else root.rglob(glob_pat)
        for path in files:
            if not path.is_file():
                continue
            if any(part in {".git", "node_modules", "__pycache__", ".venv"} for part in path.parts):
                continue
            try:
                if path.stat().st_size > 1_000_000:
                    continue
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for i, line in enumerate(text.splitlines(), 1):
                if pattern.search(line):
                    rel = path.relative_to(self.settings.workspace)
                    hits.append(f"{rel}:{i}:{line.strip()}")
                    if len(hits) >= max_matches:
                        return "\\n".join(hits)
        return "\\n".join(hits) or "No matches"
`,"omni_agent/memory.py":`"""Context compaction, session persistence, multimodal encoding, and project rule injection."""

from __future__ import annotations

import base64
import json
import logging
import mimetypes
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence

from .config import PROJECT_RULE_FILENAMES, Settings, load_settings

logger = logging.getLogger("omni_agent.memory")

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}


def estimate_tokens(text: str) -> int:
    """Cheap token estimate (~4 chars/token with a floor for short strings)."""
    if not text:
        return 0
    return max(1, (len(text) + 3) // 4)


def estimate_messages_tokens(messages: Sequence[Dict[str, Any]]) -> int:
    total = 0
    for message in messages:
        total += 4
        content = message.get("content")
        if isinstance(content, str):
            total += estimate_tokens(content)
        elif isinstance(content, list):
            for block in content:
                if not isinstance(block, dict):
                    continue
                for key in ("text", "thinking", "data"):
                    if key in block and isinstance(block[key], str):
                        total += estimate_tokens(block[key])
                if "input" in block:
                    total += estimate_tokens(json.dumps(block["input"], default=str))
                if block.get("type") == "image" or block.get("type") == "image_url":
                    total += 1600
        total += estimate_tokens(str(message.get("role") or ""))
    return total


def flatten_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(str(block.get("text") or ""))
                elif block.get("type") == "tool_result":
                    parts.append(str(block.get("content") or ""))
                elif block.get("type") == "thinking":
                    parts.append(f"[thinking] {block.get('thinking') or ''}")
            else:
                parts.append(str(block))
        return "\\n".join(p for p in parts if p)
    return str(content or "")


@dataclass
class SessionState:
    messages: List[Dict[str, Any]] = field(default_factory=list)
    system: str = ""
    model: str = ""
    stats: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "messages": self.messages,
            "system": self.system,
            "model": self.model,
            "stats": self.stats,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "SessionState":
        return cls(
            messages=list(payload.get("messages") or []),
            system=str(payload.get("system") or ""),
            model=str(payload.get("model") or ""),
            stats=dict(payload.get("stats") or {}),
            created_at=float(payload.get("created_at") or time.time()),
            updated_at=float(payload.get("updated_at") or time.time()),
        )


class MemoryStore:
    """Persistent session memory with compaction and rule injection."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self.state = SessionState()
        self.load()

    def load(self) -> SessionState:
        path = self.settings.session_path
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(payload, dict):
                    self.state = SessionState.from_dict(payload)
            except json.JSONDecodeError:
                logger.warning("Corrupt session file at %s; starting fresh", path)
        return self.state

    def save(self) -> None:
        self.settings.ensure_session_dir()
        self.state.updated_at = time.time()
        tmp = self.settings.session_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self.state.to_dict(), indent=2), encoding="utf-8")
        tmp.replace(self.settings.session_path)

    def clear(self) -> None:
        self.state = SessionState(system=self.state.system, model=self.state.model)
        self.save()

    def append(self, message: Dict[str, Any]) -> None:
        self.state.messages.append(message)
        self.save()

    def extend(self, messages: Iterable[Dict[str, Any]]) -> None:
        self.state.messages.extend(list(messages))
        self.save()

    def load_project_rules(self, extra_paths: Sequence[Path] | None = None) -> str:
        chunks: List[str] = []
        seen: set[Path] = set()
        candidates: List[Path] = []
        root = self.settings.workspace
        for name in PROJECT_RULE_FILENAMES:
            candidates.append(root / name)
        if extra_paths:
            candidates.extend(extra_paths)
        for path in candidates:
            resolved = path.resolve()
            if resolved in seen or not resolved.exists() or not resolved.is_file():
                continue
            seen.add(resolved)
            try:
                text = resolved.read_text(encoding="utf-8").strip()
            except OSError:
                continue
            if text:
                chunks.append(f"# Project rules from {resolved.name}\\n{text}")
        return "\\n\\n".join(chunks)

    def build_system_prompt(self, base: str | None = None) -> str:
        parts = [
            base
            or (
                "You are Omni, an autonomous software engineering agent. "
                "Prefer precise, minimal diffs. Run syntax checks after edits. "
                "Use tools to inspect the repository before changing it. "
                "Never invent file contents you have not read."
            )
        ]
        rules = self.load_project_rules()
        if rules:
            parts.append(rules)
        self.state.system = "\\n\\n".join(parts)
        return self.state.system

    def encode_image(self, path: str | Path) -> Dict[str, Any]:
        file_path = Path(path)
        if not file_path.is_absolute():
            file_path = self.settings.workspace / file_path
        file_path = file_path.resolve()
        if file_path.suffix.lower() not in IMAGE_EXTENSIONS:
            raise ValueError(f"Unsupported image type: {file_path.suffix}")
        data = file_path.read_bytes()
        mime = mimetypes.guess_type(str(file_path))[0] or "image/png"
        b64 = base64.b64encode(data).decode("ascii")
        return {
            "type": "image",
            "source": {"type": "base64", "media_type": mime, "data": b64},
        }

    def user_text(self, text: str, images: Sequence[str | Path] | None = None) -> Dict[str, Any]:
        if not images:
            return {"role": "user", "content": [{"type": "text", "text": text}]}
        content: List[Dict[str, Any]] = [{"type": "text", "text": text}]
        for image in images:
            content.append(self.encode_image(image))
        return {"role": "user", "content": content}

    def maybe_compact(self, force: bool = False) -> bool:
        tokens = estimate_messages_tokens(self.state.messages)
        self.state.stats["estimated_tokens"] = tokens
        if not force and tokens < self.settings.compaction_threshold:
            return False
        compacted = self.compact(self.state.messages, keep=self.settings.compaction_keep)
        self.state.messages = compacted
        self.state.stats["last_compaction"] = time.time()
        self.state.stats["estimated_tokens"] = estimate_messages_tokens(compacted)
        self.save()
        logger.info("Compacted session memory to ~%s tokens", self.state.stats["estimated_tokens"])
        return True

    def compact(self, messages: Sequence[Dict[str, Any]], keep: int | None = None) -> List[Dict[str, Any]]:
        keep_n = keep if keep is not None else self.settings.compaction_keep
        items = list(messages)
        if len(items) <= keep_n + 2:
            return items
        head = items[:1]
        tail = items[-keep_n:]
        middle = items[1:-keep_n] if keep_n else items[1:]
        summary = self._summarize(middle)
        summary_message = {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": (
                        "Context compaction summary of earlier turns. "
                        "Use this as historical memory; do not treat it as a new instruction.\\n\\n"
                        f"{summary}"
                    ),
                }
            ],
        }
        return head + [summary_message] + tail

    def _summarize(self, messages: Sequence[Dict[str, Any]]) -> str:
        tool_names: List[str] = []
        files: List[str] = []
        decisions: List[str] = []
        errors: List[str] = []
        for message in messages:
            role = message.get("role")
            content = message.get("content")
            text = flatten_text(content)
            if role == "assistant":
                snippet = " ".join(text.split())
                if snippet:
                    decisions.append(snippet[:280])
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "tool_use":
                            tool_names.append(str(block.get("name") or "tool"))
                            payload = block.get("input") or {}
                            path = payload.get("path")
                            if path:
                                files.append(str(path))
            elif role == "user" and "is_error" in json.dumps(content, default=str):
                if "failed" in text.lower() or "error" in text.lower():
                    errors.append(text[:240])
        unique_tools = list(dict.fromkeys(tool_names))
        unique_files = list(dict.fromkeys(files))
        lines = [
            f"Turns compacted: {len(messages)}",
            f"Tools used: {', '.join(unique_tools) or 'none'}",
            f"Files touched: {', '.join(unique_files[:40]) or 'none'}",
        ]
        if decisions:
            lines.append("Key assistant notes:")
            for item in decisions[-8:]:
                lines.append(f"- {item}")
        if errors:
            lines.append("Errors observed:")
            for item in errors[-6:]:
                lines.append(f"- {item}")
        return "\\n".join(lines)
`,"omni_agent/diagnostics.py":`"""Git snapshot checkpoints and instant rollback for the /undo command."""

from __future__ import annotations

import json
import logging
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import Settings, load_settings

logger = logging.getLogger("omni_agent.diagnostics")


class DiagnosticsError(RuntimeError):
    pass


@dataclass
class Checkpoint:
    id: str
    created_at: float
    label: str
    method: str
    ref: str
    files: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "created_at": self.created_at,
            "label": self.label,
            "method": self.method,
            "ref": self.ref,
            "files": self.files,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "Checkpoint":
        return cls(
            id=str(payload.get("id") or ""),
            created_at=float(payload.get("created_at") or 0),
            label=str(payload.get("label") or ""),
            method=str(payload.get("method") or ""),
            ref=str(payload.get("ref") or ""),
            files=list(payload.get("files") or []),
        )


class Diagnostics:
    """Create restore points with \`git stash create\` and roll them back."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self._history: List[Checkpoint] = []
        self._load()

    def _load(self) -> None:
        path = self.settings.checkpoints_path
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                items = payload if isinstance(payload, list) else payload.get("checkpoints", [])
                self._history = [Checkpoint.from_dict(item) for item in items]
            except json.JSONDecodeError:
                self._history = []

    def _save(self) -> None:
        self.settings.ensure_session_dir()
        self.settings.checkpoints_path.write_text(
            json.dumps([item.to_dict() for item in self._history], indent=2),
            encoding="utf-8",
        )

    def _git(self, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args],
            cwd=str(self.settings.workspace),
            capture_output=True,
            text=True,
            check=check,
        )

    def is_git_repo(self) -> bool:
        result = self._git("rev-parse", "--is-inside-work-tree", check=False)
        return result.returncode == 0 and result.stdout.strip() == "true"

    def snapshot(self, label: str = "omni-checkpoint") -> Checkpoint:
        """Create a checkpoint. Prefers \`git stash create\` so the working tree is untouched."""
        created_at = time.time()
        ident = f"{int(created_at)}-{label.replace(' ', '-')[:24]}"
        files = self.changed_files()
        if self.is_git_repo():
            self._git("add", "-A", check=False)
            created = self._git("stash", "create", label, check=False)
            ref = created.stdout.strip()
            if created.returncode != 0 or not ref:
                # Fall back to a stash push that we immediately apply to restore the tree.
                pushed = self._git("stash", "push", "-u", "-m", label, check=False)
                if pushed.returncode != 0:
                    raise DiagnosticsError(pushed.stderr or "git stash push failed")
                ref = self._git("rev-parse", "stash@{0}").stdout.strip()
                self._git("stash", "apply", "stash@{0}", check=False)
            method = "git-stash-create"
        else:
            archive_dir = self.settings.session_dir / "snapshots" / ident
            archive_dir.mkdir(parents=True, exist_ok=True)
            self._copy_workspace(archive_dir)
            ref = str(archive_dir)
            method = "filesystem"
        checkpoint = Checkpoint(
            id=ident,
            created_at=created_at,
            label=label,
            method=method,
            ref=ref,
            files=files,
        )
        self._history.append(checkpoint)
        self._save()
        logger.info("Checkpoint %s via %s (%s)", checkpoint.id, method, ref)
        return checkpoint

    def undo(self, checkpoint_id: str | None = None) -> Checkpoint:
        if not self._history:
            raise DiagnosticsError("No checkpoints to undo")
        checkpoint = self._history[-1]
        if checkpoint_id:
            found = next((item for item in reversed(self._history) if item.id == checkpoint_id), None)
            if not found:
                raise DiagnosticsError(f"Unknown checkpoint: {checkpoint_id}")
            checkpoint = found
        if checkpoint.method.startswith("git"):
            if not self.is_git_repo():
                raise DiagnosticsError("Not a git repository; cannot restore git checkpoint")
            result = self._git("stash", "show", "-p", checkpoint.ref, check=False)
            apply = self._git("checkout", checkpoint.ref, "--", ".", check=False)
            if apply.returncode != 0:
                apply = self._git("stash", "apply", checkpoint.ref, check=False)
            if apply.returncode != 0:
                raise DiagnosticsError(apply.stderr or result.stderr or "Failed to restore checkpoint")
            self._git("reset", "HEAD", check=False)
        else:
            archive = Path(checkpoint.ref)
            if not archive.exists():
                raise DiagnosticsError(f"Snapshot directory missing: {archive}")
            self._restore_workspace(archive)
        logger.info("Rolled back to checkpoint %s", checkpoint.id)
        return checkpoint

    def diff(self) -> str:
        if self.is_git_repo():
            staged = self._git("diff", "--stat", check=False).stdout
            unstaged = self._git("diff", "--stat", "HEAD", check=False).stdout
            return (unstaged or staged or "Working tree clean").strip()
        files = self.changed_files()
        return "\\n".join(files) if files else "No tracked changes (non-git workspace)"

    def changed_files(self) -> List[str]:
        if not self.is_git_repo():
            return []
        result = self._git("status", "--porcelain", check=False)
        files = []
        for line in result.stdout.splitlines():
            path = line[3:].strip()
            if " -> " in path:
                path = path.split(" -> ", 1)[1]
            if path:
                files.append(path)
        return files

    def history(self) -> List[Checkpoint]:
        return list(self._history)

    def _copy_workspace(self, dest: Path) -> None:
        skip = {".git", ".omni_agent", "node_modules", "__pycache__", ".venv", "dist"}
        root = self.settings.workspace
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(root)
            if any(part in skip for part in rel.parts):
                continue
            target = dest / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())

    def _restore_workspace(self, archive: Path) -> None:
        skip = {".git", ".omni_agent", "node_modules", "__pycache__", ".venv", "dist"}
        root = self.settings.workspace
        for path in archive.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(archive)
            if any(part in skip for part in rel.parts):
                continue
            target = root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())
`,"omni_agent/test_runner.py":`"""Autonomous self-healing test runner that iterates until tests pass."""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

from .config import Settings, load_settings
from .diagnostics import Diagnostics
from .tools import ToolRegistry

logger = logging.getLogger("omni_agent.test_runner")

FixCallback = Callable[[str, "TestReport"], Optional[str]]


@dataclass
class TestReport:
    command: List[str]
    passed: bool
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int
    failures: List[str] = field(default_factory=list)
    attempts: int = 1

    def log_text(self) -> str:
        parts = [
            f"command: {' '.join(self.command)}",
            f"exit_code: {self.exit_code}",
            f"duration_ms: {self.duration_ms}",
            f"passed: {self.passed}",
        ]
        if self.stdout:
            parts.append("stdout:\\n" + self.stdout)
        if self.stderr:
            parts.append("stderr:\\n" + self.stderr)
        if self.failures:
            parts.append("failures:\\n- " + "\\n- ".join(self.failures))
        return "\\n".join(parts)


class TestRunner:
    """Detect, execute, and optionally self-heal a project's test suite."""

    def __init__(
        self,
        settings: Settings | None = None,
        tools: ToolRegistry | None = None,
        diagnostics: Diagnostics | None = None,
        fixer: FixCallback | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        self.tools = tools or ToolRegistry(self.settings)
        self.diagnostics = diagnostics or Diagnostics(self.settings)
        self.fixer = fixer

    def detect_command(self, explicit: Sequence[str] | None = None) -> List[str]:
        if explicit:
            return list(explicit)
        env_cmd = os.getenv("OMNI_TEST_COMMAND")
        if env_cmd:
            return env_cmd.split()
        root = self.settings.workspace
        if (root / "pyproject.toml").exists() or (root / "pytest.ini").exists() or list(root.glob("test_*.py")):
            if (root / "pyproject.toml").exists() or (root / "pytest.ini").exists() or (root / "tests").exists():
                return ["python", "-m", "pytest", "-q"]
        if (root / "package.json").exists():
            try:
                payload = json.loads((root / "package.json").read_text(encoding="utf-8"))
                scripts = payload.get("scripts") or {}
                if "test" in scripts:
                    return ["npm", "test", "--silent"]
            except json.JSONDecodeError:
                pass
        if (root / "Cargo.toml").exists():
            return ["cargo", "test"]
        if (root / "go.mod").exists():
            return ["go", "test", "./..."]
        python_tests = list(root.rglob("test_*.py"))
        if python_tests:
            return ["python", "-m", "unittest", "discover", "-q"]
        raise RuntimeError("Could not detect a test command. Pass one explicitly.")

    def run(self, command: Sequence[str] | None = None, timeout: float | None = None) -> TestReport:
        cmd = self.detect_command(command)
        started = time.monotonic()
        completed = subprocess.run(
            cmd,
            cwd=str(self.settings.workspace),
            capture_output=True,
            text=True,
            timeout=timeout or max(self.settings.tool_timeout, 180.0),
            env=os.environ.copy(),
        )
        duration_ms = int((time.monotonic() - started) * 1000)
        stdout = completed.stdout or ""
        stderr = completed.stderr or ""
        failures = self.parse_failures(stdout + "\\n" + stderr)
        report = TestReport(
            command=cmd,
            passed=completed.returncode == 0,
            exit_code=completed.returncode,
            stdout=stdout,
            stderr=stderr,
            duration_ms=duration_ms,
            failures=failures,
        )
        log_path = self._write_log(report)
        logger.info("Tests %s (log %s)", "passed" if report.passed else "failed", log_path)
        return report

    def heal(
        self,
        command: Sequence[str] | None = None,
        max_attempts: int = 5,
        fixer: FixCallback | None = None,
    ) -> TestReport:
        """Run tests, apply patches via fixer, and iterate until passing or attempts exhausted."""
        callback = fixer or self.fixer
        last: Optional[TestReport] = None
        checkpoint = None
        try:
            checkpoint = self.diagnostics.snapshot(label="pre-heal")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not snapshot before heal: %s", exc)
        for attempt in range(1, max_attempts + 1):
            report = self.run(command)
            report.attempts = attempt
            last = report
            if report.passed:
                return report
            if callback is None:
                return report
            logger.info("Heal attempt %s/%s with %s failure(s)", attempt, max_attempts, len(report.failures))
            patch_or_note = callback(report.log_text(), report)
            if not patch_or_note:
                logger.info("Fixer declined to patch; stopping")
                return report
            self._apply_fixer_output(patch_or_note)
        assert last is not None
        if checkpoint and not last.passed:
            logger.warning("Heal failed; leaving last patches in place (undo via diagnostics)")
        return last

    def parse_failures(self, log: str) -> List[str]:
        failures: List[str] = []
        patterns = [
            re.compile(r"^E\\s+.+$", re.MULTILINE),
            re.compile(r"FAIL:\\s+.+$", re.MULTILINE),
            re.compile(r"FAILED\\s+\\S+"),
            re.compile(r"AssertionError:.*"),
            re.compile(r"Error:\\s+.+$", re.MULTILINE),
            re.compile(r"●\\s+.+$", re.MULTILINE),
        ]
        for pattern in patterns:
            for match in pattern.findall(log):
                text = match.strip()
                if text and text not in failures:
                    failures.append(text)
        return failures[:50]

    def _apply_fixer_output(self, output: str) -> None:
        text = output.strip()
        if text.startswith("{") and text.endswith("}"):
            try:
                payload = json.loads(text)
            except json.JSONDecodeError:
                payload = None
            if isinstance(payload, dict) and payload.get("path"):
                if payload.get("old_text") is not None and payload.get("new_text") is not None:
                    self.tools.execute(
                        "apply_patch",
                        {
                            "path": payload["path"],
                            "old_text": payload["old_text"],
                            "new_text": payload["new_text"],
                        },
                    )
                    return
                if payload.get("content") is not None:
                    self.tools.execute("write_file", {"path": payload["path"], "content": payload["content"]})
                    return
        if "<<<<<<< SEARCH" in text or "@@" in text:
            path_match = re.search(r"^(?:\\+\\+\\+|---|\\*\\*\\* Update File:)\\s+([^\\s]+)", text, re.MULTILINE)
            if path_match:
                rel = path_match.group(1)
                rel = re.sub(r"^[ab]/", "", rel)
                self.tools.execute("apply_patch", {"path": rel, "patch": text})
                return
        logger.info("Fixer output treated as note only")

    def _write_log(self, report: TestReport) -> Path:
        log_dir = self.settings.session_dir / "test-logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        path = log_dir / f"test-{int(time.time())}.log"
        path.write_text(report.log_text(), encoding="utf-8")
        return path
`,"omni_agent/agent.py":`"""Core autonomous agent loop: stream, tool-use, compact, continue."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence

from .client import AgentRouterClient, StreamMessage
from .config import Settings, load_settings
from .diagnostics import Diagnostics
from .memory import MemoryStore
from .tools import ToolRegistry

logger = logging.getLogger("omni_agent.agent")

EventHandler = Callable[[str, Dict[str, Any]], None]


@dataclass
class TurnResult:
    text: str
    thinking: str
    stop_reason: Optional[str]
    tool_rounds: int
    usage: Dict[str, int] = field(default_factory=dict)
    duration_ms: int = 0
    message: Optional[StreamMessage] = None


class OmniAgent:
    """Production agent that drives the Anthropic-compatible tool loop."""

    def __init__(
        self,
        settings: Settings | None = None,
        client: AgentRouterClient | None = None,
        tools: ToolRegistry | None = None,
        memory: MemoryStore | None = None,
        diagnostics: Diagnostics | None = None,
        on_event: EventHandler | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        self.memory = memory or MemoryStore(self.settings)
        self.tools = tools or ToolRegistry(self.settings)
        self.diagnostics = diagnostics or Diagnostics(self.settings)
        self.on_event = on_event
        self.client = client or AgentRouterClient(self.settings, on_event=self._forward_event)
        self.stats: Dict[str, Any] = {
            "turns": 0,
            "tool_calls": 0,
            "errors": 0,
            "input_tokens": 0,
            "output_tokens": 0,
        }

    def _forward_event(self, kind: str, payload: Dict[str, Any]) -> None:
        if self.on_event:
            self.on_event(kind, payload)

    def _emit(self, kind: str, payload: Dict[str, Any]) -> None:
        if self.on_event:
            self.on_event(kind, payload)

    def run(self, prompt: str, images: Sequence[str] | None = None, snapshot: bool = True) -> TurnResult:
        if snapshot:
            try:
                self.diagnostics.snapshot(label="pre-turn")
            except Exception as exc:  # noqa: BLE001
                logger.warning("Checkpoint skipped: %s", exc)
        system = self.memory.build_system_prompt()
        user = self.memory.user_text(prompt, images)
        self.memory.append(user)
        return self._loop(system)

    def continue_turn(self) -> TurnResult:
        system = self.memory.state.system or self.memory.build_system_prompt()
        return self._loop(system)

    def _loop(self, system: str) -> TurnResult:
        started = time.monotonic()
        tool_rounds = 0
        last: Optional[StreamMessage] = None
        self.memory.maybe_compact()
        while True:
            last = self.client.stream(
                self.memory.state.messages,
                system=system,
                tools=self.tools.anthropic_tools(),
                model=self.memory.state.model or None,
            )
            self._accumulate_usage(last.usage)
            assistant = last.to_assistant_message()
            self.memory.append(assistant)
            if last.stop_reason == "tool_use" and last.tool_calls:
                tool_rounds += 1
                if tool_rounds > self.settings.max_tool_rounds:
                    logger.error("Max tool rounds exceeded")
                    break
                self._emit("tool_round", {"round": tool_rounds, "count": len(last.tool_calls)})
                results = self.tools.execute_blocks(last.tool_calls)
                self.stats["tool_calls"] += len(last.tool_calls)
                for result in results:
                    if result.get("is_error"):
                        self.stats["errors"] += 1
                    self._emit("tool_result", result)
                self.memory.append({"role": "user", "content": results})
                self.memory.maybe_compact()
                continue
            break
        self.stats["turns"] += 1
        duration_ms = int((time.monotonic() - started) * 1000)
        assert last is not None
        return TurnResult(
            text=last.text,
            thinking=last.thinking,
            stop_reason=last.stop_reason,
            tool_rounds=tool_rounds,
            usage=last.usage,
            duration_ms=duration_ms,
            message=last,
        )

    def _accumulate_usage(self, usage: Dict[str, int]) -> None:
        self.stats["input_tokens"] += int(usage.get("input_tokens") or 0)
        self.stats["output_tokens"] += int(usage.get("output_tokens") or 0)

    def plan(self, prompt: str) -> TurnResult:
        planning = (
            "Produce an implementation plan only. Do not edit files yet. "
            "List files to inspect, risks, and a numbered sequence of changes.\\n\\n"
            f"{prompt}"
        )
        return self.run(planning, snapshot=False)

    def set_model(self, model: str) -> str:
        resolved = self.client.resolve_model(model)
        self.memory.state.model = resolved
        self.memory.save()
        return resolved
`,"omni_agent/cli.py":`"""Interactive REPL with command history and slash-command routing."""

from __future__ import annotations

import argparse
import logging
import os
import shlex
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

from .agent import OmniAgent, TurnResult
from .config import Settings, load_settings
from .diagnostics import Diagnostics
from .memory import MemoryStore, estimate_messages_tokens
from .test_runner import TestRunner

try:
    import readline  # noqa: F401
except ImportError:  # pragma: no cover - Windows
    readline = None  # type: ignore[assignment]


logger = logging.getLogger("omni_agent.cli")

SLASH_COMMANDS = {
    "/help": "Show available slash commands",
    "/test": "Run the autonomous self-healing test runner",
    "/plan": "Ask the agent for an implementation plan without editing",
    "/image": "Attach an image to the next prompt: /image path/to/file.png prompt...",
    "/commit": "Create a git commit from the current diff",
    "/undo": "Roll back to the last checkpoint",
    "/diff": "Show the working tree diff",
    "/stats": "Print session statistics",
    "/clear": "Clear conversation memory",
    "/model": "Show or set the active model: /model [name]",
    "/exit": "Leave the REPL",
}


class OmniREPL:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self.settings.ensure_session_dir()
        self._configure_logging()
        self.memory = MemoryStore(self.settings)
        self.diagnostics = Diagnostics(self.settings)
        self.agent = OmniAgent(
            settings=self.settings,
            memory=self.memory,
            diagnostics=self.diagnostics,
            on_event=self._on_event,
        )
        self.tests = TestRunner(
            settings=self.settings,
            tools=self.agent.tools,
            diagnostics=self.diagnostics,
            fixer=self._heal_fixer,
        )
        self._setup_history()

    def _configure_logging(self) -> None:
        logging.basicConfig(
            level=os.getenv("OMNI_LOG_LEVEL", "INFO"),
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        )

    def _setup_history(self) -> None:
        if readline is None:
            return
        history = str(self.settings.history_path)
        try:
            readline.read_history_file(history)
        except FileNotFoundError:
            pass
        readline.set_history_length(1000)
        self._history_path = history

    def _save_history(self) -> None:
        if readline is None:
            return
        try:
            readline.write_history_file(getattr(self, "_history_path", str(self.settings.history_path)))
        except OSError:
            pass

    def _on_event(self, kind: str, payload: Dict[str, Any]) -> None:
        if kind == "thinking_delta":
            sys.stdout.write("")
            sys.stdout.flush()
        elif kind == "content_block_delta":
            delta = payload.get("delta") or {}
            if delta.get("type") == "text_delta":
                sys.stdout.write(str(delta.get("text") or ""))
                sys.stdout.flush()
        elif kind == "tool_round":
            print(f"\\n[tools] round {payload.get('round')} ({payload.get('count')} calls)")
        elif kind == "tool_result":
            name = payload.get("tool_use_id")
            flag = "error" if payload.get("is_error") else "ok"
            preview = str(payload.get("content") or "").splitlines()[:1]
            print(f"[tool {flag}] {name} {preview[0][:120] if preview else ''}")

    def run_forever(self) -> int:
        print("Omni Agent REPL. Type /help for commands, /exit to quit.")
        if not self.settings.auth_token:
            print("Warning: ANTHROPIC_AUTH_TOKEN is not set. Network calls will fail.")
        try:
            while True:
                try:
                    raw = input("omni> ").strip()
                except EOFError:
                    print()
                    break
                if not raw:
                    continue
                if raw.startswith("/"):
                    if self._dispatch_slash(raw):
                        break
                    continue
                self._chat(raw)
        finally:
            self._save_history()
        return 0

    def _dispatch_slash(self, raw: str) -> bool:
        parts = shlex.split(raw)
        command = parts[0]
        args = parts[1:]
        if command in {"/exit", "/quit"}:
            return True
        handlers = {
            "/help": self._cmd_help,
            "/test": self._cmd_test,
            "/plan": self._cmd_plan,
            "/image": self._cmd_image,
            "/commit": self._cmd_commit,
            "/undo": self._cmd_undo,
            "/diff": self._cmd_diff,
            "/stats": self._cmd_stats,
            "/clear": self._cmd_clear,
            "/model": self._cmd_model,
        }
        handler = handlers.get(command)
        if handler is None:
            print(f"Unknown command {command}. Try /help")
            return False
        try:
            handler(args)
        except Exception as exc:  # noqa: BLE001
            print(f"Command failed: {exc}")
            logger.debug(traceback.format_exc())
        return False

    def _cmd_help(self, _args: List[str]) -> None:
        width = max(len(k) for k in SLASH_COMMANDS)
        for name, desc in SLASH_COMMANDS.items():
            print(f"{name.ljust(width)}  {desc}")

    def _cmd_test(self, args: List[str]) -> None:
        command = args or None
        print("Running self-healing test loop...")
        report = self.tests.heal(command=command, max_attempts=5)
        print(report.log_text())
        print("PASS" if report.passed else "FAIL")

    def _heal_fixer(self, log_text: str, report: Any) -> Optional[str]:
        prompt = (
            "The test suite failed. Inspect the log, edit the repository with tools, "
            "and stop when you believe tests will pass. Do not explain at length.\\n\\n"
            f"{log_text}"
        )
        result = self.agent.run(prompt, snapshot=False)
        return result.text or "attempted-fix"

    def _cmd_plan(self, args: List[str]) -> None:
        prompt = " ".join(args) or "Plan the next implementation steps for this repository."
        result = self.agent.plan(prompt)
        self._print_result(result)

    def _cmd_image(self, args: List[str]) -> None:
        if not args:
            print("Usage: /image path/to/file.png [prompt]")
            return
        image = args[0]
        prompt = " ".join(args[1:]) or "Describe this image and apply any implied engineering task."
        result = self.agent.run(prompt, images=[image])
        self._print_result(result)

    def _cmd_commit(self, args: List[str]) -> None:
        message = " ".join(args) or "chore: omni agent checkpoint"
        diff = self.diagnostics.diff()
        print(diff)
        self.agent.tools.execute("bash", {"command": "git add -A"})
        quoted = message.replace('"', '\\\\"')
        result = self.agent.tools.execute("bash", {"command": f'git commit -m "{quoted}"'})
        print(result.output)

    def _cmd_undo(self, args: List[str]) -> None:
        ident = args[0] if args else None
        checkpoint = self.diagnostics.undo(ident)
        print(f"Restored checkpoint {checkpoint.id} ({checkpoint.method})")

    def _cmd_diff(self, _args: List[str]) -> None:
        print(self.diagnostics.diff())

    def _cmd_stats(self, _args: List[str]) -> None:
        tokens = estimate_messages_tokens(self.memory.state.messages)
        print(f"model: {self.memory.state.model or self.agent.client.resolve_model()}")
        print(f"messages: {len(self.memory.state.messages)}")
        print(f"estimated_tokens: {tokens}")
        print(f"turns: {self.agent.stats['turns']}")
        print(f"tool_calls: {self.agent.stats['tool_calls']}")
        print(f"errors: {self.agent.stats['errors']}")
        print(f"input_tokens: {self.agent.stats['input_tokens']}")
        print(f"output_tokens: {self.agent.stats['output_tokens']}")
        print(f"checkpoints: {len(self.diagnostics.history())}")

    def _cmd_clear(self, _args: List[str]) -> None:
        self.memory.clear()
        print("Session memory cleared")

    def _cmd_model(self, args: List[str]) -> None:
        if not args:
            try:
                models = self.agent.client.discover_models()
            except Exception as exc:  # noqa: BLE001
                print(f"Could not list models: {exc}")
                models = []
            current = self.memory.state.model or self.settings.model or "(auto)"
            print(f"current: {current}")
            for item in models[:40]:
                ident = item.get("id") if isinstance(item, dict) else item
                print(f"- {ident}")
            return
        resolved = self.agent.set_model(args[0])
        print(f"model set to {resolved}")

    def _chat(self, prompt: str) -> None:
        try:
            result = self.agent.run(prompt)
            self._print_result(result)
        except Exception as exc:  # noqa: BLE001
            print(f"\\nAgent error: {exc}")
            logger.debug(traceback.format_exc())

    def _print_result(self, result: TurnResult) -> None:
        if result.text and not result.text.endswith("\\n"):
            print()
        if result.thinking:
            print(f"\\n[thinking {len(result.thinking)} chars]")
        print(f"[stop={result.stop_reason} tools={result.tool_rounds} {result.duration_ms}ms]")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="omni_agent", description="Omni autonomous engineering agent")
    parser.add_argument("prompt", nargs="*", help="Optional one-shot prompt")
    parser.add_argument("--workspace", default=None, help="Workspace root")
    parser.add_argument("--model", default=None, help="Model id override")
    parser.add_argument("--repl", action="store_true", help="Force interactive REPL")
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    settings = load_settings(args.workspace)
    repl = OmniREPL(settings)
    if args.model:
        repl.agent.set_model(args.model)
    if args.prompt and not args.repl:
        result = repl.agent.run(" ".join(args.prompt))
        if result.text:
            print(result.text)
        return 0
    return repl.run_forever()
`,"omni_agent/README.md":"# Omni Agent\n\nProduction-grade autonomous software engineering agent (`omni_agent`).\n\nThe framework talks to the AgentRouter Anthropic-compatible proxy with live SSE streaming, extended thinking (`thinking_delta`), model auto-discovery, and auto-continuation on `max_tokens`.\n\n## Package layout\n\n| Module | Responsibility |\n| --- | --- |\n| `config.py` | Environment, endpoints, token budgets, dangerous-command patterns |\n| `client.py` | Resilient HTTP + SSE, retries, thinking blocks, `/v1/models` |\n| `tools.py` | Tool registry: bash, files, fuzzy patch, AST search, repo map, fetch, daemons, tasks, trade-offs |\n| `memory.py` | Compaction, session JSON, base64 images, `CLAUDE.md` / `AGENT.md` injection |\n| `diagnostics.py` | `git stash create` checkpoints and `/undo` rollback |\n| `test_runner.py` | Detect tests, capture logs, iterate patches until green |\n| `agent.py` | Tool-use loop with compaction and continuation |\n| `cli.py` | REPL, history, slash commands |\n\n## Protocol\n\n- Base URL: `ANTHROPIC_BASE_URL` or `https://agentrouter.org`\n- Messages: `/v1/messages`\n- Models: `/v1/models`\n- Headers: `Authorization`, `x-api-key`, `anthropic-version: 2023-06-01`, `anthropic-beta: claude-code-20250219,interleaved-thinking-2025-05-14`, `x-app: cli`, `User-Agent: claude-cli/2.1.158 (external, sdk-cli)`\n\n## Environment\n\n| Variable | Purpose |\n| --- | --- |\n| `ANTHROPIC_AUTH_TOKEN` | Bearer and x-api-key token |\n| `ANTHROPIC_BASE_URL` | Proxy origin |\n| `OMNI_MODEL` | Preferred model id |\n| `OMNI_MAX_TOKENS` | Completion budget |\n| `OMNI_THINKING_BUDGET` | Extended thinking budget |\n| `OMNI_ALLOW_DANGEROUS` | Permit blocked shell patterns |\n| `OMNI_SESSION_DIR` | Persistence directory |\n\n## Slash commands\n\n`/test` `/plan` `/image` `/commit` `/undo` `/diff` `/stats` `/clear` `/model` `/help` `/exit`\n\n## Tools\n\n`bash` `read_file` `write_file` `apply_patch` `syntax_check` `find_symbol` `repo_map` `fetch_url` `daemon_control` `manage_tasks` `select_best_option` `glob_search` `grep_search`\n\n`apply_patch` uses exact then difflib fuzzy matching. `syntax_check` runs `py_compile` or `node --check`. `find_symbol` walks Python ASTs. `select_best_option` ranks weighted trade-offs.\n","setup.py":`from setuptools import find_packages, setup

setup(
    name="omni_agent",
    version="1.0.0",
    description="Production-grade autonomous software engineering agent framework",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Omni Agent",
    license="MIT",
    packages=find_packages(exclude=("tests", "tests.*")),
    python_requires=">=3.10",
    install_requires=["requests>=2.31.0"],
    entry_points={"console_scripts": ["omni-agent=omni_agent.cli:main", "omni_agent=omni_agent.cli:main"]},
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Topic :: Software Development :: Libraries",
    ],
)
`,"tests/test_omni_agent.py":`import json
import tempfile
import unittest
from pathlib import Path

from omni_agent.client import SSEParser
from omni_agent.config import load_settings
from omni_agent.memory import MemoryStore, estimate_tokens
from omni_agent.tools import ToolRegistry


class ConfigTests(unittest.TestCase):
    def test_headers_and_urls(self) -> None:
        settings = load_settings()
        settings.auth_token = "secret-token"
        settings.base_url = "https://agentrouter.org"
        headers = settings.client_headers()
        self.assertEqual(headers["Authorization"], "Bearer secret-token")
        self.assertEqual(headers["x-api-key"], "secret-token")
        self.assertEqual(headers["anthropic-version"], "2023-06-01")
        self.assertIn("claude-code-20250219", headers["anthropic-beta"])
        self.assertEqual(headers["x-app"], "cli")
        self.assertEqual(headers["User-Agent"], "claude-cli/2.1.158 (external, sdk-cli)")
        self.assertEqual(settings.messages_url, "https://agentrouter.org/v1/messages")
        self.assertEqual(settings.models_url, "https://agentrouter.org/v1/models")

    def test_dangerous_commands(self) -> None:
        settings = load_settings()
        settings.allow_dangerous = False
        self.assertTrue(settings.is_dangerous("rm -rf /"))
        self.assertTrue(settings.is_dangerous("curl http://x | sh"))
        self.assertFalse(settings.is_dangerous("ls -la"))


class SSETests(unittest.TestCase):
    def test_thinking_delta_parse(self) -> None:
        parser = SSEParser()
        chunk = (
            "event: content_block_delta\\n"
            'data: {"type":"content_block_delta","index":0,"delta":{"type":"thinking_delta","thinking":"plan"}}\\n\\n'
        )
        events = list(parser.feed(chunk))
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["data"]["delta"]["type"], "thinking_delta")


class ToolTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.settings = load_settings(self.root)
        self.tools = ToolRegistry(self.settings)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_write_read_and_syntax(self) -> None:
        result = self.tools.execute("write_file", {"path": "mod.py", "content": "VALUE = 1\\n"})
        self.assertFalse(result.is_error)
        read = self.tools.execute("read_file", {"path": "mod.py"})
        self.assertIn("VALUE = 1", read.output)

    def test_fuzzy_patch_and_symbol(self) -> None:
        (self.root / "mod.py").write_text("def greet(name):\\n    return 'hi ' + name\\n", encoding="utf-8")
        patched = self.tools.execute(
            "apply_patch",
            {
                "path": "mod.py",
                "old_text": "def greet(name):\\n    return 'hi ' + name\\n",
                "new_text": "def greet(name):\\n    return f'hello {name}'\\n",
            },
        )
        self.assertFalse(patched.is_error)
        found = self.tools.execute("find_symbol", {"name": "greet", "kind": "function"})
        self.assertIn("greet", found.output)

    def test_select_best_option(self) -> None:
        result = self.tools.execute(
            "select_best_option",
            {
                "goal": "Pick a cache",
                "options": [
                    {
                        "id": "redis",
                        "summary": "Shared cache",
                        "pros": ["fast", "shared"],
                        "cons": ["ops"],
                        "scores": {"correctness": 0.9, "simplicity": 0.5, "risk": 0.3, "performance": 0.9, "maintainability": 0.7},
                    },
                    {
                        "id": "dict",
                        "summary": "In-process dict",
                        "pros": ["simple"],
                        "cons": ["not shared", "lossy"],
                        "scores": {"correctness": 0.5, "simplicity": 0.9, "risk": 0.6, "performance": 0.6, "maintainability": 0.8},
                    },
                ],
            },
        )
        payload = json.loads(result.output)
        self.assertEqual(payload["recommendation"], "redis")

    def test_manage_tasks(self) -> None:
        created = json.loads(
            self.tools.execute("manage_tasks", {"action": "create", "title": "Ship patch"}).output
        )
        listed = json.loads(self.tools.execute("manage_tasks", {"action": "list"}).output)
        self.assertEqual(listed[0]["id"], created["id"])

    def test_repo_map(self) -> None:
        (self.root / "pkg").mkdir()
        (self.root / "pkg" / "a.py").write_text("class Thing:\\n    pass\\n", encoding="utf-8")
        mapped = self.tools.execute("repo_map", {})
        self.assertIn("pkg/a.py", mapped.output)
        self.assertIn("class Thing", mapped.output)


class MemoryTests(unittest.TestCase):
    def test_compaction_and_rules(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        (root / "AGENT.md").write_text("Prefer small diffs.", encoding="utf-8")
        settings = load_settings(root)
        memory = MemoryStore(settings)
        system = memory.build_system_prompt()
        self.assertIn("Prefer small diffs", system)
        for i in range(40):
            memory.append({"role": "user", "content": [{"type": "text", "text": f"msg {i} " * 200}]})
        compacted = memory.compact(memory.state.messages, keep=4)
        self.assertLess(len(compacted), 40)
        self.assertIn("Context compaction summary", compacted[1]["content"][0]["text"])
        self.assertGreater(estimate_tokens("abcd"), 0)
        tmp.cleanup()


if __name__ == "__main__":
    unittest.main()
`,"requirements.txt":`requests>=2.31.0
`},o=r(),s=Object.keys(a).sort();function c({initialFile:e}){let t=e&&a[e]?e:`omni_agent/agent.py`,[r,c]=(0,i.useState)(t),l=a[r]??``,u=(0,i.useMemo)(()=>l.split(`
`),[l]);return(0,o.jsxs)(`div`,{className:`mx-auto max-w-6xl`,children:[(0,o.jsx)(`h1`,{className:`text-4xl sm:text-5xl`,children:`Source`}),(0,o.jsx)(`p`,{className:`mt-3 max-w-2xl text-muted`,children:`Complete package, no stubs. Select a module to read the implementation that ships in the zip.`}),(0,o.jsxs)(`div`,{className:`mt-8 grid gap-4 lg:grid-cols-4`,children:[(0,o.jsx)(`div`,{className:`rounded-lg border border-border bg-surface p-2 lg:col-span-1`,children:(0,o.jsx)(`ul`,{className:`max-h-56 overflow-auto lg:max-h-screen`,children:s.map(e=>(0,o.jsx)(`li`,{children:(0,o.jsx)(`button`,{type:`button`,onClick:()=>c(e),className:n(`flex min-h-11 w-full items-center rounded-sm px-3 py-2 text-left font-mono text-xs`,r===e?`bg-elevated text-fg`:`text-muted hover:text-fg`),children:e.replace(`omni_agent/`,``)})},e))})}),(0,o.jsxs)(`div`,{className:`overflow-hidden rounded-lg border border-border bg-bg lg:col-span-3`,children:[(0,o.jsxs)(`div`,{className:`flex items-center justify-between border-b border-border px-4 py-3`,children:[(0,o.jsx)(`p`,{className:`truncate font-mono text-xs text-muted`,children:r}),(0,o.jsxs)(`p`,{className:`font-mono text-xs tabular-nums text-subtle`,children:[u.length,` lines`]})]}),(0,o.jsx)(`pre`,{className:`max-h-screen overflow-auto p-4 font-mono text-xs leading-5 text-fg`,children:u.map((e,t)=>(0,o.jsxs)(`div`,{className:`flex gap-4`,children:[(0,o.jsx)(`span`,{className:`w-8 shrink-0 select-none text-right text-subtle tabular-nums`,children:t+1}),(0,o.jsx)(`span`,{className:`whitespace-pre`,children:e||` `})]},t))})]})]})]})}function l(){return(0,o.jsx)(c,{})}export{l as component};