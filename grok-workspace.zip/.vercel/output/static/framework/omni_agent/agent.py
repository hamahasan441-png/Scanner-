"""Core autonomous agent loop: stream, tool-use, compact, continue."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence

from .client import AgentRouterClient, StreamMessage
from .config import Settings, load_settings
from .diagnostics import Diagnostics
from .memory import MemoryStore
from .tools import ToolRegistry

logger = logging.getLogger("omni_agent.agent")

EventHandler = Callable[[str, Dict[str, Any]], None]


@dataclass
class TurnResult:
    text: str
    thinking: str
    stop_reason: Optional[str]
    tool_rounds: int
    usage: Dict[str, int] = field(default_factory=dict)
    duration_ms: int = 0
    message: Optional[StreamMessage] = None


class OmniAgent:
    """Production agent that drives the Anthropic-compatible tool loop."""

    def __init__(
        self,
        settings: Settings | None = None,
        client: AgentRouterClient | None = None,
        tools: ToolRegistry | None = None,
        memory: MemoryStore | None = None,
        diagnostics: Diagnostics | None = None,
        on_event: EventHandler | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        self.memory = memory or MemoryStore(self.settings)
        self.tools = tools or ToolRegistry(self.settings)
        self.diagnostics = diagnostics or Diagnostics(self.settings)
        self.on_event = on_event
        self.client = client or AgentRouterClient(self.settings, on_event=self._forward_event)
        self.stats: Dict[str, Any] = {
            "turns": 0,
            "tool_calls": 0,
            "errors": 0,
            "input_tokens": 0,
            "output_tokens": 0,
        }

    def _forward_event(self, kind: str, payload: Dict[str, Any]) -> None:
        if self.on_event:
            self.on_event(kind, payload)

    def _emit(self, kind: str, payload: Dict[str, Any]) -> None:
        if self.on_event:
            self.on_event(kind, payload)

    def run(self, prompt: str, images: Sequence[str] | None = None, snapshot: bool = True) -> TurnResult:
        if snapshot:
            try:
                self.diagnostics.snapshot(label="pre-turn")
            except Exception as exc:  # noqa: BLE001
                logger.warning("Checkpoint skipped: %s", exc)
        system = self.memory.build_system_prompt()
        user = self.memory.user_text(prompt, images)
        self.memory.append(user)
        return self._loop(system)

    def continue_turn(self) -> TurnResult:
        system = self.memory.state.system or self.memory.build_system_prompt()
        return self._loop(system)

    def _loop(self, system: str) -> TurnResult:
        started = time.monotonic()
        tool_rounds = 0
        last: Optional[StreamMessage] = None
        self.memory.maybe_compact()
        while True:
            last = self.client.stream(
                self.memory.state.messages,
                system=system,
                tools=self.tools.anthropic_tools(),
                model=self.memory.state.model or None,
            )
            self._accumulate_usage(last.usage)
            assistant = last.to_assistant_message()
            self.memory.append(assistant)
            if last.stop_reason == "tool_use" and last.tool_calls:
                tool_rounds += 1
                if tool_rounds > self.settings.max_tool_rounds:
                    logger.error("Max tool rounds exceeded")
                    break
                self._emit("tool_round", {"round": tool_rounds, "count": len(last.tool_calls)})
                results = self.tools.execute_blocks(last.tool_calls)
                self.stats["tool_calls"] += len(last.tool_calls)
                for result in results:
                    if result.get("is_error"):
                        self.stats["errors"] += 1
                    self._emit("tool_result", result)
                self.memory.append({"role": "user", "content": results})
                self.memory.maybe_compact()
                continue
            break
        self.stats["turns"] += 1
        duration_ms = int((time.monotonic() - started) * 1000)
        assert last is not None
        return TurnResult(
            text=last.text,
            thinking=last.thinking,
            stop_reason=last.stop_reason,
            tool_rounds=tool_rounds,
            usage=last.usage,
            duration_ms=duration_ms,
            message=last,
        )

    def _accumulate_usage(self, usage: Dict[str, int]) -> None:
        self.stats["input_tokens"] += int(usage.get("input_tokens") or 0)
        self.stats["output_tokens"] += int(usage.get("output_tokens") or 0)

    def plan(self, prompt: str) -> TurnResult:
        planning = (
            "Produce an implementation plan only. Do not edit files yet. "
            "List files to inspect, risks, and a numbered sequence of changes.\n\n"
            f"{prompt}"
        )
        return self.run(planning, snapshot=False)

    def set_model(self, model: str) -> str:
        resolved = self.client.resolve_model(model)
        self.memory.state.model = resolved
        self.memory.save()
        return resolved
