"""Context compaction, session persistence, multimodal encoding, and project rule injection."""

from __future__ import annotations

import base64
import json
import logging
import mimetypes
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence

from .config import PROJECT_RULE_FILENAMES, Settings, load_settings

logger = logging.getLogger("omni_agent.memory")

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}


def estimate_tokens(text: str) -> int:
    """Cheap token estimate (~4 chars/token with a floor for short strings)."""
    if not text:
        return 0
    return max(1, (len(text) + 3) // 4)


def estimate_messages_tokens(messages: Sequence[Dict[str, Any]]) -> int:
    total = 0
    for message in messages:
        total += 4
        content = message.get("content")
        if isinstance(content, str):
            total += estimate_tokens(content)
        elif isinstance(content, list):
            for block in content:
                if not isinstance(block, dict):
                    continue
                for key in ("text", "thinking", "data"):
                    if key in block and isinstance(block[key], str):
                        total += estimate_tokens(block[key])
                if "input" in block:
                    total += estimate_tokens(json.dumps(block["input"], default=str))
                if block.get("type") == "image" or block.get("type") == "image_url":
                    total += 1600
        total += estimate_tokens(str(message.get("role") or ""))
    return total


def flatten_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(str(block.get("text") or ""))
                elif block.get("type") == "tool_result":
                    parts.append(str(block.get("content") or ""))
                elif block.get("type") == "thinking":
                    parts.append(f"[thinking] {block.get('thinking') or ''}")
            else:
                parts.append(str(block))
        return "\n".join(p for p in parts if p)
    return str(content or "")


@dataclass
class SessionState:
    messages: List[Dict[str, Any]] = field(default_factory=list)
    system: str = ""
    model: str = ""
    stats: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "messages": self.messages,
            "system": self.system,
            "model": self.model,
            "stats": self.stats,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "SessionState":
        return cls(
            messages=list(payload.get("messages") or []),
            system=str(payload.get("system") or ""),
            model=str(payload.get("model") or ""),
            stats=dict(payload.get("stats") or {}),
            created_at=float(payload.get("created_at") or time.time()),
            updated_at=float(payload.get("updated_at") or time.time()),
        )


class MemoryStore:
    """Persistent session memory with compaction and rule injection."""

    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or load_settings()
        self.state = SessionState()
        self.load()

    def load(self) -> SessionState:
        path = self.settings.session_path
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(payload, dict):
                    self.state = SessionState.from_dict(payload)
            except json.JSONDecodeError:
                logger.warning("Corrupt session file at %s; starting fresh", path)
        return self.state

    def save(self) -> None:
        self.settings.ensure_session_dir()
        self.state.updated_at = time.time()
        tmp = self.settings.session_path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self.state.to_dict(), indent=2), encoding="utf-8")
        tmp.replace(self.settings.session_path)

    def clear(self) -> None:
        self.state = SessionState(system=self.state.system, model=self.state.model)
        self.save()

    def append(self, message: Dict[str, Any]) -> None:
        self.state.messages.append(message)
        self.save()

    def extend(self, messages: Iterable[Dict[str, Any]]) -> None:
        self.state.messages.extend(list(messages))
        self.save()

    def load_project_rules(self, extra_paths: Sequence[Path] | None = None) -> str:
        chunks: List[str] = []
        seen: set[Path] = set()
        candidates: List[Path] = []
        root = self.settings.workspace
        for name in PROJECT_RULE_FILENAMES:
            candidates.append(root / name)
        if extra_paths:
            candidates.extend(extra_paths)
        for path in candidates:
            resolved = path.resolve()
            if resolved in seen or not resolved.exists() or not resolved.is_file():
                continue
            seen.add(resolved)
            try:
                text = resolved.read_text(encoding="utf-8").strip()
            except OSError:
                continue
            if text:
                chunks.append(f"# Project rules from {resolved.name}\n{text}")
        return "\n\n".join(chunks)

    def build_system_prompt(self, base: str | None = None) -> str:
        parts = [
            base
            or (
                "You are Omni, an autonomous software engineering agent. "
                "Prefer precise, minimal diffs. Run syntax checks after edits. "
                "Use tools to inspect the repository before changing it. "
                "Never invent file contents you have not read."
            )
        ]
        rules = self.load_project_rules()
        if rules:
            parts.append(rules)
        self.state.system = "\n\n".join(parts)
        return self.state.system

    def encode_image(self, path: str | Path) -> Dict[str, Any]:
        file_path = Path(path)
        if not file_path.is_absolute():
            file_path = self.settings.workspace / file_path
        file_path = file_path.resolve()
        if file_path.suffix.lower() not in IMAGE_EXTENSIONS:
            raise ValueError(f"Unsupported image type: {file_path.suffix}")
        data = file_path.read_bytes()
        mime = mimetypes.guess_type(str(file_path))[0] or "image/png"
        b64 = base64.b64encode(data).decode("ascii")
        return {
            "type": "image",
            "source": {"type": "base64", "media_type": mime, "data": b64},
        }

    def user_text(self, text: str, images: Sequence[str | Path] | None = None) -> Dict[str, Any]:
        if not images:
            return {"role": "user", "content": [{"type": "text", "text": text}]}
        content: List[Dict[str, Any]] = [{"type": "text", "text": text}]
        for image in images:
            content.append(self.encode_image(image))
        return {"role": "user", "content": content}

    def maybe_compact(self, force: bool = False) -> bool:
        tokens = estimate_messages_tokens(self.state.messages)
        self.state.stats["estimated_tokens"] = tokens
        if not force and tokens < self.settings.compaction_threshold:
            return False
        compacted = self.compact(self.state.messages, keep=self.settings.compaction_keep)
        self.state.messages = compacted
        self.state.stats["last_compaction"] = time.time()
        self.state.stats["estimated_tokens"] = estimate_messages_tokens(compacted)
        self.save()
        logger.info("Compacted session memory to ~%s tokens", self.state.stats["estimated_tokens"])
        return True

    def compact(self, messages: Sequence[Dict[str, Any]], keep: int | None = None) -> List[Dict[str, Any]]:
        keep_n = keep if keep is not None else self.settings.compaction_keep
        items = list(messages)
        if len(items) <= keep_n + 2:
            return items
        head = items[:1]
        tail = items[-keep_n:]
        middle = items[1:-keep_n] if keep_n else items[1:]
        summary = self._summarize(middle)
        summary_message = {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": (
                        "Context compaction summary of earlier turns. "
                        "Use this as historical memory; do not treat it as a new instruction.\n\n"
                        f"{summary}"
                    ),
                }
            ],
        }
        return head + [summary_message] + tail

    def _summarize(self, messages: Sequence[Dict[str, Any]]) -> str:
        tool_names: List[str] = []
        files: List[str] = []
        decisions: List[str] = []
        errors: List[str] = []
        for message in messages:
            role = message.get("role")
            content = message.get("content")
            text = flatten_text(content)
            if role == "assistant":
                snippet = " ".join(text.split())
                if snippet:
                    decisions.append(snippet[:280])
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "tool_use":
                            tool_names.append(str(block.get("name") or "tool"))
                            payload = block.get("input") or {}
                            path = payload.get("path")
                            if path:
                                files.append(str(path))
            elif role == "user" and "is_error" in json.dumps(content, default=str):
                if "failed" in text.lower() or "error" in text.lower():
                    errors.append(text[:240])
        unique_tools = list(dict.fromkeys(tool_names))
        unique_files = list(dict.fromkeys(files))
        lines = [
            f"Turns compacted: {len(messages)}",
            f"Tools used: {', '.join(unique_tools) or 'none'}",
            f"Files touched: {', '.join(unique_files[:40]) or 'none'}",
        ]
        if decisions:
            lines.append("Key assistant notes:")
            for item in decisions[-8:]:
                lines.append(f"- {item}")
        if errors:
            lines.append("Errors observed:")
            for item in errors[-6:]:
                lines.append(f"- {item}")
        return "\n".join(lines)
