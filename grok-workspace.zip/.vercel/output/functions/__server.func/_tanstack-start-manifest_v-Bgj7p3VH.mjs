//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bgj7p3VH.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/architecture",
			"/console",
			"/protocol",
			"/source",
			"/tools"
		],
		preloads: ["/assets/index-DcUb8NoJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DcUb8NoJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D_E2osy2.js", "/assets/button-yYfwkLca.js"]
	},
	"/architecture": {
		filePath: "/workspace/src/routes/architecture.tsx",
		children: void 0,
		preloads: ["/assets/architecture-CzNMbY5X.js"]
	},
	"/console": {
		filePath: "/workspace/src/routes/console.tsx",
		children: void 0,
		preloads: ["/assets/console-DaCBmqYZ.js", "/assets/button-yYfwkLca.js"]
	},
	"/protocol": {
		filePath: "/workspace/src/routes/protocol.tsx",
		children: void 0,
		preloads: ["/assets/protocol-BREiRBuu.js"]
	},
	"/source": {
		filePath: "/workspace/src/routes/source.tsx",
		children: void 0,
		preloads: ["/assets/source-qjWgK-FZ.js"]
	},
	"/tools": {
		filePath: "/workspace/src/routes/tools.tsx",
		children: void 0,
		preloads: ["/assets/tools-n6YxqN_a.js"]
	}
} });
//#endregion
export { tsrStartManifest };
