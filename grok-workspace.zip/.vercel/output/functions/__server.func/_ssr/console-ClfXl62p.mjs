import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./router-Dt5yAwFy.mjs";
import { t as Button } from "./button-MLi-BEI8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/console-ClfXl62p.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HELP_TEXT = [
	"/test   self-healing test loop",
	"/plan   implementation plan, no edits",
	"/diff   working tree summary",
	"/undo   restore last checkpoint",
	"/stats  tokens, tools, turns",
	"/model  list discovered models",
	"/clear  reset this console",
	"/help   this list"
].join("\n");
function eventsFor(input) {
	const trimmed = input.trim();
	const cmd = trimmed.split(/\s+/)[0];
	if (cmd === "/help") return [{
		kind: "system",
		text: HELP_TEXT,
		delay: 40
	}];
	if (cmd === "/stats") return [{
		kind: "system",
		text: "model: claude-sonnet-4-6\nmessages: 12\nestimated_tokens: 18420\nturns: 4\ntool_calls: 17\ncheckpoints: 3",
		delay: 40
	}];
	if (cmd === "/model") return [{
		kind: "system",
		text: "current: claude-sonnet-4-6\n- claude-opus-4-6\n- claude-sonnet-4-6\n- claude-sonnet-4-5",
		delay: 40
	}];
	if (cmd === "/diff") return [{
		kind: "system",
		text: " omni_agent/tools.py | 24 ++++\n tests/test_omni_agent.py |  8 ++\n 2 files changed, 32 insertions(+)",
		delay: 40
	}];
	if (cmd === "/undo") return [{
		kind: "system",
		text: "Restored checkpoint 1725100000-pre-turn (git-stash-create)",
		delay: 40
	}];
	if (cmd === "/clear") return [{
		kind: "system",
		text: "Session memory cleared",
		delay: 20
	}];
	if (cmd === "/plan" || trimmed.toLowerCase().includes("plan")) return planEvents(trimmed);
	if (cmd === "/test" || trimmed.toLowerCase().includes("test")) return healEvents();
	return defaultEvents(trimmed);
}
function planEvents(prompt) {
	return [
		{
			kind: "thinking",
			text: "Inspect layout, then list a sequence that avoids extra abstractions.",
			delay: 18
		},
		{
			kind: "tool",
			name: "repo_map",
			text: "repo_map .\nomni_agent/agent.py  :: class OmniAgent, def run\nomni_agent/tools.py  :: class ToolRegistry\ntests/test_omni_agent.py",
			delay: 12
		},
		{
			kind: "text",
			text: "Plan for: " + (prompt.replace(/^\/plan\s*/, "") || "next implementation steps") + "\n\n1. Read agent.py and tools.py.\n2. Add a failing test first.\n3. Patch with apply_patch, then syntax_check.\n4. Run /test and keep the git checkpoint from diagnostics.snapshot.",
			delay: 10
		}
	];
}
function healEvents() {
	return [
		{
			kind: "thinking",
			text: "Tests failed on greet(). Read the file, patch, re-run.",
			delay: 16
		},
		{
			kind: "tool",
			name: "bash",
			text: "exit_code: 1\nFAILED tests/test_omni_agent.py::ToolTests::test_fuzzy_patch_and_symbol",
			delay: 10
		},
		{
			kind: "tool",
			name: "apply_patch",
			text: "Patched mod.py\n-    return 'hi ' + name\n+    return f'hello {name}'\nsyntax_ok python mod.py",
			delay: 12
		},
		{
			kind: "tool",
			name: "syntax_check",
			text: "syntax_ok python mod.py",
			delay: 8
		},
		{
			kind: "result",
			name: "test_runner",
			text: "attempt 2/5  passed=true  duration_ms=412",
			delay: 10
		},
		{
			kind: "text",
			text: "Suite is green. Checkpoint pre-heal remains available via /undo.",
			delay: 10
		}
	];
}
function defaultEvents(prompt) {
	return [
		{
			kind: "thinking",
			text: `Need a repo map before touching files for: ${prompt.slice(0, 80)}`,
			delay: 16
		},
		{
			kind: "tool",
			name: "find_symbol",
			text: "omni_agent/agent.py:36 [class] OmniAgent\nomni_agent/agent.py:64 [function] run",
			delay: 12
		},
		{
			kind: "tool",
			name: "select_best_option",
			text: "{\n  \"recommendation\": \"apply_patch\",\n  \"rationale\": \"Prefer a minimal fuzzy patch over rewriting the file.\"\n}",
			delay: 12
		},
		{
			kind: "text",
			text: "I would snapshot with git stash create, apply a focused patch, syntax-check, then let the test runner iterate. Open Source to read the real loop in agent.py.",
			delay: 10
		}
	];
}
var seq = 1;
function AgentConsole() {
	const [lines, setLines] = (0, import_react.useState)([{
		id: 0,
		role: "system",
		text: "Omni console. Slash commands are live. Free-text runs a traced agent loop against the packaged architecture."
	}]);
	const [input, setInput] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({
			top: scroller.current.scrollHeight,
			behavior: "smooth"
		});
	}, [lines, busy]);
	async function play(events) {
		setBusy(true);
		for (const event of events) await typeLine(event);
		setBusy(false);
	}
	async function typeLine(event) {
		const id = seq++;
		setLines((prev) => [...prev, {
			id,
			role: event.kind,
			name: event.name,
			text: ""
		}]);
		let acc = "";
		for (const ch of event.text) {
			acc += ch;
			const snapshot = acc;
			setLines((prev) => prev.map((line) => line.id === id ? {
				...line,
				text: snapshot
			} : line));
			if (event.delay) await sleep(event.delay);
		}
	}
	function submit(raw) {
		const value = (raw ?? input).trim();
		if (!value || busy) return;
		if (value === "/clear") {
			setLines([{
				id: seq++,
				role: "system",
				text: "Session memory cleared"
			}]);
			setInput("");
			return;
		}
		setLines((prev) => [...prev, {
			id: seq++,
			role: "user",
			text: value
		}]);
		setInput("");
		play(eventsFor(value));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl sm:text-5xl",
				children: "Console"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted",
				children: "A traced loop: thinking, tools, results. Try /test, /plan, /stats, or describe a change."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 overflow-hidden rounded-xl border border-border bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs uppercase tracking-wide text-muted",
							children: "omni · sse"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono text-xs", busy ? "text-sage" : "text-subtle"),
							children: busy ? "streaming" : "idle"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: scroller,
						className: "h-console space-y-4 overflow-auto px-4 py-4",
						children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsoleLine, { line }, line.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex flex-col gap-2 border-t border-border p-3 sm:flex-row",
						onSubmit: (e) => {
							e.preventDefault();
							submit();
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "sr-only",
								htmlFor: "omni-input",
								children: "Prompt"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "omni-input",
								value: input,
								onChange: (e) => setInput(e.target.value),
								placeholder: "omni>  /test  or  patch the greet helper",
								className: "h-12 min-w-0 flex-1 rounded-sm border border-border bg-bg px-3 font-mono text-sm text-fg outline-none ring-accent/40 placeholder:text-subtle focus:ring-2",
								autoComplete: "off",
								disabled: busy
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: busy,
								className: "h-12",
								children: "Send"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					"/test",
					"/plan",
					"/stats",
					"find OmniAgent and explain the loop"
				].map((hint) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => submit(hint),
					className: "min-h-11 rounded-full border border-border px-3 font-mono text-xs text-muted hover:text-fg",
					children: hint
				}, hint))
			})
		]
	});
}
function ConsoleLine({ line }) {
	if (line.role === "user") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "font-mono text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-subtle",
				children: "omni>"
			}),
			" ",
			line.text
		]
	});
	if (line.role === "thinking") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "font-mono text-xs uppercase tracking-wide text-subtle",
		children: "thinking"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm italic text-muted",
		children: line.text
	})] });
	if (line.role === "tool" || line.role === "result") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md border border-border bg-bg p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-mono text-xs uppercase tracking-wide text-sage",
			children: [
				line.role,
				" ",
				line.name
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "mt-2 whitespace-pre-wrap font-mono text-xs text-fg",
			children: line.text
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
		className: "whitespace-pre-wrap font-mono text-sm text-fg",
		children: line.text
	});
}
function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
function ConsolePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentConsole, {});
}
//#endregion
export { ConsolePage as component };
