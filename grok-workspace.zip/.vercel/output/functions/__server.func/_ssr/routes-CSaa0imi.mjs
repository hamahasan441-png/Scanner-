import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as ArrowRight } from "../_libs/lucide-react.mjs";
import { a as MODULES, n as cn, s as TOOLS } from "./router-Dt5yAwFy.mjs";
import { t as Button } from "./button-MLi-BEI8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CSaa0imi.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border border-border px-2.5 py-0.5 font-mono text-xs uppercase tracking-wide text-muted", className),
		children
	});
}
var STATS = [
	{
		label: "Modules",
		value: String(MODULES.length)
	},
	{
		label: "Tools",
		value: String(TOOLS.length)
	},
	{
		label: "Protocol",
		value: "SSE"
	},
	{
		label: "Thinking",
		value: "On"
	}
];
function Overview() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-border bg-surface p-6 sm:p-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-bg px-5 py-8 sm:px-10 sm:py-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "AgentRouter · Anthropic messages" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-6 max-w-xl text-4xl text-fg sm:text-6xl",
							children: "Autonomous software engineering, instrumented."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-base text-muted sm:text-lg",
							children: "Omni is a modular Python agent: live SSE streaming, extended thinking, fuzzy patches, git checkpoints, and a self-healing test loop."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/console",
									children: ["Open console", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/architecture",
									children: "Inspect architecture"
								})
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: STATS.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-surface px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-mono text-xs uppercase tracking-wide text-muted",
						children: stat.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-3xl tabular-nums",
						children: stat.value
					})]
				}, stat.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Loop"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-5 grid gap-3 sm:grid-cols-2",
					children: [
						[
							"01",
							"Prompt",
							"REPL injects project rules from CLAUDE.md / AGENT.md."
						],
						[
							"02",
							"Think",
							"Extended thinking streams as thinking_delta blocks."
						],
						[
							"03",
							"Act",
							"Tool calls execute against the workspace with syntax checks."
						],
						[
							"04",
							"Heal",
							"Tests run; failures patch and retry until green or budget."
						]
					].map(([n, title, copy]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border border-border bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-sage",
								children: n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-lg font-medium",
								children: title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: copy
							})
						]
					}, n))
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overview, {});
}
//#endregion
export { Home as component };
