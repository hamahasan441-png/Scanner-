import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as SLASH, s as TOOLS } from "./router-Dt5yAwFy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tools-D_OgJS2F.js
var import_jsx_runtime = require_jsx_runtime();
var GROUPS = {
	exec: "Execution",
	fs: "Filesystem",
	verify: "Verification",
	nav: "Navigation",
	net: "Network",
	ops: "Operations",
	reason: "Reasoning"
};
function ToolCatalog() {
	const groups = Array.from(new Set(TOOLS.map((t) => t.group)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl sm:text-5xl",
				children: "Tools"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted",
				children: "Every tool returns clipped text, records duration, and is exposed to the model as an Anthropic JSON schema."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 space-y-10",
				children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-mono text-xs uppercase tracking-wide text-muted",
					children: GROUPS[group]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-3 sm:grid-cols-2",
					children: TOOLS.filter((t) => t.group === group).map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border border-border bg-surface p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-sm text-sage",
							children: tool.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: tool.summary
						})]
					}, tool.name))
				})] }, group))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Slash commands"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-border rounded-lg border border-border bg-surface",
					children: SLASH.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-4 px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-sm",
							children: item.cmd
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: item.detail
						})]
					}, item.cmd))
				})]
			})
		]
	});
}
function ToolsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolCatalog, {});
}
//#endregion
export { ToolsPage as component };
