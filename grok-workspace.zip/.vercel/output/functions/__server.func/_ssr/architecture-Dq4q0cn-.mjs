import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MODULES } from "./router-Dt5yAwFy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/architecture-Dq4q0cn-.js
var import_jsx_runtime = require_jsx_runtime();
var FLOW = [
	{
		from: "cli.py",
		via: "slash commands",
		to: "agent.py"
	},
	{
		from: "agent.py",
		via: "messages + tools",
		to: "client.py"
	},
	{
		from: "client.py",
		via: "SSE /v1/messages",
		to: "AgentRouter"
	},
	{
		from: "agent.py",
		via: "tool_use",
		to: "tools.py"
	},
	{
		from: "agent.py",
		via: "compact / persist",
		to: "memory.py"
	},
	{
		from: "agent.py",
		via: "stash create",
		to: "diagnostics.py"
	},
	{
		from: "cli.py",
		via: "/test",
		to: "test_runner.py"
	}
];
function ArchitectureMap() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl sm:text-5xl",
				children: "Architecture"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted",
				children: "Eight modules, one loop. The client never blocks the tool registry; memory and diagnostics sit beside the turn, not inside the HTTP layer."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 overflow-x-auto rounded-xl border border-border bg-surface p-4 sm:p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:min-w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-4 gap-3",
						children: [
							[
								"REPL",
								"Loop",
								"Transport",
								"Effects"
							].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs uppercase tracking-wide text-muted",
								children: label
							}, label)),
							[
								"cli.py",
								"agent.py",
								"client.py",
								"tools.py"
							].map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-md border border-border bg-bg px-3 py-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-sm",
									children: file
								})
							}, file)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-md border border-border bg-bg px-3 py-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-sm",
									children: "config.py"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-md border border-border bg-bg px-3 py-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-sm",
									children: "memory.py"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-border-strong bg-elevated px-3 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-sm",
									children: "AgentRouter"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-xs text-muted",
									children: "/v1/messages"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-border bg-bg px-3 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-sm",
									children: "diagnostics.py"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-mono text-xs text-muted",
									children: "test_runner.py"
								})]
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 space-y-2",
				children: FLOW.map((edge) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b border-border py-3 font-mono text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: edge.from }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: edge.via
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sage",
							children: ["→ ", edge.to]
						})
					]
				}, `${edge.from}-${edge.to}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-3 sm:grid-cols-2",
				children: MODULES.map((mod) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/source",
					className: "rounded-lg border border-border bg-surface p-5 transition-colors duration-150 hover:bg-elevated",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-muted",
							children: mod.file
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-lg font-medium",
							children: mod.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: mod.summary
						})
					]
				}, mod.id))
			})
		]
	});
}
function ArchitecturePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchitectureMap, {});
}
//#endregion
export { ArchitecturePage as component };
