import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createRootRoute, b as require_jsx_runtime, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Download, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Dt5yAwFy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var MODULES = [
	{
		id: "config",
		file: "omni_agent/config.py",
		title: "Config",
		summary: "Environment, AgentRouter endpoints, token budgets, dangerous-command patterns."
	},
	{
		id: "client",
		file: "omni_agent/client.py",
		title: "Client",
		summary: "Resilient HTTP, SSE streaming, thinking_delta, model discovery, max_tokens continuation."
	},
	{
		id: "tools",
		file: "omni_agent/tools.py",
		title: "Tools",
		summary: "Registry with fuzzy patches, AST search, repo maps, daemons, tasks, and trade-off scoring."
	},
	{
		id: "memory",
		file: "omni_agent/memory.py",
		title: "Memory",
		summary: "Session JSON, context compaction, base64 images, CLAUDE.md / AGENT.md injection."
	},
	{
		id: "diagnostics",
		file: "omni_agent/diagnostics.py",
		title: "Diagnostics",
		summary: "git stash create checkpoints and instant /undo rollback."
	},
	{
		id: "test_runner",
		file: "omni_agent/test_runner.py",
		title: "Test runner",
		summary: "Detects the suite, captures logs, applies patches, iterates until green."
	},
	{
		id: "agent",
		file: "omni_agent/agent.py",
		title: "Agent loop",
		summary: "Stream → tool_use → execute → compact → continue until end_turn."
	},
	{
		id: "cli",
		file: "omni_agent/cli.py",
		title: "REPL",
		summary: "Interactive shell with history and slash-command routing."
	}
];
var TOOLS = [
	{
		name: "bash",
		group: "exec",
		summary: "Workspace shell with dangerous-pattern blocking."
	},
	{
		name: "read_file",
		group: "fs",
		summary: "Numbered reads with offset/limit slicing."
	},
	{
		name: "write_file",
		group: "fs",
		summary: "Atomic write plus automatic syntax check."
	},
	{
		name: "apply_patch",
		group: "fs",
		summary: "Unified diff or search/replace with difflib fuzzy match."
	},
	{
		name: "syntax_check",
		group: "verify",
		summary: "py_compile for Python, node --check for JS/TS."
	},
	{
		name: "find_symbol",
		group: "nav",
		summary: "AST walk for functions, classes, methods, assignments."
	},
	{
		name: "repo_map",
		group: "nav",
		summary: "Compact file tree with top-level Python symbols."
	},
	{
		name: "grep_search",
		group: "nav",
		summary: "Regex content search with glob filters."
	},
	{
		name: "glob_search",
		group: "nav",
		summary: "Filename glob under the workspace root."
	},
	{
		name: "fetch_url",
		group: "net",
		summary: "HTTP fetch with HTML stripping and JSON pretty-print."
	},
	{
		name: "daemon_control",
		group: "ops",
		summary: "Start, stop, status, and tailed logs for background jobs."
	},
	{
		name: "manage_tasks",
		group: "ops",
		summary: "Persistent task tracker for multi-step work."
	},
	{
		name: "select_best_option",
		group: "reason",
		summary: "Weighted trade-off evaluator with ranked rationale."
	}
];
var SLASH = [
	{
		cmd: "/test",
		detail: "Self-healing test loop"
	},
	{
		cmd: "/plan",
		detail: "Implementation plan, no edits"
	},
	{
		cmd: "/image",
		detail: "Attach a multimodal image"
	},
	{
		cmd: "/commit",
		detail: "Commit the current diff"
	},
	{
		cmd: "/undo",
		detail: "Restore last checkpoint"
	},
	{
		cmd: "/diff",
		detail: "Working tree summary"
	},
	{
		cmd: "/stats",
		detail: "Tokens, tools, turns"
	},
	{
		cmd: "/clear",
		detail: "Reset session memory"
	},
	{
		cmd: "/model",
		detail: "Discover or set model"
	}
];
var HEADERS = [
	{
		key: "Authorization",
		value: "Bearer <ANTHROPIC_AUTH_TOKEN>"
	},
	{
		key: "x-api-key",
		value: "<ANTHROPIC_AUTH_TOKEN>"
	},
	{
		key: "anthropic-version",
		value: "2023-06-01"
	},
	{
		key: "anthropic-beta",
		value: "claude-code-20250219,interleaved-thinking-2025-05-14"
	},
	{
		key: "x-app",
		value: "cli"
	},
	{
		key: "User-Agent",
		value: "claude-cli/2.1.158 (external, sdk-cli)"
	},
	{
		key: "Content-Type",
		value: "application/json"
	}
];
var EVENTS = [
	{
		type: "message_start",
		detail: "Stream opens with model, id, usage"
	},
	{
		type: "content_block_start",
		detail: "thinking | text | tool_use"
	},
	{
		type: "thinking_delta",
		detail: "Extended thinking tokens"
	},
	{
		type: "text_delta",
		detail: "Visible assistant text"
	},
	{
		type: "input_json_delta",
		detail: "Partial tool arguments"
	},
	{
		type: "message_delta",
		detail: "stop_reason, usage"
	},
	{
		type: "message_stop",
		detail: "end_turn | tool_use | max_tokens"
	}
];
var NAV = [
	{
		to: "/",
		label: "Overview",
		short: "Home"
	},
	{
		to: "/architecture",
		label: "Architecture",
		short: "Arch"
	},
	{
		to: "/source",
		label: "Source",
		short: "Source"
	},
	{
		to: "/tools",
		label: "Tools",
		short: "Tools"
	},
	{
		to: "/console",
		label: "Console",
		short: "REPL"
	},
	{
		to: "/protocol",
		label: "Protocol",
		short: "Spec"
	}
];
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh max-w-7xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border px-5 py-8 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "mb-10 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl leading-none text-fg",
							children: "OMNI"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-xs uppercase tracking-widest text-muted",
							children: "Control plane"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-1",
						children: NAV.map((item) => {
							const active = pathname === item.to;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: item.to,
								className: cn("rounded-sm px-3 py-2.5 text-sm transition-colors duration-150", active ? "bg-elevated text-fg" : "text-muted hover:bg-surface hover:text-fg"),
								children: item.label
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "/omni_agent_framework.zip",
						download: true,
						className: "mt-6 inline-flex h-11 items-center justify-center gap-2 rounded-sm bg-accent px-3 text-sm font-medium text-accent-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Package"]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-center justify-between border-b border-border px-4 py-3 md:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "font-display text-2xl",
							children: "OMNI"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/omni_agent_framework.zip",
							download: true,
							className: "inline-flex h-11 w-11 items-center justify-center rounded-sm border border-border",
							"aria-label": "Download package",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "flex-1 px-4 py-8 pb-24 sm:px-8 sm:py-10 md:pb-10",
						children
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "sticky bottom-0 grid grid-cols-3 gap-1 border-t border-border bg-bg/95 px-2 py-2 backdrop-blur md:hidden",
						children: NAV.map((item) => {
							const active = pathname === item.to;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: item.to,
								className: cn("flex min-h-11 items-center justify-center rounded-sm px-1 text-center font-mono text-xs uppercase tracking-wide whitespace-nowrap", active ? "bg-elevated text-fg" : "text-muted"),
								children: item.short
							}, item.to);
						})
					})
				]
			})]
		})
	});
}
var styles_default = "/assets/styles-UWTGGBPE.css";
var APP_NAME = "OMNI";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Omni autonomous software engineering agent — control plane."
			},
			{
				name: "theme-color",
				content: "#09090b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&family=Instrument+Serif:ital@0;1&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$5 = () => import("./routes-CSaa0imi.mjs");
var Route$5 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./architecture-Dq4q0cn-.mjs");
var Route$4 = createFileRoute("/architecture")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./console-ClfXl62p.mjs");
var Route$3 = createFileRoute("/console")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./protocol-Cy5m2Rry.mjs");
var Route$2 = createFileRoute("/protocol")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./source-TzxL523z.mjs");
var Route$1 = createFileRoute("/source")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./tools-D_OgJS2F.mjs");
var Route = createFileRoute("/tools")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$5.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$6
	}),
	ArchitectureRoute: Route$4.update({
		id: "/architecture",
		path: "/architecture",
		getParentRoute: () => Route$6
	}),
	ConsoleRoute: Route$3.update({
		id: "/console",
		path: "/console",
		getParentRoute: () => Route$6
	}),
	ProtocolRoute: Route$2.update({
		id: "/protocol",
		path: "/protocol",
		getParentRoute: () => Route$6
	}),
	SourceRoute: Route$1.update({
		id: "/source",
		path: "/source",
		getParentRoute: () => Route$6
	}),
	ToolsRoute: Route.update({
		id: "/tools",
		path: "/tools",
		getParentRoute: () => Route$6
	})
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { MODULES as a, HEADERS as i, cn as n, SLASH as o, EVENTS as r, TOOLS as s, router_exports as t };
