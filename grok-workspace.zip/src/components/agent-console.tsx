import { useEffect, useRef, useState } from "react";
import { eventsFor, type DemoEvent } from "@/lib/demo-session";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type Line = {
  id: number;
  role: "user" | "thinking" | "text" | "tool" | "result" | "system";
  name?: string;
  text: string;
};

let seq = 1;

export function AgentConsole() {
  const [lines, setLines] = useState<Line[]>([
    {
      id: 0,
      role: "system",
      text: "Omni console. Slash commands are live. Free-text runs a traced agent loop against the packaged architecture.",
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [lines, busy]);

  async function play(events: DemoEvent[]) {
    setBusy(true);
    for (const event of events) {
      await typeLine(event);
    }
    setBusy(false);
  }

  async function typeLine(event: DemoEvent) {
    const id = seq++;
    setLines((prev) => [...prev, { id, role: event.kind, name: event.name, text: "" }]);
    let acc = "";
    for (const ch of event.text) {
      acc += ch;
      const snapshot = acc;
      setLines((prev) => prev.map((line) => (line.id === id ? { ...line, text: snapshot } : line)));
      if (event.delay) {
        await sleep(event.delay);
      }
    }
  }

  function submit(raw?: string) {
    const value = (raw ?? input).trim();
    if (!value || busy) return;
    if (value === "/clear") {
      setLines([{ id: seq++, role: "system", text: "Session memory cleared" }]);
      setInput("");
      return;
    }
    setLines((prev) => [...prev, { id: seq++, role: "user", text: value }]);
    setInput("");
    void play(eventsFor(value));
  }

  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="text-4xl sm:text-5xl">Console</h1>
      <p className="mt-3 max-w-2xl text-muted">
        A traced loop: thinking, tools, results. Try /test, /plan, /stats, or describe a change.
      </p>
      <div className="mt-8 overflow-hidden rounded-xl border border-border bg-surface">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <p className="font-mono text-xs uppercase tracking-wide text-muted">omni · sse</p>
          <p className={cn("font-mono text-xs", busy ? "text-sage" : "text-subtle")}>
            {busy ? "streaming" : "idle"}
          </p>
        </div>
        <div ref={scroller} className="h-console space-y-4 overflow-auto px-4 py-4">
          {lines.map((line) => (
            <ConsoleLine key={line.id} line={line} />
          ))}
        </div>
        <form
          className="flex flex-col gap-2 border-t border-border p-3 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <label className="sr-only" htmlFor="omni-input">
            Prompt
          </label>
          <input
            id="omni-input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="omni>  /test  or  patch the greet helper"
            className="h-12 min-w-0 flex-1 rounded-sm border border-border bg-bg px-3 font-mono text-sm text-fg outline-none ring-accent/40 placeholder:text-subtle focus:ring-2"
            autoComplete="off"
            disabled={busy}
          />
          <Button type="submit" disabled={busy} className="h-12">
            Send
          </Button>
        </form>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {["/test", "/plan", "/stats", "find OmniAgent and explain the loop"].map((hint) => (
          <button
            key={hint}
            type="button"
            onClick={() => submit(hint)}
            className="min-h-11 rounded-full border border-border px-3 font-mono text-xs text-muted hover:text-fg"
          >
            {hint}
          </button>
        ))}
      </div>
    </div>
  );
}

function ConsoleLine({ line }: { line: Line }) {
  if (line.role === "user") {
    return (
      <p className="font-mono text-sm">
        <span className="text-subtle">{"omni>"}</span> {line.text}
      </p>
    );
  }
  if (line.role === "thinking") {
    return (
      <div>
        <p className="font-mono text-xs uppercase tracking-wide text-subtle">thinking</p>
        <p className="mt-1 text-sm italic text-muted">{line.text}</p>
      </div>
    );
  }
  if (line.role === "tool" || line.role === "result") {
    return (
      <div className="rounded-md border border-border bg-bg p-3">
        <p className="font-mono text-xs uppercase tracking-wide text-sage">
          {line.role} {line.name}
        </p>
        <pre className="mt-2 whitespace-pre-wrap font-mono text-xs text-fg">{line.text}</pre>
      </div>
    );
  }
  return <pre className="whitespace-pre-wrap font-mono text-sm text-fg">{line.text}</pre>;
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
