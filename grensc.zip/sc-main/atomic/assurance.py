"""Deterministic, network-free assurance for an operator scan plan.

This module audits what a plan *claims* before execution.  It does not scan a
target and it never converts configuration intent into runtime coverage.
Runtime proof is produced separately by ``AtomicEngine._runtime_coverage``.
"""
from __future__ import annotations

from typing import Iterable
from urllib.parse import urlsplit

from core.models import SurfaceCategory
from core.surface_map import MODULE_SURFACE_CATEGORY, category_for


def _gate(name: str, result: str, detail: str, *, critical: bool = False) -> dict:
    return {
        "name": name,
        "result": result,
        "detail": detail,
        "critical": critical,
    }


def _enabled_components(profile) -> list[str]:
    enabled = [name for name, on in profile.modules.items() if on]
    enabled.append("recon")
    if profile.name in {"standard", "deep", "full"}:
        enabled.append("discovery")
    if profile.name in {"deep", "full"}:
        enabled.extend(
            [
                "passive_recon",
                "real_ip",
                "shield_detect",
                "enrich",
                "exploit_search",
                "attack_map",
            ]
        )
    return sorted(set(enabled))


def _suggestions(category: str) -> list[str]:
    return sorted(
        name for name, mapped in MODULE_SURFACE_CATEGORY.items()
        if mapped == category
    )[:8]


def build_plan_assurance(profile, target: str, argv: Iterable[str], *, authorized: bool) -> dict:
    """Return a stable assurance report for a wrapper-generated plan."""
    args = list(argv)
    parsed = urlsplit(target)
    hostname = (parsed.hostname or "").lower()
    enabled = _enabled_components(profile)
    unmapped = sorted(name for name in enabled if category_for(name) is None)
    declared_categories = sorted({
        category_for(name) for name in enabled if category_for(name) is not None
    })
    blind_spots = [
        {
            "category": category,
            "reason": "not declared by this profile; runtime coverage not claimed",
            "suggested_modules": _suggestions(category),
        }
        for category in SurfaceCategory.ALL
        if category not in declared_categories
    ]

    strict = "--strict-scope" in args
    allow_domain = ""
    if "--allow-domain" in args:
        idx = args.index("--allow-domain")
        if idx + 1 < len(args):
            allow_domain = str(args[idx + 1]).lower()

    state_change_requested = any(
        (
            profile.auto_attack,
            profile.shell_upload,
            profile.db_dump,
            profile.brute_force,
        )
    )
    gates = [
        _gate(
            "target_parse",
            "pass" if parsed.scheme in {"http", "https"} and hostname else "fail",
            "target has an HTTP(S) scheme and canonical hostname",
            critical=True,
        ),
        _gate(
            "strict_host_scope",
            "pass" if strict and allow_domain == hostname else "fail",
            f"allow-domain={allow_domain or '<missing>'}; target-host={hostname or '<missing>'}",
            critical=True,
        ),
        _gate(
            "state_change_authorization",
            "pass" if not state_change_requested or authorized else "fail",
            "state-changing stages require explicit operator authorization",
            critical=True,
        ),
        _gate(
            "independent_evidence",
            "pass",
            "HIGH/CRITICAL confirmation requires two independent evidence forms",
            critical=True,
        ),
        _gate(
            "runtime_coverage_truth",
            "pass",
            "only executed validator outcomes may satisfy coverage",
            critical=True,
        ),
        _gate(
            "transport",
            "pass" if parsed.scheme == "https" else "warn",
            "HTTPS protects scanner credentials and evidence in transit"
            if parsed.scheme != "https"
            else "HTTPS target",
        ),
        _gate(
            "surface_mapping",
            "pass" if not unmapped else "warn",
            "all declared components map to a reviewable surface category"
            if not unmapped
            else f"unmapped components: {', '.join(unmapped)}",
        ),
    ]

    failures = [g for g in gates if g["critical"] and g["result"] == "fail"]
    warnings = [g for g in gates if g["result"] == "warn"]
    status = "blocked" if failures else ("degraded" if warnings or blind_spots else "ready")
    return {
        "schema_version": 1,
        "status": status,
        "gates": gates,
        "declared_components": enabled,
        "declared_surface_categories": declared_categories,
        "blind_spots": blind_spots,
        "unmapped_components": unmapped,
        "proof_model": {
            "configuration": "PLANNED only",
            "successful_execution": "TESTED",
            "ambiguous_result": "INCONCLUSIVE",
            "scope_or_runtime_failure": "BLOCKED",
            "confirmed_finding": "VALIDATED",
        },
        "summary": {
            "critical_failures": len(failures),
            "warnings": len(warnings),
            "declared_categories": len(declared_categories),
            "blind_spots": len(blind_spots),
            "unmapped_components": len(unmapped),
        },
    }


__all__ = ["build_plan_assurance"]
