"""Network-free deployment diagnostics and deterministic scan planning."""
from __future__ import annotations

import contextlib
import io
import json
import os
import sys
from pathlib import Path
from typing import List
from urllib.parse import urlsplit

from config import Config

from .profiles import PROFILES, Profile, to_main_args
from .runtime_paths import resolve_asset
from .assurance import build_plan_assurance


def _check(name: str, status: str, detail: str, *, critical: bool = False) -> dict:
    return {
        "name": name,
        "status": status,
        "detail": detail,
        "critical": critical,
    }


def _asset_checks() -> List[dict]:
    checks: List[dict] = []
    assets = (
        ("scanner rules", "scanner_rules.yaml", False),
        ("rules schema", "schemas/scanner_rules.schema.json", False),
        ("tool manifest", "runtime/metadata/tools.json", False),
        ("nuclei templates", "nuclei_templates", True),
    )
    for label, relative, directory in assets:
        path = resolve_asset(relative, directory=directory)
        if path is None:
            checks.append(_check(label, "fail", f"missing packaged asset: {relative}", critical=True))
            continue
        if directory:
            count = len(list(path.rglob("*.yaml"))) + len(list(path.rglob("*.yml")))
            status = "pass" if count else "fail"
            checks.append(_check(label, status, f"{path} ({count} templates)", critical=True))
            continue
        try:
            if path.suffix == ".json":
                json.loads(path.read_text(encoding="utf-8"))
            elif path.suffix in {".yaml", ".yml"}:
                import yaml

                payload = yaml.safe_load(path.read_text(encoding="utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("top level must be a mapping")
        except (OSError, ValueError, TypeError, ImportError) as exc:
            checks.append(_check(label, "fail", f"invalid {relative}: {exc}", critical=True))
        else:
            checks.append(_check(label, "pass", str(path), critical=True))
    return checks


def _profile_contract_check() -> dict:
    """Prove every wrapper profile translates into canonical CLI arguments."""
    try:
        from core.cli.parser import create_parser

        parser = create_parser()
        for name, profile in PROFILES.items():
            argv = to_main_args(
                profile,
                "https://example.invalid",
                authorized=(name == "full"),
            )
            with contextlib.redirect_stderr(io.StringIO()):
                parser.parse_args(argv)
    except (BaseException,) as exc:
        if isinstance(exc, (KeyboardInterrupt, SystemExit)) and not isinstance(exc, SystemExit):
            raise
        return _check(
            "profile contract",
            "fail",
            f"wrapper/canonical CLI drift: {type(exc).__name__}: {exc}",
            critical=True,
        )
    return _check(
        "profile contract",
        "pass",
        f"{len(PROFILES)} profiles parse through the canonical CLI",
        critical=True,
    )


def _output_check() -> dict:
    home = Path(os.environ.get("ATOMIC_HOME", "").strip() or Config.ATOMIC_HOME).expanduser()
    reports = home / "reports"
    try:
        reports.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return _check("output directory", "fail", f"cannot create {reports}: {exc}", critical=True)
    writable = os.access(reports, os.W_OK | os.X_OK)
    return _check(
        "output directory",
        "pass" if writable else "fail",
        str(reports),
        critical=True,
    )


def _tool_summary() -> tuple[dict, dict]:
    try:
        from core.tool_runtime import ToolRuntime

        status = ToolRuntime().status()
    except Exception as exc:
        return (
            {
                "real_available": 0,
                "missing": 0,
                "simulations_disabled": 0,
                "tools": {},
            },
            _check("external tools", "warn", f"status unavailable: {exc}"),
        )
    real_available = sum(
        1
        for item in status.values()
        if item.get("available")
        and (item.get("source") == "host" or not item.get("simulated"))
    )
    simulations_disabled = sum(
        1 for item in status.values() if item.get("simulation_disabled_by_default")
    )
    missing = sum(1 for item in status.values() if not item.get("available"))
    summary = {
        "real_available": real_available,
        "missing": missing,
        "simulations_disabled": simulations_disabled,
        "tools": status,
    }
    if real_available:
        check = _check("external tools", "pass", f"{real_available} real tools available")
    else:
        check = _check(
            "external tools",
            "warn",
            "no real external tools found; Python-native modules remain available",
        )
    return summary, check


def run_doctor() -> dict:
    """Return deployment health without contacting a target or update server."""
    checks = [
        _check(
            "python runtime",
            "pass" if sys.version_info >= (3, 10) else "fail",
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            critical=True,
        ),
        _check("framework metadata", "pass", f"v{Config.VERSION} ({Config.CODENAME})", critical=True),
        *_asset_checks(),
        _profile_contract_check(),
        _output_check(),
    ]
    tools, tool_check = _tool_summary()
    checks.append(tool_check)
    critical_failures = [c for c in checks if c["critical"] and c["status"] == "fail"]
    warnings = [c for c in checks if c["status"] == "warn"]
    status = "failed" if critical_failures else ("degraded" if warnings else "ready")
    return {
        "schema_version": 1,
        "status": status,
        "framework": {"version": str(Config.VERSION), "codename": Config.CODENAME},
        "checks": checks,
        "summary": {
            "passed": sum(1 for c in checks if c["status"] == "pass"),
            "warnings": len(warnings),
            "failed": sum(1 for c in checks if c["status"] == "fail"),
            "critical_failures": len(critical_failures),
        },
        "external_tools": tools,
    }


def _stage(key: str, purpose: str, mode: str = "deterministic") -> dict:
    return {"key": key, "purpose": purpose, "mode": mode}


def build_operator_plan(profile: Profile, target: str, *, authorized: bool) -> dict:
    """Build the exact high-level plan the wrapper will submit to the engine."""
    doctor = run_doctor()
    argv = to_main_args(profile, target, authorized=authorized)
    stages = [
        _stage("preflight", "Validate runtime, scope, and immutable assets"),
        _stage("scope_lock", "Restrict requests to the normalized target host"),
        _stage("discovery", "Build the target surface and endpoint inventory"),
    ]
    if profile.name in {"standard", "deep", "full"}:
        stages.append(_stage("active_discovery", "Crawl and enumerate target-owned paths"))
    if profile.name in {"deep", "full"}:
        stages.extend(
            [
                _stage("shield_and_origin", "Detect edge controls and authorized origin exposure"),
                _stage("external_recon", "Run available real external tools", "capability-gated"),
                _stage("intelligence", "Prioritize reachable, evidenced attack surface"),
            ]
        )
    stages.extend(
        [
            _stage("baseline", "Capture stable response baselines"),
            _stage("validation", "Run enabled detection modules"),
            _stage("verification", "Reproduce signals and reject unstable findings"),
            _stage("evidence_scoring", "Score only evidence-backed findings"),
        ]
    )
    if profile.auto_attack and authorized:
        stages.append(_stage("post_exploitation", "Run explicitly authorized gated actions", "gated"))
    stages.extend(
        [
            _stage("coverage_closure", "Report blind spots and remaining validators"),
            _stage("reporting", "Write HTML, JSON, SARIF, and supporting reports"),
        ]
    )

    enabled_modules = sorted(key for key, enabled in profile.modules.items() if enabled)
    blocked_reasons = []
    if profile.auto_attack and not authorized:
        blocked_reasons.append("full profile requires explicit --authorized confirmation")
    if doctor["summary"]["critical_failures"]:
        blocked_reasons.append("deployment doctor reported critical failures")
    output_index = argv.index("--output") + 1
    parsed = urlsplit(target)
    tools = doctor["external_tools"]
    simulation_enabled = os.environ.get("ATOMIC_ALLOW_SIMULATED_TOOLS", "").strip().lower() in {
        "1", "true", "yes", "on"
    }
    assurance = build_plan_assurance(
        profile, target, argv, authorized=authorized
    )
    if assurance["summary"]["critical_failures"]:
        blocked_reasons.append("plan assurance reported critical gate failures")
    return {
        "schema_version": 1,
        "status": "blocked" if blocked_reasons else "ready",
        "blocked_reasons": blocked_reasons,
        "framework": {"version": str(Config.VERSION), "codename": Config.CODENAME},
        "target": {
            "url": target,
            "scheme": parsed.scheme,
            "hostname": parsed.hostname,
            "scope_mode": "strict-host",
        },
        "profile": {
            "name": profile.name,
            "description": profile.description,
            "threads": profile.threads,
            "depth": profile.depth,
            "timeout_seconds": profile.timeout,
            "delay_seconds": profile.delay,
            "evasion": profile.evasion,
            "module_count": len(enabled_modules),
        },
        "safety": {
            "authorization_confirmed": authorized,
            "post_exploitation_requested": profile.auto_attack,
            "post_exploitation_enabled": profile.auto_attack and authorized,
            "simulated_tools_allowed": simulation_enabled,
        },
        "stages": stages,
        "modules": enabled_modules,
        "external_tools": {
            "requested": profile.auto_external_tools,
            "real_available": tools["real_available"],
            "missing": tools["missing"],
            "simulations_disabled": tools["simulations_disabled"],
        },
        "output_directory": argv[output_index],
        "command": [sys.executable, "-m", "main", *argv],
        "preflight": doctor["summary"],
        "assurance": assurance,
    }


def render_doctor(report: dict) -> str:
    lines = [f"Deployment status: {report['status'].upper()}"]
    for check in report["checks"]:
        lines.append(f"  [{check['status'].upper():4}] {check['name']}: {check['detail']}")
    return "\n".join(lines)


def render_plan(plan: dict) -> str:
    lines = [
        f"Execution plan: {plan['status'].upper()}",
        f"  Target: {plan['target']['url']} ({plan['target']['scope_mode']})",
        f"  Profile: {plan['profile']['name']} ({plan['profile']['module_count']} modules)",
        f"  Output: {plan['output_directory']}",
        "  Stages:",
    ]
    for index, stage in enumerate(plan["stages"], start=1):
        lines.append(f"    {index:02d}. {stage['key']}: {stage['purpose']}")
    assurance = plan.get("assurance", {})
    if assurance:
        summary = assurance.get("summary", {})
        lines.append(
            "  Assurance: "
            f"{assurance.get('status', 'unknown').upper()} "
            f"({summary.get('declared_categories', 0)} categories, "
            f"{summary.get('blind_spots', 0)} declared blind spots)"
        )
    if plan["blocked_reasons"]:
        lines.append("  Blocked:")
        lines.extend(f"    - {reason}" for reason in plan["blocked_reasons"])
    return "\n".join(lines)
