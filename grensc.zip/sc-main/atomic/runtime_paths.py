"""Resolve immutable runtime assets in source and installed deployments."""
from __future__ import annotations

import os
import sys
import sysconfig
from pathlib import Path
from typing import Iterable, Optional


def candidate_roots() -> Iterable[Path]:
    """Yield unique roots that may contain ATOMIC's packaged data files."""
    candidates = []
    configured = os.environ.get("ATOMIC_ROOT", "").strip()
    if configured:
        candidates.append(Path(configured).expanduser())
    candidates.extend(
        [
            Path(__file__).resolve().parents[1],
            Path(sys.prefix),
            Path(sysconfig.get_path("data")),
        ]
    )
    seen = set()
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved not in seen:
            seen.add(resolved)
            yield resolved


def resolve_asset(relative_path: str, *, directory: bool = False) -> Optional[Path]:
    """Return the first existing packaged asset matching ``relative_path``."""
    relative = Path(relative_path)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("asset paths must be relative and may not traverse parents")
    for root in candidate_roots():
        candidate = root / relative
        if candidate.is_dir() if directory else candidate.is_file():
            return candidate
    return None


def asset_root(relative_path: str) -> Optional[Path]:
    """Return the root containing an asset, if it is installed."""
    relative = Path(relative_path)
    asset = resolve_asset(relative_path)
    if asset is None:
        return None
    root = asset
    for _part in relative.parts:
        root = root.parent
    return root
