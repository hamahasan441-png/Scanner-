# Defensive Assurance Upgrade

## Objective

Make scan planning, execution, verification, and blind-spot reporting
deterministic and evidence-backed. This upgrade does not add unrestricted
exploitation. State-changing behavior remains behind explicit authorization,
and coverage closure refuses invasive validators.

## Corrected blind spots

1. **Enabled was incorrectly treated as tested.** Surface reports used module
   configuration as proof of execution. They now use runtime coverage records.
2. **Unsupported entry points could look successful.** Parameter-level and
   URL-level execution now report `UNSUPPORTED` when the applicable callable
   does not exist.
3. **Scope-check exceptions failed open in coverage closure.** They now produce
   `BLOCKED` and no request is attempted.
4. **Invasive aliases were incomplete.** State-changing and high-risk aliases
   are covered by the closure driver's hard denylist.
5. **Canonical module names were missing from surface mapping.** Engine keys,
   implementation aliases, extended network/cloud modules, and common
   human-readable finding labels now map deterministically.
6. **Preflight plans hid declared gaps.** `atomic plan --json` now includes an
   assurance block with gates, surface categories, blind spots, unmapped
   components, and a proof model.
7. **Unavailable validators were implicit.** Coverage plans now expose
   `unavailable_validators` and their count.

## Proof model

| Evidence | Coverage state |
| --- | --- |
| Module configured | `PLANNED` |
| Entry point ran successfully | `TESTED` |
| Result ambiguous | `INCONCLUSIVE` |
| Scope/runtime failure | `BLOCKED` |
| Prerequisite not met | `SKIPPED` |
| Entry point unavailable | `UNSUPPORTED` |
| Finding confirmed | `VALIDATED` |

Higher-ranked runtime evidence cannot be downgraded by later planning data.
HIGH and CRITICAL confirmation retains the two-independent-evidence rule.

## Verification completed

- Python compilation: pass
- Release contract: pass
- Focused assurance, coverage, planner, surface-map, and finding-quality tests:
  90 passed
- Offline deployment doctor: zero critical failures; degraded only because
  optional external scanner binaries are not installed in the verification
  environment

The environment did not contain the optional `pytest`, Flask, Requests,
SQLAlchemy, build, lint, type-check, or dependency-audit tooling. The focused
suite was therefore executed with the standard-library `unittest` runner, and
the project release contract plus compile checks were run directly.
