#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ATOMIC FRAMEWORK - Plugin System
Extensible plugin architecture for third-party scanning modules.

Plugin structure:
  plugins/
    my_plugin/
      __init__.py   # contains plugin_info dict
      scanner.py    # contains PluginScanner class

Plugin interface:
  class PluginScanner:
      name: str
      description: str
      def setup(self, engine) -> None
      def run(self, target: str, params: list) -> list[dict]
      def teardown(self) -> None

Plugin registration:
  - Drop-in: place plugin folder in ``plugins/`` directory
  - API: call ``plugin_manager.register(plugin_instance)``
"""

import importlib
import importlib.util
import multiprocessing
import os
import queue
import sys
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


def _sanitize_plugin_findings(findings: Any) -> List[dict]:
    """Return a bounded, serialization-safe plugin result.

    Sanitizing inside the worker prevents an untrusted plugin from sending an
    arbitrarily large or unserializable object through the IPC channel.
    """
    safe_findings: List[dict] = []
    for finding in findings[:1000] if isinstance(findings, list) else []:
        if not isinstance(finding, dict):
            continue
        safe: dict = {}
        for key, value in finding.items():
            if not isinstance(key, str) or len(key) > 100:
                continue
            if isinstance(value, str) and len(value) <= 4096:
                safe[key] = value
            elif isinstance(value, (int, float, bool)) or value is None:
                safe[key] = value
        safe_findings.append(safe)
    return safe_findings


def _plugin_process_worker(result_queue, instance, target: str, params: list, engine: Any) -> None:
    """Execute one plugin in a killable child process."""
    try:
        if hasattr(instance, "setup") and engine is not None:
            instance.setup(engine)
        result_queue.put(("ok", _sanitize_plugin_findings(instance.run(target, params))))
    except BaseException as exc:  # plugin failures must never escape the worker
        result_queue.put(("error", f"{type(exc).__name__}: {exc}"[:500]))


@dataclass
class PluginInfo:
    """Metadata about a registered plugin."""

    name: str
    version: str = "1.0.0"
    author: str = ""
    description: str = ""
    category: str = "scanner"  # scanner | recon | exploit | report | utility
    enabled: bool = True
    loaded_at: str = ""
    module_path: str = ""
    instance: Any = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "author": self.author,
            "description": self.description,
            "category": self.category,
            "enabled": self.enabled,
            "loaded_at": self.loaded_at,
            "module_path": self.module_path,
        }


@dataclass
class PluginResult:
    """Result from a plugin execution."""

    plugin_name: str
    success: bool
    findings: List[dict] = field(default_factory=list)
    data: dict = field(default_factory=dict)
    error: str = ""
    duration_seconds: float = 0.0

    def to_dict(self) -> dict:
        return {
            "plugin_name": self.plugin_name,
            "success": self.success,
            "findings_count": len(self.findings),
            "findings": self.findings,
            "data": self.data,
            "error": self.error,
            "duration_seconds": self.duration_seconds,
        }


class PluginManager:
    """Discover, load, and manage scanner plugins."""

    def __init__(self, plugin_dir: str = ""):
        self._plugins: Dict[str, PluginInfo] = {}
        self._lock = threading.Lock()
        self._plugin_dir = plugin_dir or os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "plugins",
        )
        self._hooks: Dict[str, List] = {
            "pre_scan": [],
            "post_scan": [],
            "on_finding": [],
            "on_scan_start": [],
            "on_scan_complete": [],
            "pre_report": [],
            "post_report": [],
        }

    # --- Discovery & Loading ---

    def discover_and_load_all(self) -> List[str]:
        """Discover and load all available plugins, returning loaded names.

        This is the recommended entry-point for plugin initialisation at
        engine startup.  Plugins that define lifecycle hook methods
        (``on_scan_start``, ``on_finding``, ``on_scan_complete``) are
        automatically registered.
        """
        loaded = []
        for name in self.discover_plugins():
            info = self.load_plugin(name)
            if info and info.instance:
                # Auto-register lifecycle hooks exposed by the plugin class
                for hook_name in self._hooks:
                    handler = getattr(info.instance, hook_name, None)
                    if callable(handler):
                        self.register_hook(hook_name, handler)
                loaded.append(name)
        return loaded

    # --- Discovery & Loading ---

    def discover_plugins(self) -> List[str]:
        """Scan the plugin directory for available plugins.

        SECURITY HARDENING (PLUGIN-001):
        - Only allow alphanumeric + underscore + dash names (no traversal).
        - Skip symlinks and world-writable directories.
        """
        discovered = []
        if not os.path.isdir(self._plugin_dir):
            return discovered

        import re
        _SAFE_NAME = re.compile(r"^[a-zA-Z0-9_-]+$")
        for entry in os.listdir(self._plugin_dir):
            if not _SAFE_NAME.match(entry):
                continue
            plugin_path = os.path.join(self._plugin_dir, entry)
            # Reject symlinks (symlink attack)
            try:
                if os.path.islink(plugin_path):
                    continue
                # Reject world-writable plugin dirs (supply-chain risk)
                st = os.stat(plugin_path)
                if st.st_mode & 0o002:
                    continue
            except OSError:
                continue
            init_path = os.path.join(plugin_path, "__init__.py")
            if os.path.isdir(plugin_path) and os.path.isfile(init_path):
                discovered.append(entry)
        return discovered

    def load_plugin(self, plugin_name: str) -> Optional[PluginInfo]:
        """Load a plugin from the plugins directory by name."""
        import re
        # Validate plugin name strictly (no path traversal)
        if not re.match(r"^[a-zA-Z0-9_-]+$", plugin_name):
            return None
        plugin_path = os.path.join(self._plugin_dir, plugin_name)
        # Ensure resolved path stays within plugin dir (path traversal defense)
        try:
            real_plugin = os.path.realpath(plugin_path)
            real_base = os.path.realpath(self._plugin_dir)
            if not real_plugin.startswith(real_base + os.sep) and real_plugin != real_base:
                return None
            if os.path.islink(plugin_path):
                return None
        except OSError:
            return None

        init_path = os.path.join(plugin_path, "__init__.py")
        if not os.path.isfile(init_path):
            return None

        try:
            # Add plugin dir to path temporarily — remove after load
            added = False
            if plugin_path not in sys.path:
                sys.path.insert(0, plugin_path)
                added = True

            spec = importlib.util.spec_from_file_location(
                f"plugins.{plugin_name}",
                init_path,
            )
            if spec is None or spec.loader is None:
                return None

            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Extract plugin_info dict — validate it
            info_dict = getattr(module, "plugin_info", {})
            if not isinstance(info_dict, dict):
                info_dict = {}
            # Category must be from allowlist
            allowed_categories = {"scanner", "recon", "exploit", "report", "utility"}
            cat = info_dict.get("category", "scanner")
            if cat not in allowed_categories:
                cat = "scanner"

            scanner_class = getattr(module, "PluginScanner", None)

            instance = None
            if scanner_class:
                # Basic capability check: must have run method
                if not hasattr(scanner_class, "run") or not callable(getattr(scanner_class, "run")):
                    return None
                instance = scanner_class()

            plugin_info = PluginInfo(
                name=str(info_dict.get("name", plugin_name))[:100],
                version=str(info_dict.get("version", "1.0.0"))[:32],
                author=str(info_dict.get("author", ""))[:100],
                description=str(info_dict.get("description", ""))[:500],
                category=cat,
                enabled=True,
                loaded_at=datetime.now(timezone.utc).isoformat(),
                module_path=plugin_path,
                instance=instance,
            )

            with self._lock:
                self._plugins[plugin_info.name] = plugin_info

            try:
                from core.audit_logger import AuditLogger

                AuditLogger().log_config(
                    "plugin.loaded",
                    result="ok",
                    plugin=plugin_info.name,
                    path=plugin_path,
                )
            except Exception:
                pass

            return plugin_info
        except Exception:
            return None
        finally:
            # Cleanup: remove plugin_path from sys.path if we added it
            try:
                if added and plugin_path in sys.path:
                    sys.path.remove(plugin_path)
            except ValueError:
                pass

    def load_all(self) -> int:
        """Discover and load all plugins. Returns count of loaded plugins."""
        count = 0
        for name in self.discover_plugins():
            if self.load_plugin(name):
                count += 1
        return count

    # --- Registration (programmatic) ---

    def register(self, name: str, instance: Any, **kwargs) -> PluginInfo:
        """Register a plugin programmatically."""
        info = PluginInfo(
            name=name,
            version=kwargs.get("version", "1.0.0"),
            author=kwargs.get("author", ""),
            description=kwargs.get("description", ""),
            category=kwargs.get("category", "scanner"),
            enabled=True,
            loaded_at=datetime.now(timezone.utc).isoformat(),
            instance=instance,
        )
        with self._lock:
            self._plugins[name] = info
        return info

    def unregister(self, name: str) -> bool:
        with self._lock:
            plugin = self._plugins.pop(name, None)
        if plugin and plugin.instance and hasattr(plugin.instance, "teardown"):
            try:
                plugin.instance.teardown()
            except Exception:
                pass
        return plugin is not None

    # --- Query ---

    def list_plugins(self) -> List[dict]:
        with self._lock:
            return [p.to_dict() for p in self._plugins.values()]

    def get_plugin(self, name: str) -> Optional[PluginInfo]:
        return self._plugins.get(name)

    def toggle_plugin(self, name: str, enabled: bool) -> bool:
        plugin = self._plugins.get(name)
        if not plugin:
            return False
        plugin.enabled = enabled
        return True

    # --- Execution (hardened with timeout) ---

    def run_plugin(self, name: str, target: str, params: Optional[list] = None, engine: Any = None) -> PluginResult:
        """Execute a plugin with a hard timeout and bounded IPC output.

        On platforms with ``fork`` support the plugin runs in a child process,
        which can be terminated reliably. A thread fallback is retained for
        platforms where loaded plugin instances cannot be transferred to a
        process, but it never waits for a timed-out worker during shutdown.
        """
        import time
        import concurrent.futures

        plugin = self._plugins.get(name)
        if not plugin or not plugin.enabled or not plugin.instance:
            return PluginResult(plugin_name=name, success=False, error="Plugin not available or disabled")

        # SECURITY: Limit target length to prevent resource exhaustion via huge input
        if not isinstance(target, str) or len(target) > 4096:
            return PluginResult(plugin_name=name, success=False, error="Invalid target")
        # Limit params size
        if params and len(params) > 1000:
            return PluginResult(plugin_name=name, success=False, error="Too many params")

        safe_params = list(params or [])

        def _exec():
            if hasattr(plugin.instance, "setup") and engine:
                plugin.instance.setup(engine)
            return _sanitize_plugin_findings(plugin.instance.run(target, safe_params))

        start = time.time()
        try:
            # Timeout per plugin execution (30s default, configurable via
            # ATOMIC_PLUGIN_TIMEOUT). One second is intentionally supported
            # for CI and operator-enforced fail-fast profiles.
            try:
                _timeout = int(os.environ.get("ATOMIC_PLUGIN_TIMEOUT", "30"))
            except ValueError:
                _timeout = 30
            _timeout = max(1, min(_timeout, 300))

            if "fork" in multiprocessing.get_all_start_methods():
                context = multiprocessing.get_context("fork")
                result_queue = context.Queue(maxsize=1)
                process = context.Process(
                    target=_plugin_process_worker,
                    args=(result_queue, plugin.instance, target, safe_params, engine),
                    name=f"atomic-plugin-{name[:40]}",
                    daemon=True,
                )
                process.start()
                process.join(_timeout)
                if process.is_alive():
                    process.terminate()
                    process.join(1.0)
                    if process.is_alive() and hasattr(process, "kill"):
                        process.kill()
                        process.join(1.0)
                    result_queue.close()
                    result_queue.join_thread()
                    process.close()
                    return PluginResult(
                        plugin_name=name,
                        success=False,
                        error=f"Plugin execution timed out after {_timeout}s",
                        duration_seconds=round(time.time() - start, 2),
                    )
                try:
                    status, payload = result_queue.get(timeout=0.25)
                except queue.Empty:
                    status, payload = "error", f"Plugin exited without a result (exit code {process.exitcode})"
                finally:
                    result_queue.close()
                    result_queue.join_thread()
                    process.close()
                if status != "ok":
                    return PluginResult(
                        plugin_name=name,
                        success=False,
                        error=str(payload)[:500],
                        duration_seconds=round(time.time() - start, 2),
                    )
                findings = payload
            else:  # pragma: no cover - exercised on non-POSIX platforms
                executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
                future = executor.submit(_exec)
                try:
                    findings = future.result(timeout=_timeout)
                except concurrent.futures.TimeoutError:
                    future.cancel()
                    executor.shutdown(wait=False, cancel_futures=True)
                    return PluginResult(
                        plugin_name=name,
                        success=False,
                        error=f"Plugin execution timed out after {_timeout}s",
                        duration_seconds=round(time.time() - start, 2),
                    )
                executor.shutdown(wait=True)

            duration = time.time() - start
            return PluginResult(
                plugin_name=name,
                success=True,
                findings=findings,
                duration_seconds=round(duration, 2),
            )
        except Exception as exc:
            duration = time.time() - start
            return PluginResult(
                plugin_name=name,
                success=False,
                error=str(exc)[:500],
                duration_seconds=round(duration, 2),
            )

    def run_all(
        self, target: str, params: Optional[list] = None, engine: Any = None, category: str = ""
    ) -> List[PluginResult]:
        """Run all enabled plugins (optionally filtered by category)."""
        results = []
        for name, plugin in self._plugins.items():
            if not plugin.enabled:
                continue
            if category and plugin.category != category:
                continue
            results.append(self.run_plugin(name, target, params, engine))
        return results

    # --- Hook System ---

    def register_hook(self, hook_name: str, callback) -> bool:
        """Register a callback for a lifecycle hook."""
        if hook_name not in self._hooks:
            return False
        self._hooks[hook_name].append(callback)
        return True

    def fire_hook(self, hook_name: str, **kwargs):
        """Fire all callbacks for a lifecycle hook."""
        for cb in self._hooks.get(hook_name, []):
            try:
                cb(**kwargs)
            except Exception:
                pass
