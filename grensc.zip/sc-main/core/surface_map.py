#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ATOMIC FRAMEWORK - Module -> Surface Category Map
=========================================================

Maps a scan module / finding technique name to the attack-surface category it
primarily exercises (:class:`core.models.SurfaceCategory`). This is what lets a
real run populate the :class:`core.surface_ledger.SurfaceLedger`: which
surfaces were actually assessed, and which findings belong to which surface.

The mapping is a deliberate, reviewable 1-primary-category assignment. Names
not in the table map to ``None`` (unknown) rather than a guessed default, so
the ledger never *over-claims* coverage — an unmapped module leaves its
surfaces at NOT_TESTED.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional

from core.models import SurfaceCategory as C
from core.surface_ledger import SurfaceLedger

# technique/module name -> primary attack-surface category
MODULE_SURFACE_CATEGORY: Dict[str, str] = {
    # Input & processing (injection into server-side parsing/execution)
    "sqli": C.INPUT_PROCESSING,
    "nosqli": C.INPUT_PROCESSING,
    "nosql": C.INPUT_PROCESSING,
    "cmdi": C.INPUT_PROCESSING,
    "ssti": C.INPUT_PROCESSING,
    "xxe": C.INPUT_PROCESSING,
    "lfi": C.INPUT_PROCESSING,
    "crlf": C.INPUT_PROCESSING,
    "hpp": C.INPUT_PROCESSING,
    "proto_pollution": C.INPUT_PROCESSING,
    "deserialization": C.INPUT_PROCESSING,
    "open_redirect": C.INPUT_PROCESSING,
    "ssrf": C.INPUT_PROCESSING,
    "fuzzer": C.INPUT_PROCESSING,
    "dumper": C.INPUT_PROCESSING,
    # Client-side
    "xss": C.CLIENT_SIDE,
    "cors": C.CLIENT_SIDE,
    # Authentication
    "jwt": C.AUTHENTICATION,
    "oauth": C.AUTHENTICATION,
    "mfa_bypass": C.AUTHENTICATION,
    "brute_force": C.AUTHENTICATION,
    # Authorization
    "idor": C.AUTHORIZATION,
    # API
    "api_abuse": C.API,
    "api_versioning": C.API,
    "graphql": C.API,
    "websocket": C.API,
    # HTTP edge / proxy / cache
    "request_smuggling": C.HTTP_EDGE,
    "h2_smuggling": C.HTTP_EDGE,
    "cache_poisoning": C.HTTP_EDGE,
    # Business logic
    "race_condition": C.BUSINESS_LOGIC,
    "llm_logic": C.BUSINESS_LOGIC,
    # Network
    "port_scanner": C.NETWORK,
    "network_exploits": C.NETWORK,
    "sc_crawler": C.NETWORK,
    # DNS / domain
    "reconnaissance": C.DNS_DOMAIN,
    "osint": C.DNS_DOMAIN,
    "discovery": C.WEB_APP,
    # TLS / cryptographic configuration
    "tls": C.TLS_CRYPTO,
    # Secrets exposure
    "secrets": C.SECRETS,
    # File handling
    "uploader": C.FILE_HANDLING,
    "upload": C.FILE_HANDLING,
    # Security controls
    "waf": C.SECURITY_CONTROLS,
    "firewall_bypass": C.SECURITY_CONTROLS,
    "gatebreaker": C.SECURITY_CONTROLS,
    # Technology / version
    "tech_exploits": C.TECH_VERSION,
    # Cloud
    "cloud_scanner": C.CLOUD_PLATFORM,
    "cloud_scan": C.CLOUD_PLATFORM,
    # Broad scanners touch the web-app surface
    "deep_scan": C.WEB_APP,
    "recon": C.DNS_DOMAIN,
    "passive_recon": C.DNS_DOMAIN,
    "real_ip": C.DNS_DOMAIN,
    "shield_detect": C.SECURITY_CONTROLS,
    "enrich": C.TECH_VERSION,
    "exploit_search": C.TECH_VERSION,
    "attack_map": C.WEB_APP,
    "chain_detect": C.BUSINESS_LOGIC,
    "agent_scan": C.WEB_APP,

    # Canonical engine/config aliases.  Coverage is keyed by the names in
    # ``AtomicEngine._load_modules``; keeping only implementation filenames
    # here made successfully executed validators look like blind spots.
    "tls_scan": C.TLS_CRYPTO,
    "secrets_scan": C.SECRETS,
    "tech_exploit": C.TECH_VERSION,
    "network_exploit": C.NETWORK,

    # Network and infrastructure validators.
    "dns_attacks": C.DNS_DOMAIN,
    "snmp_enum": C.NETWORK,
    "smb_attacks": C.NETWORK,
    "ssh_attacks": C.NETWORK,
    "rdp_attacks": C.NETWORK,
    "nfs_enum": C.NETWORK,
    "rpc_enum": C.NETWORK,
    "vnc_attacks": C.NETWORK,
    "ipv6_attacks": C.NETWORK,
    "vlan_hopping": C.NETWORK,
    "vpn_attacks": C.NETWORK,
    "dhcp_attacks": C.NETWORK,
    "arp_attacks": C.NETWORK,
    "icmp_attacks": C.NETWORK,

    # Web/API coverage added by the complete module registry.
    "csrf": C.WEB_APP,
    "clickjacking": C.CLIENT_SIDE,
    "host_header": C.HTTP_EDGE,
    "mass_assignment": C.API,
    "webdav": C.FILE_HANDLING,
    "ssi_injection": C.INPUT_PROCESSING,
    "soap_wsdl": C.API,
    "grpc": C.API,
    "webhook_ssrf": C.API,

    # Cloud, supply-chain, crypto, and specialist validators.
    "container_escape": C.CLOUD_PLATFORM,
    "cicd_injection": C.CLOUD_PLATFORM,
    "aws_iam_privesc": C.CLOUD_PLATFORM,
    "service_mesh": C.CLOUD_PLATFORM,
    "ics_protocols": C.NETWORK,
    "typosquatting": C.DNS_DOMAIN,
    "covert_channels": C.NETWORK,
    "crypto_weakness": C.TLS_CRYPTO,
    "coverage_fuzz": C.INPUT_PROCESSING,
    "symbolic_exec": C.INPUT_PROCESSING,

    # State-changing modules remain mapped for honest reporting; whether they
    # may execute is decided by authorization and coverage-closure gates.
    "credential_dump": C.SECRETS,
    "lateral_movement": C.NETWORK,
    "ad_attacks": C.AUTHORIZATION,
}

# Canonical findings often carry a human-readable technique (for example
# ``SQL Injection (Error-based)``) rather than the engine module key.  Exact
# lookup alone therefore lost issue evidence from the surface ledger.
_TECHNIQUE_MARKERS = (
    ("sql injection", C.INPUT_PROCESSING),
    ("nosql injection", C.INPUT_PROCESSING),
    ("command injection", C.INPUT_PROCESSING),
    ("template injection", C.INPUT_PROCESSING),
    ("local file inclusion", C.INPUT_PROCESSING),
    ("xml external entity", C.INPUT_PROCESSING),
    ("server-side request forgery", C.INPUT_PROCESSING),
    ("cross-site scripting", C.CLIENT_SIDE),
    ("open redirect", C.INPUT_PROCESSING),
    ("file upload", C.FILE_HANDLING),
    ("parameter pollution", C.INPUT_PROCESSING),
    ("prototype pollution", C.INPUT_PROCESSING),
    ("race condition", C.BUSINESS_LOGIC),
    ("request smuggling", C.HTTP_EDGE),
    ("cache poisoning", C.HTTP_EDGE),
    ("broken object authorization", C.AUTHORIZATION),
    ("insecure direct object", C.AUTHORIZATION),
)


def category_for(name: str) -> Optional[str]:
    """Return the surface category for a module/technique name, or None."""
    if not name:
        return None
    normalized = str(name).strip().lower()
    exact = MODULE_SURFACE_CATEGORY.get(normalized)
    if exact is not None:
        return exact
    for marker, category in _TECHNIQUE_MARKERS:
        if marker in normalized:
            return category
    return None


def build_surface_ledger(
    enabled_modules: Optional[Iterable[str]] = None,
    findings: Optional[Iterable] = None,
) -> SurfaceLedger:
    """Build a populated :class:`SurfaceLedger` from a run's inputs.

    * Each enabled module marks its category ``TESTED_NO_ISSUE`` (it ran).
    * Each finding marks its technique's category ``TESTED_ISSUES`` (with the
      finding id as evidence). Issue marks win over clean marks.

    Unmapped modules/techniques are ignored, so surfaces nothing touched stay
    NOT_TESTED and appear as explicit blind spots.
    """
    ledger = SurfaceLedger()

    for name in enabled_modules or []:
        cat = category_for(name)
        if cat is not None:
            ledger.record_tested(cat, count=1)

    for f in findings or []:
        technique = getattr(f, "technique", "") if not isinstance(f, dict) else f.get("technique", "")
        cat = category_for(technique)
        if cat is None:
            continue
        fid = getattr(f, "finding_id", "") if not isinstance(f, dict) else f.get("finding_id", "")
        ledger.record_tested(cat, count=0, had_issue=True, evidence_ref=fid or "")

    return ledger


def known_modules() -> List[str]:
    """Sorted list of all mapped module/technique names."""
    return sorted(MODULE_SURFACE_CATEGORY)
