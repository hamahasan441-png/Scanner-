"""Regression tests for the v12 operator planner and deployment wiring."""
from __future__ import annotations

import argparse
import contextlib
import io
import json
import unittest
from unittest import mock

from atomic import __version__
from atomic.__main__ import cmd_dashboard, cmd_scan, main
from atomic.preflight import build_operator_plan, run_doctor
from atomic.profiles import PROFILES, get, to_main_args
from core.cli.parser import create_parser


class TestProfileContract(unittest.TestCase):
    def test_all_profiles_parse_in_canonical_cli(self):
        parser = create_parser()
        for name, profile in PROFILES.items():
            with self.subTest(profile=name):
                argv = to_main_args(
                    profile,
                    "https://example.invalid/path",
                    authorized=(name == "full"),
                )
                parsed = parser.parse_args(argv)
                self.assertTrue(parsed.strict_scope)
                self.assertEqual(parsed.allow_domain, "example.invalid")
                self.assertEqual(parsed.external_tools, profile.auto_external_tools)

    def test_full_profile_is_authorized_end_to_end(self):
        parsed = create_parser().parse_args(
            to_main_args(get("full"), "https://example.invalid", authorized=True)
        )
        self.assertTrue(parsed.authorized)
        self.assertTrue(parsed.auto_exploit)
        self.assertTrue(parsed.race)
        self.assertTrue(parsed.deser)
        self.assertTrue(parsed.fuzz)
        self.assertTrue(parsed.cache_poison)
        self.assertEqual(parsed.format, "all")

    @mock.patch("atomic.__main__.subprocess.call", return_value=0)
    def test_scan_uses_installed_module_entrypoint(self, call):
        args = argparse.Namespace(
            target="example.invalid",
            profile="quick",
            authorized=False,
            yes=False,
        )
        self.assertEqual(cmd_scan(args), 0)
        command = call.call_args.args[0]
        self.assertEqual(command[1:3], ["-m", "main"])
        self.assertIn("--strict-scope", command)

    @mock.patch("atomic.__main__.subprocess.call", return_value=0)
    def test_dashboard_translates_wrapper_flags(self, call):
        args = argparse.Namespace(host="127.0.0.1", port=5050, explicit_host=True)
        self.assertEqual(cmd_dashboard(args), 0)
        command = call.call_args.args[0]
        self.assertIn("--web-host", command)
        self.assertIn("--web-port", command)
        self.assertNotIn("--host", command)


class TestPlannerAndDoctor(unittest.TestCase):
    def test_source_deployment_has_no_critical_health_failures(self):
        report = run_doctor()
        self.assertNotEqual(report["status"], "failed")
        self.assertEqual(report["summary"]["critical_failures"], 0)

    def test_full_plan_without_authorization_is_blocked(self):
        plan = build_operator_plan(
            get("full"), "https://example.invalid", authorized=False
        )
        self.assertEqual(plan["status"], "blocked")
        self.assertFalse(plan["safety"]["post_exploitation_enabled"])
        self.assertNotIn("post_exploitation", [s["key"] for s in plan["stages"]])

    def test_plan_json_is_clean_machine_output(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            rc = main(["plan", "example.invalid", "--profile", "quick", "--json"])
        self.assertEqual(rc, 0)
        payload = json.loads(output.getvalue())
        self.assertEqual(payload["framework"]["version"], __version__)
        self.assertEqual(payload["target"]["hostname"], "example.invalid")

    def test_doctor_json_is_clean_machine_output(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            rc = main(["doctor", "--json"])
        self.assertEqual(rc, 0)
        payload = json.loads(output.getvalue())
        self.assertEqual(payload["summary"]["critical_failures"], 0)


if __name__ == "__main__":
    unittest.main()
