"""Regression tests for evidence-backed coverage and preflight assurance."""
from __future__ import annotations

import unittest

from atomic.preflight import build_operator_plan
from atomic.profiles import get
from core.coverage_executor import RealValidatorExecutor
from core.models import (
    CoverageState,
    SurfaceCategory,
    SurfaceEndpoint,
    TargetSurface,
)
from core.surface_map import category_for


class TestPlanAssurance(unittest.TestCase):
    def test_plan_exposes_gates_and_blind_spots(self):
        plan = build_operator_plan(
            get("quick"), "https://example.invalid/", authorized=False
        )
        assurance = plan["assurance"]
        self.assertEqual(assurance["summary"]["critical_failures"], 0)
        self.assertTrue(assurance["blind_spots"])
        gates = {g["name"]: g for g in assurance["gates"]}
        self.assertEqual(gates["strict_host_scope"]["result"], "pass")
        self.assertEqual(gates["runtime_coverage_truth"]["result"], "pass")

    def test_full_plan_without_authorization_remains_blocked(self):
        plan = build_operator_plan(
            get("full"), "https://example.invalid/", authorized=False
        )
        self.assertEqual(plan["status"], "blocked")
        gates = {g["name"]: g for g in plan["assurance"]["gates"]}
        self.assertEqual(gates["state_change_authorization"]["result"], "fail")

    def test_canonical_module_aliases_are_mapped(self):
        self.assertEqual(category_for("nosql"), SurfaceCategory.INPUT_PROCESSING)
        self.assertEqual(category_for("upload"), SurfaceCategory.FILE_HANDLING)
        self.assertEqual(category_for("cloud_scan"), SurfaceCategory.CLOUD_PLATFORM)
        self.assertEqual(
            category_for("SQL Injection (Error-based)"),
            SurfaceCategory.INPUT_PROCESSING,
        )


class _ScopeRaises:
    def is_in_scope(self, _url):
        raise RuntimeError("scope unavailable")


class _NoopModule:
    pass


class _Engine:
    def __init__(self, module, scope=None):
        self._modules = {"noop": module}
        self.scope = scope
        self.findings = []


class TestCoverageExecutorFailClosed(unittest.TestCase):
    def test_scope_error_is_blocked(self):
        result = RealValidatorExecutor(
            _Engine(_NoopModule(), scope=_ScopeRaises())
        )("https://example.invalid/", "noop")
        self.assertEqual(result, CoverageState.BLOCKED)

    def test_module_without_applicable_entrypoint_is_unsupported(self):
        result = RealValidatorExecutor(
            _Engine(_NoopModule())
        )("https://example.invalid/", "noop")
        self.assertEqual(result, CoverageState.UNSUPPORTED)


class TestRuntimeCoverageTruth(unittest.TestCase):
    def _engine(self):
        from core.engine import AtomicEngine

        eng = AtomicEngine(
            {"quiet": True, "modules": {"sqli": True, "missing_validator": True}}
        )
        eng.surface = TargetSurface(
            target="https://example.invalid/",
            endpoints=[SurfaceEndpoint(url="https://example.invalid/a", method="GET")],
        )
        return eng

    def test_enabled_is_not_reported_as_tested(self):
        eng = self._engine()
        before = eng.get_coverage_summary()
        self.assertEqual(before.endpoints_tested, 0)
        eng._runtime_coverage.mark_tested(
            "https://example.invalid/a", "sqli", method="GET"
        )
        after = eng.get_coverage_summary()
        self.assertEqual(after.endpoints_tested, 1)

    def test_unloaded_validator_is_explicit(self):
        eng = self._engine()
        plan = eng.get_coverage_plan()
        self.assertIn("missing_validator", plan["unavailable_validators"])


if __name__ == "__main__":
    unittest.main()
