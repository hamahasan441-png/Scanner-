# ATOMIC Framework 12.0.1 Hardening Release

Date: 2026-08-30

This patch release closes reliability, scope-containment, and test-isolation
gaps found during a full defensive assurance pass.

## Corrected failures

- Plugin timeouts now terminate fork-capable worker processes instead of
  returning from a thread timeout while silently waiting for the worker.
- Discovery no longer performs passive archive network calls unless passive
  archive collection is explicitly enabled. Archive calls use the centralized
  requester and a bounded timeout.
- Surface and coverage APIs recover additive runtime coverage state for older,
  deserialized, and lightweight engine instances.
- Every scan now binds the centralized outbound network policy to its declared
  target scope before loading robots.txt or testing connectivity.
- Redirects are followed manually under an active network policy. Every
  destination is approved before connection, cross-host credentials are
  stripped, and the redirect count is bounded.
- robots.txt retrieval now uses the framework requester rather than a direct
  library network call. Wildcard user-agent exclusions are included in scope
  exclusions.
- Passive recon no longer repeats archive collection through discovery after
  its own passive URL fan-out.

## Verification gates

- Python bytecode compilation
- Full non-integration test suite
- Full integration test suite, including local open-redirect containment
- Dependency declaration synchronization
- Release metadata/profile/runtime-asset contract
- Focused type checking and high-signal static linting
- High-confidence, high-severity security static analysis

## Residual design note

On platforms without process `fork`, plugin timeout handling uses a non-waiting
thread fallback because Python cannot safely terminate an arbitrary running
thread. Fork-capable platforms use the killable process path.
