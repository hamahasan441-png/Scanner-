#!/usr/bin/env python3
"""Fail when release metadata, profile wiring, or runtime assets drift."""
from __future__ import annotations

import contextlib
import io
import sys
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from atomic.profiles import PROFILES, to_main_args
from atomic.runtime_paths import resolve_asset
from config import Config
from core.cli.parser import create_parser


def normalized(version: str) -> str:
    parts = str(version).split(".")
    return ".".join((parts + ["0", "0"])[:3])


def main() -> int:
    errors = []
    metadata = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    package_version = metadata["project"]["version"]
    if package_version != normalized(Config.VERSION):
        errors.append(
            f"version drift: Config={Config.VERSION}, pyproject={package_version}"
        )

    parser = create_parser()
    for name, profile in PROFILES.items():
        argv = to_main_args(
            profile,
            "https://example.invalid",
            authorized=(name == "full"),
        )
        try:
            with contextlib.redirect_stderr(io.StringIO()):
                parsed = parser.parse_args(argv)
        except SystemExit as exc:
            errors.append(f"profile {name} does not parse (exit {exc.code}): {argv}")
            continue
        if not parsed.strict_scope or parsed.allow_domain != "example.invalid":
            errors.append(f"profile {name} is not strict-host scoped")
        expected_external = profile.auto_external_tools
        if parsed.external_tools is not expected_external:
            errors.append(f"profile {name} external-tool policy drift")
        if name == "full" and not parsed.authorized:
            errors.append("full profile lost the canonical authorization flag")

    required_assets = (
        ("scanner_rules.yaml", False),
        ("schemas/scanner_rules.schema.json", False),
        ("runtime/metadata/tools.json", False),
        ("nuclei_templates", True),
    )
    for relative, directory in required_assets:
        if resolve_asset(relative, directory=directory) is None:
            errors.append(f"missing runtime asset: {relative}")

    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    if "ATOMIC_HOME=/data" not in compose or "/data/reports" not in compose:
        errors.append("container output paths are not wired to ATOMIC_HOME")
    if "ATOMIC_API_KEY:?" not in compose:
        errors.append("public dashboard composition does not require an API key")

    if errors:
        for error in errors:
            print(f"FAIL: {error}", file=sys.stderr)
        return 1
    print(
        f"release contract OK: v{package_version}, {len(PROFILES)} profiles, "
        f"strict scope, packaged assets, container persistence"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
