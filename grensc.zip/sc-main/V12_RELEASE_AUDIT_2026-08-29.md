# ATOMIC Framework v12.0 — Release Audit

Date: 2026-08-29
Codename: TITAN

## Release decision

**PASS — all locally executable release gates are green.**

The deployment doctor intentionally reports `degraded` in an environment with
no real external scanner binaries. This is not a release failure: Python-native
modules remain available, and the bundled simulation wrappers are disabled by
default so fabricated tool output cannot be mistaken for real evidence.

## Upgrade delivered

- Added `atomic plan` for deterministic, network-free, machine-readable scan
  plans with stages, modules, strict scope, authorization state, tool readiness,
  output path, and the exact canonical command.
- Added `atomic doctor` for deployment, asset, profile-contract, output-path,
  and external-tool readiness checks.
- Repaired every named profile's canonical CLI translation. The old wrapper
  emitted unsupported race, deserialization, fuzzer, cache, output, format, and
  external-tool flags.
- Propagated `--authorized` to the canonical engine. Full-profile execution is
  now fail-closed instead of silently changing to a different profile.
- Locked wrapper scans to the normalized target host and displays the engine's
  execution plan before scanning.
- Repaired dashboard translation from wrapper `--host/--port` to canonical
  `--web-host/--web-port`.
- Replaced source-only `main.py` subprocess assumptions with `python -m main`
  for consistent source and installed-wheel execution.
- Packaged scanner rules, schema, runtime metadata, and all 15 built-in Nuclei
  templates; asset resolution now works from both source and installed wheels.
- Added an executable release contract that checks version alignment, all four
  profiles, strict scope, tool policy, assets, and container persistence.
- Wired container state to `ATOMIC_HOME=/data`, persisted reports/shells,
  required an API key for the public dashboard composition, and added a
  deployment health check.
- Extended CI and local gates to cover release-contract drift, installed-wheel
  planner/doctor smoke tests, new typed modules, and the `atomic` security scope.

## Gate results

| Gate | Result |
| --- | --- |
| Python compilation | PASS |
| Dependency metadata sync | PASS — 18 exact runtime pins |
| Release contract | PASS — 4/4 profiles parse through canonical CLI |
| Fatal/error lint (`E9`, `F63`, `F7`, `F82`) | PASS — 0 findings |
| Safety/path type check | PASS — 8 modules |
| Unit tests | PASS — 5,513 passed, 1 skipped, 17 subtests passed |
| Local integration tests | PASS — 64 passed, 1 skipped, 27 subtests passed |
| Bandit HIGH severity / HIGH confidence | PASS — 0 findings |
| Dependency vulnerability audit | PASS — no known vulnerabilities |
| Source and wheel build | PASS |
| Clean installed-wheel dependency check | PASS |
| Installed-wheel version | PASS — v12.0 |
| Installed-wheel packaged assets | PASS — rules, schema, metadata, 15 templates |
| Installed-wheel doctor | PASS — 0 critical failures |
| Installed-wheel planner | PASS — strict-scope plan is ready |

CodeQL remains configured in `.github/workflows/codeql.yml` and executes on
GitHub-hosted runners. A Docker engine is not installed in the local gate
environment; container configuration is covered by the release contract and CI
source checks.
