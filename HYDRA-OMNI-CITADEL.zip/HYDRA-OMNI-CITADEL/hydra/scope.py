"""CITADEL scope manifests and signed Guard receipts for every dispatched prompt."""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
from dataclasses import asdict, dataclass
from typing import Iterable

from .mutator import Mutator, Variant
from .seed_guard import GuardDecision, SeedGuard, normalize_text
from .sentinel import AuditLog, sanitize_data


SCOPE_SCHEMA_VERSION = 1
_PROCESS_SCOPE_KEY = secrets.token_bytes(32)


def content_hash(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def normalized_hash(text: str) -> str:
    return hashlib.sha256(normalize_text(text).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ScopeManifest:
    scope_id: str
    policy_version: str
    seed_hashes: dict[str, str]
    topics: tuple[str, ...]
    allowed_families: tuple[str, ...]
    schema_version: int = SCOPE_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return sanitize_data(asdict(self))


@dataclass(frozen=True)
class GuardReceipt:
    scope_id: str
    policy_version: str
    seed_id: str
    variant_id: str
    prompt_hash: str
    normalized_prompt_hash: str
    parent_hash: str
    accepted: bool
    reason: str
    signature: str
    schema_version: int = SCOPE_SCHEMA_VERSION

    def unsigned(self) -> dict:
        value = asdict(self)
        value.pop("signature")
        return value

    def to_dict(self) -> dict:
        return sanitize_data(asdict(self))


class ScopeCompiler:
    def __init__(self, policy_version: str = "citadel-scope-v1"):
        self.policy_version = str(policy_version)

    def compile(self, seeds: Iterable[dict]) -> ScopeManifest:
        seed_list = list(seeds)
        hashes = {str(seed["id"]): normalized_hash(str(seed["prompt"])) for seed in seed_list}
        topics = tuple(sorted({normalize_text(seed.get("topic", "")) for seed in seed_list}))
        families = tuple(sorted(family for values in Mutator.FAMILIES.values() for family in values))
        canonical = json.dumps({"policy": self.policy_version, "seeds": hashes,
                                "topics": topics, "families": families},
                               sort_keys=True, separators=(",", ":"))
        scope_id = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:24]
        return ScopeManifest(scope_id, self.policy_version, hashes, topics, families)


class ScopeGate:
    """Runs Guard for each descendant and binds the decision to the exact prompt bytes."""

    def __init__(self, manifest: ScopeManifest, guard: SeedGuard,
                 key: bytes | None = None, audit: AuditLog | None = None):
        self.manifest = manifest
        self.guard = guard
        self._key = bytes(key or _PROCESS_SCOPE_KEY)
        if len(self._key) < 16:
            raise ValueError("scope signing key must contain at least 16 bytes")
        self.audit = audit

    def _sign(self, value: dict) -> str:
        payload = json.dumps(value, sort_keys=True, ensure_ascii=False,
                             separators=(",", ":")).encode("utf-8")
        return hmac.new(self._key, payload, hashlib.sha256).hexdigest()

    def _family_allowed(self, family: str) -> bool:
        family = str(family)
        if family in self.manifest.allowed_families:
            return True
        if family.startswith(("reflex_gate:", "reflex_tier2:",
                              "reflex_tier3:", "reflex_soft:")):
            return True
        tokens = family.replace("+", "x").split("x")
        return bool(tokens) and all(
            token in self.manifest.allowed_families
            or token.startswith("reflex_") for token in tokens
        )

    def issue(self, variant: Variant, seed: dict) -> GuardReceipt:
        seed_id = str(seed.get("id", ""))
        if seed_id != variant.seed_id or seed_id not in self.manifest.seed_hashes:
            decision = GuardDecision(variant.seed_id, False, "scope_seed_mismatch")
        elif not self._family_allowed(variant.family):
            decision = GuardDecision(variant.seed_id, False, "scope_family_rejected",
                                     variant.family)
        else:
            decision = self.guard.evaluate({"id": variant.id,
                                            "topic": seed.get("topic", ""),
                                            "prompt": variant.text})
        unsigned = {
            "scope_id": self.manifest.scope_id,
            "policy_version": self.manifest.policy_version,
            "seed_id": variant.seed_id,
            "variant_id": variant.id,
            "prompt_hash": content_hash(variant.text),
            "normalized_prompt_hash": normalized_hash(variant.text),
            "parent_hash": content_hash(variant.parent or ""),
            "accepted": bool(decision.accepted),
            "reason": decision.reason,
            "schema_version": SCOPE_SCHEMA_VERSION,
        }
        receipt = GuardReceipt(**unsigned, signature=self._sign(unsigned))
        if self.audit:
            self.audit.emit("scope_receipt", scope_id=receipt.scope_id,
                            seed_id=receipt.seed_id, variant_id=receipt.variant_id,
                            accepted=receipt.accepted, reason=receipt.reason,
                            prompt_hash=receipt.prompt_hash)
        return receipt

    def verify(self, receipt: GuardReceipt | dict, prompt: str) -> bool:
        try:
            value = receipt if isinstance(receipt, GuardReceipt) else GuardReceipt(**receipt)
        except (TypeError, ValueError):
            return False
        return (
            value.scope_id == self.manifest.scope_id
            and value.policy_version == self.manifest.policy_version
            and value.accepted
            and hmac.compare_digest(value.prompt_hash, content_hash(prompt))
            and hmac.compare_digest(value.signature, self._sign(value.unsigned()))
        )
