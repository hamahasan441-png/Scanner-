# HYDRA-OMNI CITADEL

CITADEL is a benign-only, authorized robustness benchmark for measuring whether
LLMs preserve response-policy behavior across encoding, structural, framing, and
multi-turn prompt shapes. Guard remains organ #1. Every prompt is checked again
after mutation and receives a signed receipt bound to its exact bytes before it
can enter the dispatcher.

## Quick start

Use Python 3.12 with the bundled hash-locked dependency set:

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install --require-hashes -r hydra/requirements.txt
python -m unittest discover -s hydra/tests -v
python -m hydra run --smoke --output campaign-smoke
python -m hydra verify --output campaign-smoke
```

Provider credentials are accepted only through the environment variables named
in `models.json`. Set keys only for enabled providers. For signatures that must
verify in a later process, set `HYDRA_ARTIFACT_HMAC_KEY` and
`HYDRA_CHECKPOINT_HMAC_KEY` to separate random values of at least 16 bytes.
Neither key is serialized.

## Control flow

1. `SeedGuard` admits benign seeds.
2. `ScopeCompiler` commits to the admitted seed set and permitted family set.
3. `Mutator`, `Evolver`, `ReflexEngine`, and `MemoryQuarantine` create candidates.
4. `ScopeGate` re-runs Guard and signs an exact-prompt receipt for each candidate.
5. `BlockedScheduler` randomizes comparable cells and rotates providers fairly.
6. `Dispatcher` validates the declared origin and resolved public addresses, then
   sends a size- and depth-bounded request with redirect following disabled.
7. `JudgeEnsemble` evaluates locally and marks uncertain results non-decisive.
8. `DriftDetector`, `HashChainLedger`, `ArtifactSigner`, and `Cartographer`
   produce revision-aware, tamper-evident evidence and reports.
9. `MemoryQuarantine` activates learning only after multiple complete, signed,
   non-drifted runs with sufficient samples.

## Commands

```bash
python -m hydra run --output campaign
python -m hydra run --smoke --output campaign-smoke
python -m hydra resume --output campaign
python -m hydra replay --source campaign/replay_store --output replayed --smoke
python -m hydra report --output campaign
python -m hydra verify --output campaign
```

`replay` uses `OfflineDispatcher`, which has no HTTP session or network path. A
missing fixture fails closed as `replay_miss`. Live exchanges are recorded as
scrubbed inert JSON for reproducibility.

## CITADEL modules

| Module | Contract |
| --- | --- |
| `scope.py` | Deterministic scope manifest and signed exact-prompt Guard receipts. |
| `provenance.py` | Run manifest, code/config/registry hashes, chained events, HMAC artifact signatures. |
| `scheduler.py` | Blocked randomization, provider fairness, Wilson-interval stopping. |
| `calibrator.py` | Versioned local ensemble, gold-set threshold fitting, uncertainty labels. |
| `drift.py` | Model revision identity and control-probe behavioral drift signals. |
| `replay.py` | Scrubbed fixtures and a network-impossible offline dispatcher. |
| `invariants.py` | AST policy checks plus runtime secret, JSON, and bind tripwires. |
| `memory_v2.py` | Revision-aware quarantine, evidence decay, cross-model transfer, burn recovery. |

BASTION protections remain in `sentinel.py`: environment-only secrets, exact
origin allowlists, public-address validation, redirect refusal, safe rendering,
atomic writes, signed checkpoints, scrubbed append-only audit, static adapters,
and loopback-only viewer policy. Provider output is always inert data: it is
never evaluated, executed, imported, passed to a process, or used as an egress
destination.

## Failure behavior

- Missing key: abort before dispatch with a masked error.
- Undeclared host, private DNS answer, or redirect: fail closed and do not follow.
- Oversized, invalid UTF-8, non-JSON, or over-nested response: reject visibly.
- Unsupported knob: flag and skip only that setting.
- Provider outage: bounded retry, then only a statically declared family fallback.
- Budget cap: locked reservation stops pending work and writes a partial report.
- Checkpoint corruption or HMAC mismatch: preserve stale files and start clean.
- Scope receipt mismatch: block immediately before dispatch.
- Drift or revision change: quarantine current learning evidence.
- Incomplete, unsigned, single-run, or low-sample evidence: never activate Memory.

## Verification

The test suite uses temporary files and fake sessions and makes no provider
calls. It covers Guard normalization, exact receipt binding, fallback behavior,
DNS and redirect controls, response limits, budget races, checkpoint recovery,
report escaping, replay, scheduler determinism, calibration, drift, provenance,
static invariants, Reflex depth, and Memory quarantine/recovery.

```bash
PYTHONPATH=. python -m unittest discover -s hydra/tests -q
python -m compileall -q hydra
```

See `CITADEL_UPGRADE_NOTES.md` for the patch map and security review.
