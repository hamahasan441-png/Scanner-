"""Static and runtime CITADEL invariant verification."""

from __future__ import annotations

import ast
import json
import unicodedata
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .sentinel import require_loopback, sanitize_data


FORBIDDEN_IMPORTS = frozenset({"subprocess", "importlib"})
FORBIDDEN_CALLS = frozenset({"eval", "exec", "system", "popen", "Popen",
                             "check_call", "check_output"})


@dataclass(frozen=True)
class InvariantFinding:
    code: str
    path: str
    line: int
    detail: str


@dataclass
class InvariantReport:
    scanned_files: int = 0
    findings: list[InvariantFinding] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not self.findings

    def to_dict(self) -> dict:
        return sanitize_data({"scanned_files": self.scanned_files,
                              "passed": self.passed,
                              "findings": [asdict(item) for item in self.findings]})

    def require_pass(self) -> None:
        if self.findings:
            first = self.findings[0]
            raise RuntimeError(f"invariant failure {first.code} at {first.path}:{first.line}")


class StaticPolicyScanner:
    """AST checks for dynamic execution, process launch, and unsafe shell use."""

    def scan(self, root: str | Path) -> InvariantReport:
        root = Path(root)
        report = InvariantReport()
        for path in sorted(root.rglob("*.py")):
            if "__pycache__" in path.parts:
                continue
            report.scanned_files += 1
            try:
                tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            except (SyntaxError, UnicodeError) as exc:
                report.findings.append(InvariantFinding(
                    "syntax", str(path), int(getattr(exc, "lineno", 0) or 0), type(exc).__name__
                ))
                continue
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    names = [alias.name.split(".")[0] for alias in node.names] if isinstance(node, ast.Import) \
                        else [str(node.module or "").split(".")[0]]
                    for name in names:
                        if name in FORBIDDEN_IMPORTS:
                            report.findings.append(InvariantFinding(
                                "forbidden_import", str(path), node.lineno, name
                            ))
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        name = node.func.id
                    elif isinstance(node.func, ast.Attribute):
                        name = node.func.attr
                    else:
                        name = ""
                    if name in FORBIDDEN_CALLS:
                        report.findings.append(InvariantFinding(
                            "forbidden_call", str(path), node.lineno, name
                        ))
                    for keyword in node.keywords:
                        if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant) \
                                and keyword.value.value is True:
                            report.findings.append(InvariantFinding(
                                "shell_true", str(path), node.lineno, name
                            ))
        return report


class RuntimeTripwire:
    @staticmethod
    def assert_secret_absent(paths: list[str | Path], canaries: list[str | bytes]) -> None:
        encoded = [value.encode("utf-8") if isinstance(value, str) else bytes(value)
                   for value in canaries]
        for path_value in paths:
            path = Path(path_value)
            if not path.exists() or not path.is_file():
                continue
            payload = path.read_bytes()
            for canary in encoded:
                if canary and canary in payload:
                    raise RuntimeError(f"secret canary found in artifact: {path.name}")

    @staticmethod
    def assert_control_free_json(path: str | Path) -> None:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
        rendered = json.dumps(value, ensure_ascii=False)
        forbidden = [character for character in rendered
                     if unicodedata.category(character) in {"Cc", "Cf"}
                     and character not in "\n\r\t"]
        if forbidden:
            raise RuntimeError(f"control characters found in JSON artifact: {Path(path).name}")

    @staticmethod
    def assert_local_bind(host: str) -> None:
        require_loopback(host)
