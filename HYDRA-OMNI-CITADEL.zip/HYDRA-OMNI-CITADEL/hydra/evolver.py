"""Genetic evolution with lineage, elitism, crossover, and immigrants."""

from __future__ import annotations

import hashlib
import random
import re
from dataclasses import dataclass

from .mutator import Mutator, Variant


@dataclass(frozen=True)
class ScoredVariant:
    variant: Variant
    fitness: float


class Evolver:
    def __init__(self, population_size: int = 50, elite_fraction: float = 0.2,
                 immigrant_every: int = 2, seed: int = 2035):
        if population_size < 2:
            raise ValueError("population_size must be at least 2")
        self.population_size = population_size
        self.elite_fraction = max(0.05, min(0.5, elite_fraction))
        self.immigrant_every = max(1, immigrant_every)
        self.random = random.Random(seed)
        self.mutator = Mutator(seed)
        self.lineage: list[dict] = []

    def initialize(self, variants: list[Variant]) -> list[Variant]:
        if not variants:
            raise ValueError("cannot initialize from an empty variant set")
        ordered = sorted(variants, key=lambda x: x.id)
        if len(ordered) >= self.population_size:
            return ordered[:self.population_size]
        return [ordered[i % len(ordered)] for i in range(self.population_size)]

    def _crossover(self, left: Variant, right: Variant, generation: int) -> Variant:
        frame = left.text
        if right.tier == 1:
            text = self.mutator.apply(frame, right.family)
            family = f"{left.family}+{right.family}"
        else:
            split = max(1, len(frame) // 2)
            text = frame[:split] + "\n" + right.text[len(right.text) // 2:]
            family = f"{left.family}x{right.family}"
        text = self._synonym_reorder(text)
        digest = hashlib.sha256(f"{left.id}|{right.id}|{generation}|{text}".encode()).hexdigest()[:16]
        child = Variant(f"v-{digest}", left.seed_id, max(left.tier, right.tier), family,
                        text, left.id, generation, {"parents": [left.id, right.id]})
        self.lineage.append({"child": child.id, "parents": [left.id, right.id],
                             "generation": generation, "family": family})
        return child

    def _synonym_reorder(self, text: str) -> str:
        replacements = {"answer": "respond", "explain": "describe", "technical": "engineering"}
        for source, target in replacements.items():
            if self.random.random() < 0.35:
                text = re.sub(rf"\b{source}\b", target, text, flags=re.I)
        lines = text.splitlines()
        if len(lines) > 2 and self.random.random() < 0.3:
            middle = lines[1:-1]
            self.random.shuffle(middle)
            lines = [lines[0], *middle, lines[-1]]
        return "\n".join(lines)

    def next_generation(self, scored: list[ScoredVariant], generation: int,
                        immigrants: list[Variant] | None = None) -> list[Variant]:
        if not scored:
            raise ValueError("scored population is empty")
        ranked = sorted(scored, key=lambda x: (-x.fitness, x.variant.id))
        elite_count = max(2, int(self.population_size * self.elite_fraction))
        elites = [x.variant for x in ranked[:elite_count]]
        output = list(elites)
        immigrant_pool = sorted(immigrants or [], key=lambda x: x.id)
        if generation % self.immigrant_every == 0 and immigrant_pool:
            inject = min(max(1, self.population_size // 10), len(immigrant_pool))
            output.extend(immigrant_pool[:inject])
        while len(output) < self.population_size:
            left, right = self.random.sample(elites, 2)
            output.append(self._crossover(left, right, generation))
        return output[:self.population_size]
