# HYDRA-OMNI BASTION upgrade

BASTION hardens HYDRA-OMNI itself while preserving Guard as the first campaign organ and keeping every bundled probe benign and educational.

## Patch map

| File | Change | Reason |
| --- | --- | --- |
| `sentinel.py` | Adds environment-only secret loading, masked secret objects, exact-origin HTTPS egress, redirect rejection, scrubbed append-only audit, control-free JSON, atomic writes, signed checkpoint envelopes, and loopback enforcement. | Centralizes security invariants so adapters, persistence, and reports cannot implement weaker local versions. |
| `dispatcher.py` | Uses the static adapter registry, Sentinel credentials and egress policy, disables automatic redirects, masks errors, flags allowlist failures in an envelope, and audits budget activity. | Makes the outbound request boundary fail closed. Model responses remain inert data and never become request targets. |
| `seed_guard.py` | Preserves NFKC plus confusable normalization before all lexical/semantic checks and emits scrubbed rejection events. | Keeps Guard organ #1 and closes homoglyph bypasses without logging probe bodies. |
| `reflex.py` | Maps judge organs to four bounded repair classes and creates deterministic children with explicit lineage metadata. | Converts refusals into controlled next-generation mutations without relaxing Guard. |
| `memory.py` | Adds transactional SQLite `burn_registry` and `transfer_table` tables. | Excludes model-specific burned families at boot and transfers successful benign variants between models on later runs. |
| `orchestrator.py` | Wires Sentinel, Reflex, and Memory; validates signed checkpoints; rotates stale ledgers after integrity failure; preflights environment keys; and sanitizes ledgers. | Enforces the campaign lifecycle as one hardened state machine. |
| `cartographer.py` | Uses Sentinel writes and sanitization, retains Jinja autoescape, adds per-model burn rows and Memory summary. | Prevents report/JSON injection and exposes learned state. |
| `requirements.txt` | Fully pins direct and transitive dependencies with SHA-256 artifact hashes. | Makes dependency resolution reproducible and tamper-evident. |
| `tests/` | Adds Sentinel, Reflex, and Memory suites and updates dispatcher/checkpoint tests for the hardened contracts. | Locks in security behavior and compatibility. |

## Dependency graph

`seed_guard` depends on `sentinel`; `dispatcher` depends on `sentinel`; `memory` depends on `sentinel` and `mutator`; `reflex` depends on `mutator`; `cartographer` depends on `sentinel`; `orchestrator` composes all modules. No module imports providers dynamically.

## Security contracts

- Provider credentials are read only by `secrets_loader()` from named environment variables. Inline credentials are rejected. `SecretValue.__str__` and `__repr__` are masked, and registered bytes are scrubbed from audit, ledgers, checkpoints, JSON, reports, and exception text.
- Egress is restricted to exact HTTPS origins compiled from `models.json`. `aiohttp` automatic redirects are disabled. Undeclared redirect destinations become `egress_blocked` envelopes and are never contacted.
- Provider output is parsed only as inert JSON/text. It is not used as a URL, imported, evaluated, executed, or sent to a process.
- Checkpoints use schema version 2, atomic replacement, and HMAC-SHA256. The key is process-ephemeral by default. Set `HYDRA_CHECKPOINT_HMAC_KEY` in the environment for deliberate cross-process resume; it must be at least 16 bytes and is never serialized.
- Any malformed checkpoint, schema mismatch, or HMAC mismatch produces a clean campaign state. Existing ledgers are recoverably renamed before the fresh campaign writes new data.
- Audit records contain event metadata only, remove control characters, mask known secrets and token-shaped strings, and scrub email/IP patterns.
- Any future report viewer must pass `require_loopback()` and bind to `127.0.0.1`. The current report remains a standalone file and starts no server.

## Reflex policy

| Judge organ | Repair class | Action |
| --- | --- | --- |
| `platform_gate`, `hard_block` | gate | Rewrite framing words into neutral classroom language. |
| `named_frame_refusal` | tier 2 | Change structural skin without changing benign meaning. |
| `artifact_reasoning_refusal` | tier 3 | Use a concise manual/review shape. |
| `prose_leak` | soft | Tighten JSON-only instructions and prefix. |
| `pure_schema` | none | Retain; no repair child is needed. |

Every repair child receives a deterministic identifier, parent link, organ, repair action, and lineage type. Required repair children are inserted into the next population even when normal immigrant injection is not scheduled.

## Cross-run learning

`burn_registry` stores `(model, family)` burn state after a greater-than-20-percent ASR drop. At campaign boot the orchestrator loads this state and does not dispatch burned families to that model. `transfer_table` stores the best inert JSON exemplar for green families and targets it to other roster models. Transferred variants are tagged with source/target model metadata and are dispatched only to their target.

The default database is `.hydra_bastion/memory.sqlite3` relative to the campaign output parent. `HYDRA_STATE_DIR` can select another local state directory. SQLite uses WAL, full synchronous commits, a busy timeout, fixed SQL statements, and mode `0600` where supported.

## Failure modes

- Missing environment key: preflight aborts before network dispatch with a masked JSON error.
- Allowlist miss or undeclared redirect: a flagged `egress_blocked` envelope is returned; the target is not contacted.
- Provider outage: existing retry/backoff and declared OpenRouter fallback remain active.
- Provider payload drift: the static response normalizer raises a scrubbed provider error.
- Unsupported reasoning knob: the setting is skipped and flagged.
- Budget race: reservations remain serialized by an async lock and every reserve/settle/release/block is audited.
- Corrupt checkpoint or HMAC mismatch: load returns an empty state, stale ledgers are preserved under a rejected suffix, and the campaign restarts cleanly.
- Guard rejects all seeds: campaign aborts before secrets are preflighted or egress is possible.
- SQLite contention: WAL plus `busy_timeout` serializes writers; all updates run in one immediate transaction.

## Rejected trade-offs

- OS keyring or external vault: rejected to avoid new platform dependencies; provider keys remain environment-only.
- Dynamic adapter discovery: rejected because imports controlled by configuration expand the supply-chain surface; the registry is static.
- Redirect following: rejected because an explicit provider-base update is safer than implicit endpoint movement.
- Executable repair templates: rejected; Reflex uses fixed local transformations only.
- Real-time web UI: still rejected. The standalone escaped report has no listener or new egress surface.

## Installation and verification

Use Python 3.12 for the generated lock set:

```bash
python -m pip install --require-hashes -r requirements.txt
python -m unittest discover -s tests -v
python -m hydra run --smoke --output campaign-smoke
```

Before a live smoke campaign, export the environment variables named by the enabled providers in `models.json`. Tests use inert fake sessions and make no provider calls.
