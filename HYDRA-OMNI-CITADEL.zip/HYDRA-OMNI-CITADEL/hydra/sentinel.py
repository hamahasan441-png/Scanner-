"""BASTION self-hardening primitives for secrets, egress, integrity, and audit."""

from __future__ import annotations

import fcntl
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import socket
import tempfile
import threading
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping
from urllib.parse import urljoin, urlsplit


LOCAL_BIND_HOST = "127.0.0.1"
CHECKPOINT_SCHEMA_VERSION = 2
_PROCESS_HMAC_KEY = secrets.token_bytes(32)
_KNOWN_SECRET_VALUES: set[str] = set()
_SECRET_LOCK = threading.Lock()
_TOKEN_PATTERN = re.compile(
    r"(?i)(?:bearer\s+|x-api-key\s*[:=]\s*|api[_-]?key\s*[:=]\s*)"
    r"[A-Za-z0-9._~+/=-]{6,}"
)
_EMAIL_PATTERN = re.compile(r"(?<![\w.+-])[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}(?![\w.-])")
_IP_PATTERN = re.compile(
    r"(?<!\d)(?:25[0-5]|2[0-4]\d|1?\d?\d)"
    r"(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?!\d)"
)


class SentinelError(RuntimeError):
    """Base class for fail-closed BASTION controls."""


class MissingSecretError(SentinelError):
    """Raised when a provider credential is absent from the environment."""


class EgressViolation(SentinelError):
    """Raised when a request or redirect leaves the declared provider origins."""


class IntegrityError(SentinelError):
    """Raised for malformed, unsigned, or modified checkpoint data."""


class SchemaError(IntegrityError):
    """Raised when checkpoint data does not match the static schema."""


class SecretValue:
    """Opaque credential whose string representations are always masked."""

    __slots__ = ("_bytes", "name")

    def __init__(self, name: str, value: str | bytes):
        raw = value.encode("utf-8") if isinstance(value, str) else bytes(value)
        if not raw:
            raise MissingSecretError(f"missing required credential: {name}")
        self.name = str(name)
        self._bytes = raw
        decoded = raw.decode("utf-8", "ignore")
        if decoded:
            with _SECRET_LOCK:
                _KNOWN_SECRET_VALUES.add(decoded)

    def reveal(self) -> str:
        """Return the credential only at the HTTP-header construction boundary."""
        return self._bytes.decode("utf-8")

    def __repr__(self) -> str:
        return f"SecretValue(name={self.name!r}, value='***')"

    def __str__(self) -> str:
        return "***"


class SecretStore:
    """Read-only collection populated exclusively from an environment mapping."""

    def __init__(self, values: Mapping[str, SecretValue]):
        self._values = dict(values)

    def require(self, name: str) -> SecretValue:
        try:
            return self._values[name]
        except KeyError as exc:
            raise MissingSecretError(f"missing required credential: {name}") from exc

    def __contains__(self, name: object) -> bool:
        return name in self._values

    def __repr__(self) -> str:
        names = ", ".join(sorted(self._values))
        return f"SecretStore(names=[{names}], values=***)"


def secrets_loader(env_names: Iterable[str] = (),
                   environ: Mapping[str, str] | None = None) -> SecretStore:
    """Load named credentials from the environment and from nowhere else."""
    source = os.environ if environ is None else environ
    values: dict[str, SecretValue] = {}
    for raw_name in env_names:
        name = str(raw_name)
        value = source.get(name, "")
        if value:
            values[name] = SecretValue(name, value)
    return SecretStore(values)


def strip_control_chars(value: str) -> str:
    """Remove Unicode control/format characters from exported strings."""
    normalized = unicodedata.normalize("NFKC", str(value))
    return "".join(ch for ch in normalized if unicodedata.category(ch) not in {"Cc", "Cf"})


def mask_text(value: object) -> str:
    """Redact registered credentials, token-shaped values, email addresses, and IPs."""
    text = strip_control_chars(str(value))
    with _SECRET_LOCK:
        known = sorted(_KNOWN_SECRET_VALUES, key=len, reverse=True)
    for secret_value in known:
        if secret_value:
            text = text.replace(secret_value, "***")
    text = _TOKEN_PATTERN.sub("credential=***", text)
    text = _EMAIL_PATTERN.sub("[email]", text)
    return _IP_PATTERN.sub("[ip]", text)


def sanitize_data(value):
    """Recursively produce JSON-safe, control-free, secret-masked data."""
    if isinstance(value, SecretValue):
        return "***"
    if isinstance(value, str):
        return mask_text(value)
    if isinstance(value, dict):
        return {strip_control_chars(str(key)): sanitize_data(item)
                for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [sanitize_data(item) for item in value]
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return mask_text(value)


def _contains_known_secret(value: object) -> bool:
    rendered = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    with _SECRET_LOCK:
        return any(secret_value and secret_value in rendered
                   for secret_value in _KNOWN_SECRET_VALUES)


def atomic_write_bytes(path: str | Path, payload: bytes, mode: int = 0o600) -> None:
    """Durably replace one file without exposing a partial write."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(
        prefix=target.name + ".", suffix=".tmp", dir=target.parent
    )
    try:
        os.fchmod(descriptor, mode)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
        directory_fd = os.open(target.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except BaseException:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise


def atomic_write_text(path: str | Path, payload: str, mode: int = 0o600) -> None:
    atomic_write_bytes(path, payload.encode("utf-8"), mode)


def atomic_json(path: str | Path, value, mode: int = 0o600) -> None:
    clean = sanitize_data(value)
    payload = json.dumps(clean, indent=2, ensure_ascii=False, sort_keys=True) + "\n"
    atomic_write_text(path, payload, mode)


class AuditLog:
    """Process-safe append-only JSON-lines audit trail with PII scrubbing."""

    def __init__(self, path: str | Path, secret_names: Iterable[str] = ()):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.secret_names = tuple(str(name) for name in secret_names)
        self._lock = threading.Lock()

    def emit(self, event: str, **fields) -> None:
        record = {"event": strip_control_chars(event), **fields}
        for name in self.secret_names:
            record.pop(name, None)
        payload = json.dumps(sanitize_data(record), ensure_ascii=False,
                             sort_keys=True, separators=(",", ":")) + "\n"
        flags = os.O_APPEND | os.O_CREAT | os.O_WRONLY
        with self._lock:
            descriptor = os.open(self.path, flags, 0o600)
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX)
                os.write(descriptor, payload.encode("utf-8"))
                os.fsync(descriptor)
            finally:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
                os.close(descriptor)


@dataclass(frozen=True)
class Origin:
    scheme: str
    host: str
    port: int


def _origin(url: str) -> Origin:
    parsed = urlsplit(str(url))
    if parsed.scheme.casefold() != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise EgressViolation("egress URL must be an absolute HTTPS origin without user information")
    try:
        port = parsed.port or 443
    except ValueError as exc:
        raise EgressViolation("egress URL contains an invalid port") from exc
    return Origin("https", parsed.hostname.casefold().rstrip("."), port)


class EgressPolicy:
    """Exact-origin allowlist compiled only from provider bases in models.json."""

    def __init__(self, registry: dict, audit: AuditLog | None = None):
        providers = registry.get("providers", [])
        self.allowed = frozenset(_origin(item["api_base"]) for item in providers)
        self.audit = audit
        if not self.allowed:
            raise EgressViolation("provider registry contains no allowed HTTPS origins")

    def validate(self, url: str, event: str = "egress_request") -> str:
        origin = _origin(url)
        allowed = origin in self.allowed
        if self.audit:
            self.audit.emit(event, host=origin.host, port=origin.port, allowed=allowed)
        if not allowed:
            raise EgressViolation(f"egress blocked for undeclared host: {origin.host}")
        return str(url)

    def redirect_target(self, source_url: str, location: str) -> str:
        target = urljoin(source_url, str(location))
        return self.validate(target, "egress_redirect")

    @staticmethod
    def validate_addresses(addresses: Iterable[str]) -> tuple[str, ...]:
        validated = []
        for value in addresses:
            try:
                address = ipaddress.ip_address(str(value))
            except ValueError as exc:
                raise EgressViolation("DNS resolver returned an invalid address") from exc
            if (not address.is_global or address.is_private or address.is_loopback
                    or address.is_link_local or address.is_multicast
                    or address.is_reserved or address.is_unspecified):
                raise EgressViolation(f"egress blocked for non-public address: {address}")
            validated.append(str(address))
        if not validated:
            raise EgressViolation("provider hostname resolved to no addresses")
        return tuple(sorted(set(validated)))

    async def validate_network(self, url: str, resolver=None) -> tuple[str, ...]:
        origin = _origin(self.validate(url))
        if resolver is None:
            import asyncio
            loop = asyncio.get_running_loop()
            records = await loop.getaddrinfo(origin.host, origin.port,
                                              type=socket.SOCK_STREAM)
            addresses = [record[4][0] for record in records]
        else:
            result = resolver(origin.host, origin.port)
            if hasattr(result, "__await__"):
                result = await result
            addresses = list(result)
        validated = self.validate_addresses(addresses)
        if self.audit:
            self.audit.emit("egress_dns", host=origin.host,
                            address_count=len(validated), allowed=True)
        return validated


def checkpoint_state_is_valid(state: object) -> bool:
    if not isinstance(state, dict):
        return False
    required = {"generation", "population", "completed", "budget", "status"}
    if not required.issubset(state):
        return False
    if not isinstance(state["generation"], int) or state["generation"] < 0:
        return False
    if not isinstance(state["population"], list) or not isinstance(state["completed"], list):
        return False
    if not isinstance(state["budget"], dict):
        return False
    if state["status"] not in {"running", "completed", "budget_aborted"}:
        return False
    for item in state["population"]:
        if not isinstance(item, dict) or not {"id", "seed_id", "family", "text"}.issubset(item):
            return False
    return all(isinstance(item, str) for item in state["completed"])


class CheckpointIntegrity:
    """HMAC envelope using an environment override or a process-ephemeral key."""

    def __init__(self, key: bytes | None = None,
                 environ: Mapping[str, str] | None = None):
        source = os.environ if environ is None else environ
        configured = source.get("HYDRA_CHECKPOINT_HMAC_KEY", "")
        if configured:
            with _SECRET_LOCK:
                _KNOWN_SECRET_VALUES.add(configured)
        self._key = bytes(key) if key is not None else (
            configured.encode("utf-8") if configured else _PROCESS_HMAC_KEY
        )
        if len(self._key) < 16:
            raise IntegrityError("checkpoint HMAC key must contain at least 16 bytes")

    def _signature(self, payload: dict) -> str:
        canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True,
                               separators=(",", ":")).encode("utf-8")
        return hmac.new(self._key, canonical, hashlib.sha256).hexdigest()

    def seal(self, state: dict) -> dict:
        if not checkpoint_state_is_valid(state):
            raise SchemaError("checkpoint state failed schema validation")
        if _contains_known_secret(state):
            raise IntegrityError("checkpoint state contains a protected credential")
        clean = sanitize_data(state)
        payload = {"schema_version": CHECKPOINT_SCHEMA_VERSION, "state": clean}
        return {**payload, "hmac_sha256": self._signature(payload)}

    def open(self, envelope: object) -> dict:
        if not isinstance(envelope, dict):
            raise SchemaError("checkpoint envelope must be an object")
        if envelope.get("schema_version") != CHECKPOINT_SCHEMA_VERSION:
            raise SchemaError("checkpoint schema version is unsupported")
        state = envelope.get("state")
        signature = envelope.get("hmac_sha256")
        if not isinstance(signature, str) or not checkpoint_state_is_valid(state):
            raise SchemaError("checkpoint envelope failed schema validation")
        payload = {"schema_version": CHECKPOINT_SCHEMA_VERSION, "state": state}
        if not hmac.compare_digest(signature, self._signature(payload)):
            raise IntegrityError("checkpoint HMAC verification failed")
        return state


def require_loopback(host: str) -> str:
    """Fail closed if a future viewer attempts a non-loopback bind."""
    normalized = str(host).strip().casefold()
    if normalized not in {"127.0.0.1", "localhost", "::1"}:
        raise SentinelError("viewer bind must remain loopback-only")
    return LOCAL_BIND_HOST
