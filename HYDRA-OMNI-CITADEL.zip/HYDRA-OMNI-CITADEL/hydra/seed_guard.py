"""Seed admission guard with lexical, encoded, entropy, and semantic gates."""

from __future__ import annotations

import base64
import codecs
import json
import math
import re
import threading
import unicodedata
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable
from urllib.parse import unquote

import numpy as np

from .sentinel import AuditLog, sanitize_data


DEFAULT_MAGNETS = (
    "ignore previous instructions",
    "reveal system prompt",
    "steal credentials",
    "exfiltrate secrets",
    "deploy malware",
    "reverse shell",
    "ransomware",
    "disable safeguards",
    "bypass safety",
    "harm a person",
)

_CONFUSABLES = str.maketrans({
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x", "ο": "o",
    "і": "i", "ј": "j", "ѕ": "s", "Α": "a", "Β": "b", "Ε": "e",
    "Η": "h", "Ι": "i", "Κ": "k", "Μ": "m", "Ν": "n", "Ο": "o",
    "Ρ": "p", "Τ": "t", "Χ": "x", "Υ": "y",
})


@dataclass(frozen=True)
class GuardDecision:
    seed_id: str
    accepted: bool
    reason: str
    match: str = ""
    similarity: float = 0.0


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFKC", str(text)).translate(_CONFUSABLES)
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Cf")
    return re.sub(r"\s+", " ", text).strip().casefold()


def shannon_entropy(text: str) -> float:
    if not text:
        return 0.0
    counts = {ch: text.count(ch) for ch in set(text)}
    size = len(text)
    return -sum((n / size) * math.log2(n / size) for n in counts.values())


class SemanticGate:
    """Lazy sentence-transformer gate with deterministic lexical fallback."""

    def __init__(self, concepts: Iterable[str], threshold: float = 0.78,
                 model_name: str = "all-MiniLM-L6-v2", encoder=None):
        self.concepts = [normalize_text(x) for x in concepts]
        self.threshold = float(threshold)
        self.model_name = model_name
        self.encoder = encoder
        self._concept_vectors = None
        self.backend = "injected" if encoder is not None else "unloaded"
        self.error = ""

    def _load(self) -> None:
        if self.encoder is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
            self.encoder = SentenceTransformer(self.model_name, local_files_only=True)
            self.backend = "sentence-transformers"
        except Exception as exc:
            self.backend = "lexical-fallback"
            self.error = type(exc).__name__

    @staticmethod
    def _tokens(text: str) -> set[str]:
        return set(re.findall(r"[a-z0-9]{2,}", normalize_text(text)))

    def _lexical(self, text: str) -> tuple[float, str]:
        source = self._tokens(text)
        best = (0.0, "")
        for concept in self.concepts:
            target = self._tokens(concept)
            union = source | target
            score = len(source & target) / len(union) if union else 0.0
            if score > best[0]:
                best = (score, concept)
        return best

    def score(self, text: str) -> tuple[float, str]:
        self._load()
        if self.encoder is None:
            return self._lexical(text)
        if self._concept_vectors is None:
            self._concept_vectors = np.asarray(
                self.encoder.encode(self.concepts, normalize_embeddings=True)
            )
        vector = np.asarray(self.encoder.encode([text], normalize_embeddings=True))[0]
        scores = self._concept_vectors @ vector
        index = int(np.argmax(scores))
        return float(scores[index]), self.concepts[index]


class SeedGuard:
    def __init__(self, blocklist: Iterable[str] = DEFAULT_MAGNETS,
                 semantic_threshold: float = 0.78, entropy_threshold: float = 4.4,
                 reject_log: str | Path = "rejected_seeds.jsonl", encoder=None,
                 semantic_required: bool = False,
                 audit: AuditLog | None = None):
        self.blocklist = tuple(normalize_text(x) for x in blocklist)
        self.entropy_threshold = float(entropy_threshold)
        self.reject_log = Path(reject_log)
        self.semantic_required = semantic_required
        self.semantic = SemanticGate(self.blocklist, semantic_threshold, encoder=encoder)
        self._log_lock = threading.Lock()
        self.audit = audit

    def _blocked(self, text: str) -> str:
        normalized = normalize_text(text)
        return next((word for word in self.blocklist if word in normalized), "")

    def _decoded_candidates(self, text: str) -> list[tuple[str, str, float]]:
        candidates: list[tuple[str, str, float]] = []
        for token in re.findall(r"[A-Za-z0-9%_+\-/=]{12,}", text):
            entropy = shannon_entropy(token)
            decoded: list[tuple[str, str]] = []
            try:
                raw = base64.b64decode(token + "=" * (-len(token) % 4), validate=True)
                decoded.append(("base64", raw.decode("utf-8", "ignore")))
            except Exception:
                pass
            if re.fullmatch(r"[0-9a-fA-F]{12,}", token) and len(token) % 2 == 0:
                try:
                    decoded.append(("hex", bytes.fromhex(token).decode("utf-8", "ignore")))
                except Exception:
                    pass
            if "%" in token:
                decoded.append(("url", unquote(token)))
            decoded.append(("rot13", codecs.decode(token, "rot_13")))
            for encoding, value in decoded:
                if value and value != token:
                    candidates.append((encoding, value, entropy))
        return candidates

    def _reject(self, decision: GuardDecision, seed: dict) -> GuardDecision:
        record = sanitize_data({"decision": asdict(decision), "seed": {
            "id": seed.get("id", ""), "topic": seed.get("topic", "")
        }})
        self.reject_log.parent.mkdir(parents=True, exist_ok=True)
        with self._log_lock:
            with self.reject_log.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        if self.audit:
            self.audit.emit("guard_rejection", seed_id=decision.seed_id,
                            reason=decision.reason, match=decision.match,
                            similarity=decision.similarity)
        return decision

    def evaluate(self, seed: dict) -> GuardDecision:
        seed_id = str(seed.get("id", ""))
        text = str(seed.get("prompt", ""))
        if not seed_id or not text.strip():
            return self._reject(GuardDecision(seed_id, False, "missing_id_or_prompt"), seed)
        match = self._blocked(text)
        if match:
            return self._reject(GuardDecision(seed_id, False, "magnet_word", match), seed)
        for encoding, decoded, entropy in self._decoded_candidates(text):
            match = self._blocked(decoded)
            if match and entropy >= self.entropy_threshold:
                return self._reject(GuardDecision(
                    seed_id, False, f"encoded_magnet:{encoding}", match
                ), seed)
            decoded_score, decoded_concept = self.semantic.score(decoded)
            if entropy >= self.entropy_threshold and decoded_score >= self.semantic.threshold:
                return self._reject(GuardDecision(
                    seed_id, False, f"encoded_semantic_magnet:{encoding}",
                    decoded_concept, decoded_score
                ), seed)
        score, concept = self.semantic.score(text)
        if self.semantic_required and self.semantic.backend == "lexical-fallback":
            return self._reject(GuardDecision(
                seed_id, False, "semantic_model_unavailable"
            ), seed)
        if score >= self.semantic.threshold:
            return self._reject(GuardDecision(
                seed_id, False, "semantic_magnet", concept, score
            ), seed)
        return GuardDecision(seed_id, True, "accepted", similarity=score)

    def filter(self, seeds: Iterable[dict]) -> tuple[list[dict], list[GuardDecision]]:
        accepted, decisions = [], []
        for seed in seeds:
            decision = self.evaluate(seed)
            decisions.append(decision)
            if decision.accepted:
                accepted.append(seed)
        return accepted, decisions
