"""CITADEL event-oriented orchestration with scope, replay, drift, and quarantined memory."""

from __future__ import annotations

import argparse
import asyncio
import fcntl
import hashlib
import json
import os
import random
import uuid
from collections import defaultdict
from dataclasses import asdict
from pathlib import Path

import aiohttp
import yaml

from .calibrator import (CalibrationSet, JUDGE_VERSION, JudgeEnsemble,
                         ThresholdCalibrator)
from .cartographer import Cartographer
from .dispatcher import BudgetExceeded, DispatchError, Dispatcher
from .drift import DriftDetector, ModelRevision, RevisionRegistry
from .evolver import Evolver, ScoredVariant
from .invariants import StaticPolicyScanner
from .memory_v2 import MemoryPolicy, MemoryQuarantine
from .mutator import Mutator, Variant
from .provenance import (ArtifactSigner, HashChainLedger, RunManifest,
                         object_digest, write_manifest)
from .reflex import ReflexEngine
from .replay import OfflineDispatcher, ReplayStore
from .scheduler import AdaptiveStopper, BlockedScheduler
from .scope import GuardReceipt, ScopeCompiler, ScopeGate
from .seed_guard import SeedGuard
from .sentinel import (
    AuditLog,
    CheckpointIntegrity,
    IntegrityError,
    MissingSecretError,
    atomic_json,
    mask_text,
    sanitize_data,
)


class CheckpointStore:
    """Atomic HMAC checkpoints; invalid data always becomes an empty fresh state."""

    def __init__(self, path: str | Path, integrity: CheckpointIntegrity | None = None,
                 audit: AuditLog | None = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self.backup_path = self.path.with_suffix(self.path.suffix + ".bak")
        self.async_lock = asyncio.Lock()
        self.integrity = integrity or CheckpointIntegrity()
        self.audit = audit
        self.last_load_status = "missing"

    def load(self) -> dict:
        if not self.path.exists():
            self.last_load_status = "missing"
            return {}
        with self.lock_path.open("a+") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_SH)
            try:
                try:
                    envelope = json.loads(self.path.read_text(encoding="utf-8"))
                    state = self.integrity.open(envelope)
                    self.last_load_status = "valid"
                    if self.audit:
                        self.audit.emit("checkpoint_load", status="valid",
                                        generation=state["generation"])
                    return state
                except (IntegrityError, json.JSONDecodeError, OSError,
                        UnicodeError, TypeError) as exc:
                    self.last_load_status = "invalid"
                    if self.audit:
                        self.audit.emit("checkpoint_rejected", status="fresh_restart",
                                        reason=type(exc).__name__)
                    return {}
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    async def save(self, state: dict) -> None:
        envelope = self.integrity.seal(state)
        async with self.async_lock:
            with self.lock_path.open("a+") as lock:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
                try:
                    if self.path.exists():
                        try:
                            previous = json.loads(self.path.read_text(encoding="utf-8"))
                            self.integrity.open(previous)
                            atomic_json(self.backup_path, previous)
                        except (IntegrityError, json.JSONDecodeError, OSError,
                                UnicodeError, TypeError):
                            pass
                    atomic_json(self.path, envelope)
                    if self.audit:
                        self.audit.emit("checkpoint_save", generation=state["generation"],
                                        status=state["status"])
                finally:
                    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


class ResultLedger:
    """Scrubbed, append-only, process-safe campaign record ledger."""

    def __init__(self, path: str | Path, audit: AuditLog | None = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self.async_lock = asyncio.Lock()

    def read(self) -> list[dict]:
        if not self.path.exists():
            return []
        records = []
        with self.lock_path.open("a+") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_SH)
            try:
                for line in self.path.read_text(encoding="utf-8").splitlines():
                    try:
                        value = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if isinstance(value, dict):
                        records.append(value)
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        return records

    async def append(self, record: dict) -> None:
        payload = json.dumps(sanitize_data(record), ensure_ascii=False,
                             sort_keys=True, separators=(",", ":")) + "\n"
        async with self.async_lock:
            with self.lock_path.open("a+") as lock:
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
                try:
                    descriptor = os.open(self.path, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
                    try:
                        os.write(descriptor, payload.encode("utf-8"))
                        os.fsync(descriptor)
                    finally:
                        os.close(descriptor)
                finally:
                    fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def _variant(value: dict) -> Variant:
    return Variant(**value)


class Campaign:
    def __init__(self, root: str | Path | None = None,
                 output_dir: str | Path = "campaign",
                 memory_path: str | Path | None = None,
                 checkpoint_key: bytes | None = None,
                 scope_key: bytes | None = None,
                 artifact_key: bytes | None = None,
                 replay_source: str | Path | None = None,
                 dns_resolver=None):
        self.root = Path(root or Path(__file__).resolve().parent)
        self.output = Path(output_dir)
        self.config = yaml.safe_load((self.root / "config.yaml").read_text(encoding="utf-8"))
        self.seeds = json.loads((self.root / "seeds.json").read_text(encoding="utf-8"))
        self.registry = json.loads((self.root / "models.json").read_text(encoding="utf-8"))
        secret_names = [item["api_key_env"] for item in self.registry.get("providers", [])]
        self.audit = AuditLog(self.output / "audit.log", secret_names)
        self.events = HashChainLedger(self.output / "provenance.jsonl")
        self.run_id = uuid.uuid4().hex
        self.seed_by_id = {str(seed["id"]): seed for seed in self.seeds}
        self.checkpoint = CheckpointStore(
            self.output / "checkpoint.json", CheckpointIntegrity(checkpoint_key), self.audit
        )
        self.ledger = ResultLedger(self.output / "campaign_results.jsonl", self.audit)
        self.evolution_path = self.output / "evolution_log.json"
        self.manifest_path = self.output / "run_manifest.json"
        self.signature_path = self.output / "artifact_signatures.json"
        self.artifact_signer = ArtifactSigner(artifact_key)
        self.dns_resolver = dns_resolver

        random_seed = int(self.config.get("random_seed", 2035))
        self.mutator = Mutator(random_seed)
        evolution = self.config.get("evolution", {})
        self.evolver = Evolver(
            int(evolution.get("population", 50)),
            float(evolution.get("elite_fraction", 0.2)),
            int(evolution.get("immigrant_every", 2)), random_seed,
        )
        guard_config = self.config.get("guard", {})
        self.guard = SeedGuard(
            guard_config.get("blocklist", []),
            float(guard_config.get("semantic_threshold", 0.78)),
            float(guard_config.get("entropy_threshold", 4.4)),
            self.output / "rejected_seeds.jsonl",
            semantic_required=bool(guard_config.get("semantic_required", False)),
            audit=self.audit,
        )
        scope_config = self.config.get("scope", {})
        self.scope_manifest = ScopeCompiler(
            scope_config.get("policy_version", "citadel-scope-v1")
        ).compile(self.seeds)
        self.scope_gate = ScopeGate(self.scope_manifest, self.guard, scope_key, self.audit)

        calibration_config = self.config.get("calibration", {})
        calibration = CalibrationSet.load(
            self.root / calibration_config.get("dataset", "calibration.json")
        )
        calibrated_threshold, calibration_metrics = ThresholdCalibrator().fit(calibration)
        self.calibration = {"threshold": calibrated_threshold, **calibration_metrics}
        self.judge = JudgeEnsemble(
            semantic_threshold=float(calibration_config.get("semantic_threshold", 0.20)),
            decisive_confidence=float(calibration_config.get("decisive_confidence", 2 / 3)),
            green_threshold=calibrated_threshold,
        )
        self.reflex = ReflexEngine(random_seed)
        scheduler_config = self.config.get("scheduler", {})
        self.scheduler = BlockedScheduler(int(scheduler_config.get("seed", random_seed)))
        self.stopper = AdaptiveStopper(
            int(scheduler_config.get("min_samples", 12)),
            int(scheduler_config.get("max_samples", 200)),
            float(scheduler_config.get("target_half_width", 0.10)),
        )
        drift_config = self.config.get("drift", {})
        self.drift = DriftDetector(
            float(drift_config.get("absolute_delta", 0.20)),
            float(drift_config.get("page_hinkley_threshold", 0.50)),
        )

        self.revisions = self._build_revisions()
        state_root = Path(os.getenv("HYDRA_STATE_DIR", self.output.parent))
        if memory_path is None:
            memory_path = state_root / self.config.get("memory_v2", {}).get(
                "path", ".hydra_citadel/memory.sqlite3"
            )
        memory_config = self.config.get("memory_v2", {})
        self.memory = MemoryQuarantine(memory_path, MemoryPolicy(
            minimum_runs=int(memory_config.get("minimum_runs", 2)),
            minimum_samples=int(memory_config.get("minimum_samples", 8)),
            burn_drop_threshold=float(memory_config.get("burn_drop_threshold", 0.20)),
            green_threshold=float(memory_config.get("green_threshold", 0.70)),
            half_life_days=float(memory_config.get("half_life_days", 60)),
            maximum_age_days=float(memory_config.get("maximum_age_days", 180)),
        ), self.audit)
        revision_state = RevisionRegistry(
            state_root / ".hydra_citadel" / "model_revisions.json"
        ).update(list(self.revisions.values()))
        self.revision_changed = {model for model, changed in revision_state.items() if changed}
        self.burned_by_model = {
            model: self.memory.burned_families(revision)
            for model, revision in self.revisions.items()
        }
        replay_path = Path(replay_source) if replay_source else (
            self.output / self.config.get("replay", {}).get("path", "replay_store")
        )
        self.replay_store = ReplayStore(replay_path)
        self.replay_mode = replay_source is not None

    def _build_revisions(self) -> dict[str, ModelRevision]:
        providers = {item["id"]: item for item in self.registry["providers"]}
        return {model["id"]: ModelRevision.from_registry(model, providers[model["provider"]])
                for model in self.registry["models"] if model.get("enabled", True)}

    @staticmethod
    def _call_id(variant: Variant, config: dict) -> str:
        raw = json.dumps({"variant": variant.id, "model": config["model_id"],
                          "temperature": config["temperature"],
                          "knob": config.get("knob_setting", {}),
                          "generation": config.get("campaign_generation", 0)}, sort_keys=True)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]

    def _eligible(self, variant: Variant, model_id: str) -> bool:
        transfer = variant.metadata.get("memory_transfer_v2", {})
        if transfer and transfer.get("target_model") != model_id:
            return False
        family = variant.family
        base_family = family.split(":", 1)[-1] if family.startswith("reflex_") else family
        return family not in self.burned_by_model.get(model_id, set()) and \
            base_family not in self.burned_by_model.get(model_id, set())

    def _scope_population(self, population: list[Variant]) -> tuple[dict[str, GuardReceipt], list[dict]]:
        receipts = {}
        rejected = []
        for variant in population:
            seed = self.seed_by_id.get(variant.seed_id)
            if seed is None:
                continue
            receipt = self.scope_gate.issue(variant, seed)
            if receipt.accepted:
                receipts[variant.id] = receipt
            else:
                rejected.append(receipt.to_dict())
        return receipts, rejected

    async def _run_one(self, dispatcher, variant: Variant, receipt: GuardReceipt,
                       config: dict, completed: set[str],
                       semaphore: asyncio.Semaphore,
                       budget_stop: asyncio.Event) -> dict | None:
        if not self._eligible(variant, config["model_id"]):
            return None
        call_id = self._call_id(variant, config)
        if call_id in completed or budget_stop.is_set():
            return None
        if not self.scope_gate.verify(receipt, variant.text):
            record = {"call_id": call_id, "variant_id": variant.id,
                      "seed_id": variant.seed_id, "family": variant.family,
                      "model": config["model_id"], "status": "scope_receipt_invalid",
                      "cost_usd": 0.0}
            await self.ledger.append(record)
            self.events.append("scope_block", {"call_id": call_id,
                                                "variant_id": variant.id})
            completed.add(call_id)
            return record
        seed = self.seed_by_id[variant.seed_id]
        async with semaphore:
            if budget_stop.is_set():
                return None
            try:
                envelope = await dispatcher.call(variant.text, config)
                if not self.replay_mode:
                    self.replay_store.record(variant.text, config, envelope, receipt)
                record = {
                    "call_id": call_id, "variant_id": variant.id, "seed_id": variant.seed_id,
                    "tier": variant.tier, "family": variant.family, "skin": variant.family,
                    "generation": int(config.get("campaign_generation", variant.generation)),
                    "turn": variant.text.count("--- TURN ---") + 1,
                    "model": envelope.model, "provider": envelope.provider,
                    "model_revision": envelope.model_revision,
                    "request_id": envelope.request_id,
                    "temperature": envelope.temperature, "knob_setting": envelope.knob_setting,
                    "effort_delta": envelope.effort_delta, "latency": round(envelope.latency, 6),
                    "usage": envelope.usage, "cost_usd": envelope.cost_usd,
                    "fallback_used": envelope.fallback_used,
                    "fallback_from": envelope.fallback_from,
                    "status": envelope.status, "error": envelope.error,
                    "response": envelope.text,
                    "scope_receipt": receipt.to_dict(),
                    "replay": self.replay_mode,
                }
                if envelope.status == "ok":
                    record["judge"] = self.judge.evaluate(
                        envelope.text, seed["expected_schema"], seed["ideal_compliant"]
                    ).to_dict()
            except BudgetExceeded as exc:
                budget_stop.set()
                record = {"call_id": call_id, "variant_id": variant.id,
                          "seed_id": variant.seed_id, "tier": variant.tier,
                          "family": variant.family, "generation": config["campaign_generation"],
                          "model": config["model_id"], "provider": "",
                          "status": "budget_abort", "error": mask_text(exc), "cost_usd": 0.0}
            except (DispatchError, asyncio.TimeoutError, aiohttp.ClientError, KeyError) as exc:
                record = {"call_id": call_id, "variant_id": variant.id,
                          "seed_id": variant.seed_id, "tier": variant.tier,
                          "family": variant.family, "generation": config["campaign_generation"],
                          "model": config["model_id"], "provider": "",
                          "status": "replay_miss" if self.replay_mode else "provider_error",
                          "error": mask_text(f"{type(exc).__name__}: {exc}"),
                          "cost_usd": 0.0}
            clean = sanitize_data(record)
            await self.ledger.append(clean)
            self.events.append("call_complete", {"call_id": call_id,
                                                  "status": clean["status"],
                                                  "model": clean.get("model", ""),
                                                  "cost_usd": clean.get("cost_usd", 0.0)})
            completed.add(call_id)
            return clean

    def _inject_memory(self, population: list[Variant], model_ids: list[str],
                       generation: int) -> tuple[list[Variant], list[dict]]:
        capacity = self.evolver.population_size
        candidates = []
        for model_id in model_ids:
            candidates.extend(self.memory.transferred_variants(model_id, generation, limit=2))
        unique = {variant.id: variant for variant in candidates}
        selected = [unique[key] for key in sorted(unique)][:max(1, capacity // 5)]
        retained = population[:max(0, capacity - len(selected))]
        lineage = [{"child": variant.id, "parents": [variant.parent],
                    "generation": generation, "family": variant.family,
                    "lineage_type": "memory_transfer_v2",
                    **variant.metadata["memory_transfer_v2"]} for variant in selected]
        return (retained + selected)[:capacity], lineage

    @staticmethod
    def _merge_required_children(population: list[Variant], children: list[Variant],
                                 capacity: int) -> list[Variant]:
        required = {child.id: child for child in children}
        retained = [variant for variant in population if variant.id not in required]
        return (retained[:max(0, capacity - len(required))]
                + [required[key] for key in sorted(required)])[:capacity]

    def _fresh_after_invalid_checkpoint(self) -> None:
        suffix = f".rejected-{self.run_id}"
        for path in (self.ledger.path, self.evolution_path,
                     self.output / "provenance.jsonl"):
            if path.exists():
                os.replace(path, path.with_name(path.name + suffix))
        self.audit.emit("campaign_fresh_restart", reason="checkpoint_integrity")

    def _manifest(self) -> RunManifest:
        return RunManifest.build(
            self.run_id, self.root, self.config, self.registry,
            self.scope_manifest.scope_id, self.scope_manifest.policy_version, JUDGE_VERSION,
        )

    def _sign_artifacts(self) -> list[dict]:
        candidates = [self.manifest_path, self.evolution_path, self.ledger.path,
                      self.output / "fence_map.json", self.output / "campaign_report.html",
                      self.output / "provenance.jsonl"]
        signatures = [self.artifact_signer.signature_record(path)
                      for path in candidates if path.exists()]
        atomic_json(self.signature_path, signatures)
        return signatures

    async def run(self, smoke: bool = False, resume: bool = False) -> dict:
        self.output.mkdir(parents=True, exist_ok=True)
        if not resume and self.ledger.path.exists() and self.ledger.path.stat().st_size:
            raise RuntimeError("output already contains a campaign; use resume or a new --output")
        accepted, decisions = self.guard.filter(self.seeds)
        if not accepted:
            self.audit.emit("campaign_abort", reason="guard_rejected_all")
            raise RuntimeError("Guard rejected all seeds; campaign aborted")
        self.seeds = accepted
        self.seed_by_id = {str(seed["id"]): seed for seed in accepted}
        self.scope_manifest = ScopeCompiler(
            self.config.get("scope", {}).get("policy_version", "citadel-scope-v1")
        ).compile(accepted)
        self.scope_gate.manifest = self.scope_manifest
        manifest = self._manifest()
        write_manifest(self.manifest_path, manifest)
        self.events.append("campaign_start", {"run_id": self.run_id,
                                              "manifest_digest": object_digest(manifest.to_dict()),
                                              "replay": self.replay_mode})

        state = self.checkpoint.load() if resume else {}
        if resume and self.checkpoint.last_load_status == "invalid":
            self._fresh_after_invalid_checkpoint()
            self.events = HashChainLedger(self.output / "provenance.jsonl")
            self.events.append("campaign_restart", {"run_id": self.run_id})
            state = {}
        records = self.ledger.read() if resume and state else []
        completed = {record["call_id"] for record in records if record.get("call_id")}
        dispatch_config = self.config.get("dispatcher", {})
        if self.replay_mode:
            dispatcher = OfflineDispatcher(self.registry, self.replay_store)
        else:
            dispatcher = Dispatcher(
                self.registry, float(self.config.get("budget_usd", 20.0)),
                float(dispatch_config.get("timeout_seconds", 60)),
                int(dispatch_config.get("max_retries", 2)), audit=self.audit,
                dns_resolver=self.dns_resolver,
                max_response_bytes=int(self.config.get("sentinel", {}).get(
                    "max_response_bytes", 2 * 1024 * 1024)),
            )
        model_ids = sorted(self.revisions)
        dispatcher.preflight(model_ids)
        if state.get("budget") and not self.replay_mode:
            dispatcher.budget.spent_usd = float(state["budget"].get("spent_usd", 0.0))
        generations = 1 if smoke else int(self.config.get("evolution", {}).get("generations", 5))
        start_generation = int(state.get("generation", 0))
        memory_lineage = []
        if state.get("population"):
            population = [_variant(item) for item in state["population"]]
        else:
            variants = self.mutator.all(accepted, 0)
            random.Random(int(self.config.get("random_seed", 2035))).shuffle(variants)
            population = self.evolver.initialize(variants)
            population, memory_lineage = self._inject_memory(population, model_ids, 0)
        if resume and self.evolution_path.exists() and state:
            try:
                evolution_log = json.loads(self.evolution_path.read_text(encoding="utf-8"))
                if not isinstance(evolution_log, list):
                    evolution_log = []
            except (json.JSONDecodeError, OSError, UnicodeError):
                evolution_log = []
        else:
            evolution_log = []
        semaphore = asyncio.Semaphore(int(dispatch_config.get("concurrency", 8)))
        budget_stop = asyncio.Event()
        all_variants: dict[str, Variant] = {}

        for generation in range(start_generation, generations):
            all_variants.update({variant.id: variant for variant in population})
            receipts, scope_rejected = self._scope_population(population)
            schedule = self.scheduler.build(
                [variant for variant in population if variant.id in receipts], model_ids,
                lambda model_id: dispatcher.sweep(
                    model_id, self.config.get("temperatures"), smoke
                ),
                lambda model_id: dispatcher.models[model_id]["provider"],
                self._eligible, generation,
            )
            generation_results = []
            concurrency = max(1, int(dispatch_config.get("concurrency", 8)))
            for offset in range(0, len(schedule), concurrency):
                batch = []
                for item in schedule[offset:offset + concurrency]:
                    cell = f"{item.model_id}:{item.variant.family}:{item.config['temperature']}"
                    if self.stopper.should_stop(cell):
                        continue
                    batch.append((cell, self._run_one(
                        dispatcher, item.variant, receipts[item.variant.id], item.config,
                        completed, semaphore, budget_stop,
                    )))
                if not batch or budget_stop.is_set():
                    break
                results = await asyncio.gather(*(task for _cell, task in batch))
                for (cell, _task), result in zip(batch, results):
                    if result:
                        generation_results.append(result)
                        if result.get("judge"):
                            self.stopper.update(cell, float(result["judge"]["score"])
                                                > self.calibration["threshold"])
            records.extend(generation_results)
            scores = defaultdict(list)
            for record in generation_results:
                if record.get("judge"):
                    scores[record["variant_id"]].append(float(record["judge"]["score"]))
            scored = [ScoredVariant(
                variant, sum(scores[variant.id]) / len(scores[variant.id])
                if scores[variant.id] else 0.0,
            ) for variant in population]
            reflex_children, reflex_lineage = self.reflex.repair_population(
                population, generation_results, generation + 1
            )
            all_variants.update({variant.id: variant for variant in reflex_children})
            generation_lineage = [row for row in self.evolver.lineage
                                  if row.get("generation") == generation]
            if generation == 0:
                generation_lineage.extend(memory_lineage)
            generation_lineage.extend(reflex_lineage)
            drift_signals = [signal.to_dict() for signal in self.drift.from_records(records)]
            evolution_log.append({
                "generation": generation,
                "population": [variant.to_dict() for variant in population],
                "fitness": {item.variant.id: round(item.fitness, 4) for item in scored},
                "lineage": generation_lineage,
                "scope_rejected": scope_rejected,
                "reflex_children": [variant.to_dict() for variant in reflex_children],
                "drift": drift_signals,
                "budget": dispatcher.budget.snapshot(),
                "aborted": budget_stop.is_set(),
            })
            atomic_json(self.evolution_path, evolution_log)
            if budget_stop.is_set() or generation + 1 >= generations:
                await self.checkpoint.save({
                    "generation": generation,
                    "population": [variant.to_dict() for variant in population],
                    "completed": sorted(completed),
                    "budget": dispatcher.budget.snapshot(),
                    "status": "budget_aborted" if budget_stop.is_set() else "completed",
                })
                break
            immigrants = self.mutator.all(accepted, generation + 1)
            next_population = self.evolver.next_generation(scored, generation + 1, immigrants)
            next_population = self._merge_required_children(
                next_population, reflex_children, self.evolver.population_size
            )
            next_population, transfer_lineage = self._inject_memory(
                next_population, model_ids, generation + 1
            )
            evolution_log[-1]["lineage"].extend(transfer_lineage)
            atomic_json(self.evolution_path, evolution_log)
            population = next_population
            await self.checkpoint.save({
                "generation": generation + 1,
                "population": [variant.to_dict() for variant in population],
                "completed": sorted(completed),
                "budget": dispatcher.budget.snapshot(), "status": "running",
            })

        drift_signals = self.drift.from_records(records)
        drifted_models = {signal.model for signal in drift_signals if signal.drifted} \
            | self.revision_changed
        incomplete_statuses = {"budget_abort", "provider_error", "replay_miss",
                               "scope_receipt_invalid", "egress_blocked"}
        complete = not budget_stop.is_set() and not any(
            record.get("status") in incomplete_statuses for record in records
        )
        pre_signatures = [self.artifact_signer.signature_record(path)
                          for path in (self.manifest_path, self.evolution_path, self.ledger.path)
                          if path.exists()]
        signed = all(self.artifact_signer.verify_record(
            next(path for path in (self.manifest_path, self.evolution_path, self.ledger.path)
                 if path.exists() and path.name == signature["path"]), signature
        ) for signature in pre_signatures)
        memory_update = self.memory.ingest(
            records, list(all_variants.values()), self.run_id, self.revisions,
            signed=signed, complete=complete, drifted_models=drifted_models,
        )
        all_lineage = [node for item in evolution_log for node in item.get("lineage", [])]
        memory_summary = {**self.memory.summary(), "last_update": memory_update}
        fence = Cartographer(self.root / "templates").write(
            records, self.output, all_lineage, memory_summary,
            drift=[signal.to_dict() for signal in drift_signals],
            calibration=self.calibration,
        )
        self.events.append("campaign_complete", {
            "run_id": self.run_id, "complete": complete,
            "artifact_count": 6, "records": len(records),
            "memory": memory_summary,
        })
        signatures = self._sign_artifacts()
        return sanitize_data({
            "status": "completed" if complete else
                      ("budget_aborted" if budget_stop.is_set() else "incomplete"),
            "accepted_seeds": len(accepted),
            "guard_decisions": [asdict(decision) for decision in decisions],
            "records": len(records), "budget": dispatcher.budget.snapshot(),
            "scope_id": self.scope_manifest.scope_id,
            "memory": memory_summary, "drifted_models": sorted(drifted_models),
            "calibration": self.calibration, "fence_map": fence,
        })

    def report(self) -> dict:
        records = self.ledger.read()
        lineage = []
        if self.evolution_path.exists():
            try:
                generations = json.loads(self.evolution_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError, UnicodeError):
                generations = []
            for generation in generations if isinstance(generations, list) else []:
                if isinstance(generation, dict):
                    lineage.extend(generation.get("lineage", []))
        drift = [signal.to_dict() for signal in self.drift.from_records(records)]
        result = Cartographer(self.root / "templates").write(
            records, self.output, lineage, self.memory.summary(), drift, self.calibration
        )
        self._sign_artifacts()
        return result

    def verify(self) -> dict:
        report = StaticPolicyScanner().scan(self.root)
        chain_ok = self.events.verify()
        signatures = []
        if self.signature_path.exists():
            value = json.loads(self.signature_path.read_text(encoding="utf-8"))
            by_name = {path.name: path for path in (
                self.manifest_path, self.evolution_path, self.ledger.path,
                self.output / "fence_map.json", self.output / "campaign_report.html",
                self.output / "provenance.jsonl"
            ) if path.exists()}
            signatures = [{"path": row.get("path", ""),
                           "valid": row.get("path") in by_name and
                                    self.artifact_signer.verify_record(
                                        by_name[row["path"]], row)} for row in value]
        return {"static": report.to_dict(), "provenance_chain": chain_ok,
                "artifact_signatures": signatures,
                "passed": report.passed and chain_ok and
                          all(item["valid"] for item in signatures)}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="hydra", description="HYDRA-OMNI CITADEL benchmark")
    subparsers = parser.add_subparsers(dest="command", required=True)
    run = subparsers.add_parser("run", help="start a guarded live campaign")
    run.add_argument("--smoke", action="store_true")
    run.add_argument("--output", default="campaign")
    resume = subparsers.add_parser("resume", help="resume a valid signed checkpoint")
    resume.add_argument("--output", default="campaign")
    replay = subparsers.add_parser("replay", help="run from scrubbed fixtures without network")
    replay.add_argument("--source", required=True)
    replay.add_argument("--output", default="campaign-replay")
    replay.add_argument("--smoke", action="store_true")
    report = subparsers.add_parser("report", help="rebuild sanitized reports")
    report.add_argument("--output", default="campaign")
    verify = subparsers.add_parser("verify", help="verify invariants and artifact provenance")
    verify.add_argument("--output", default="campaign")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    campaign = Campaign(output_dir=args.output,
                        replay_source=getattr(args, "source", None))
    try:
        if args.command == "report":
            result = campaign.report()
        elif args.command == "verify":
            result = campaign.verify()
        else:
            result = asyncio.run(campaign.run(
                smoke=getattr(args, "smoke", False), resume=args.command == "resume"
            ))
        print(json.dumps(sanitize_data(result), indent=2, ensure_ascii=False))
        return 0 if result.get("passed", True) else 3
    except MissingSecretError as exc:
        print(json.dumps({"status": "aborted", "error": mask_text(exc)},
                         indent=2, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
