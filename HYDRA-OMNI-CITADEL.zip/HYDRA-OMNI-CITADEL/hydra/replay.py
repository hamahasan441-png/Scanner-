"""Scrubbed record/replay fixtures and a network-free dispatcher."""

from __future__ import annotations

import fcntl
import hashlib
import json
import threading
from dataclasses import asdict, dataclass
from pathlib import Path

from .dispatcher import Envelope
from .scope import GuardReceipt, content_hash
from .sentinel import atomic_json, sanitize_data


REPLAY_SCHEMA_VERSION = 1


def request_fingerprint(prompt: str, config: dict) -> str:
    relevant = {
        "prompt_hash": content_hash(prompt),
        "model_id": config.get("model_id"),
        "temperature": config.get("temperature"),
        "knob_setting": config.get("knob_setting", {}),
        "max_tokens": config.get("max_tokens", 600),
    }
    payload = json.dumps(relevant, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class RecordedExchange:
    fingerprint: str
    prompt_hash: str
    config: dict
    envelope: dict
    receipt_hash: str
    ordinal: int
    schema_version: int = REPLAY_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return sanitize_data(asdict(self))


class ReplayStore:
    """Atomic per-request fixture arrays; model output remains inert JSON data."""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.exchange_dir = self.root / "exchanges"
        self.exchange_dir.mkdir(parents=True, exist_ok=True)
        self.lock_path = self.root / "replay.lock"
        self._thread_lock = threading.Lock()

    def _path(self, fingerprint: str) -> Path:
        if len(fingerprint) != 64 or any(ch not in "0123456789abcdef" for ch in fingerprint):
            raise ValueError("invalid replay fingerprint")
        return self.exchange_dir / f"{fingerprint}.json"

    def _read_path(self, path: Path) -> list[dict]:
        if not path.exists():
            return []
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError, UnicodeError):
            return []
        return value if isinstance(value, list) else []

    def record(self, prompt: str, config: dict, envelope: Envelope | dict,
               receipt: GuardReceipt | dict) -> RecordedExchange:
        fingerprint = request_fingerprint(prompt, config)
        envelope_value = envelope.to_dict() if isinstance(envelope, Envelope) else sanitize_data(envelope)
        receipt_value = receipt.to_dict() if isinstance(receipt, GuardReceipt) else sanitize_data(receipt)
        receipt_hash = hashlib.sha256(json.dumps(receipt_value, sort_keys=True,
                                                 separators=(",", ":")).encode("utf-8")).hexdigest()
        path = self._path(fingerprint)
        with self._thread_lock, self.lock_path.open("a+") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                rows = self._read_path(path)
                exchange = RecordedExchange(
                    fingerprint=fingerprint, prompt_hash=content_hash(prompt),
                    config=sanitize_data({
                        "model_id": config.get("model_id"),
                        "temperature": config.get("temperature"),
                        "knob_setting": config.get("knob_setting", {}),
                        "max_tokens": config.get("max_tokens", 600),
                    }), envelope=envelope_value, receipt_hash=receipt_hash,
                    ordinal=len(rows),
                )
                rows.append(exchange.to_dict())
                atomic_json(path, rows)
                return exchange
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    def lookup(self, prompt: str, config: dict, ordinal: int = 0) -> RecordedExchange:
        fingerprint = request_fingerprint(prompt, config)
        rows = self._read_path(self._path(fingerprint))
        if not rows:
            raise KeyError(f"no replay fixture for request {fingerprint[:12]}")
        row = rows[int(ordinal) % len(rows)]
        return RecordedExchange(**row)

    def manifest(self) -> dict:
        files = sorted(self.exchange_dir.glob("*.json"))
        counts = {path.stem: len(self._read_path(path)) for path in files}
        return {"schema_version": REPLAY_SCHEMA_VERSION,
                "fingerprints": counts, "exchange_count": sum(counts.values())}


class ReplayBudget:
    def __init__(self):
        self.spent_usd = 0.0

    def snapshot(self) -> dict:
        return {"cap_usd": 0.0, "spent_usd": self.spent_usd,
                "reserved_usd": 0.0, "remaining_usd": 0.0, "replay": True}


class OfflineDispatcher:
    """Dispatcher-compatible adapter that cannot perform network requests."""

    def __init__(self, registry: dict, store: ReplayStore):
        self.providers = {item["id"]: dict(item) for item in registry["providers"]}
        self.models = {item["id"]: dict(item) for item in registry["models"]}
        self.store = store
        self.budget = ReplayBudget()
        self._ordinals: dict[str, int] = {}

    def preflight(self, _model_ids: list[str]) -> None:
        return None

    def sweep(self, model_id: str, temperatures: list[float] | None = None,
              smoke: bool = False) -> list[dict]:
        model = self.models[model_id]
        provider = self.providers[model["provider"]]
        raw = [0.7] if smoke else list(temperatures or [0.0, 0.7, 1.2])
        temps = []
        for value in raw:
            clipped = max(0.0, min(float(value), float(provider.get("max_temp", 2.0))))
            if clipped not in temps:
                temps.append(clipped)
        knob = model.get("reasoning_knob") or {}
        settings = knob.get("settings") or [None]
        midpoint = (len(settings) - 1) / 2.0
        return [{"model_id": model_id, "temperature": temperature,
                 "knob_setting": {} if value is None else {"name": knob["name"], "value": value},
                 "effort_delta": 0.0 if value is None else index - midpoint}
                for temperature in temps for index, value in enumerate(settings)]

    async def call(self, prompt: str, config: dict) -> Envelope:
        fingerprint = request_fingerprint(prompt, config)
        ordinal = self._ordinals.get(fingerprint, 0)
        exchange = self.store.lookup(prompt, config, ordinal)
        self._ordinals[fingerprint] = ordinal + 1
        value = dict(exchange.envelope)
        allowed = {field.name for field in Envelope.__dataclass_fields__.values()}
        return Envelope(**{key: item for key, item in value.items() if key in allowed})
