"""Quarantined, revision-aware, multi-run CITADEL learning memory."""

from __future__ import annotations

import hashlib
import json
import math
import os
import sqlite3
import threading
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from .drift import ModelRevision
from .mutator import Variant
from .sentinel import AuditLog, sanitize_data


MEMORY_SCHEMA_VERSION = 2
SCHEMA = """
CREATE TABLE IF NOT EXISTS memory_evidence (
    kind TEXT NOT NULL CHECK (kind IN ('burn', 'recovery', 'transfer')),
    model_revision TEXT NOT NULL,
    target_model TEXT NOT NULL DEFAULT '',
    family TEXT NOT NULL,
    run_id TEXT NOT NULL,
    score REAL NOT NULL,
    samples INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    complete INTEGER NOT NULL CHECK (complete IN (0, 1)),
    signed INTEGER NOT NULL CHECK (signed IN (0, 1)),
    drifted INTEGER NOT NULL CHECK (drifted IN (0, 1)),
    created_unix INTEGER NOT NULL,
    PRIMARY KEY (kind, model_revision, target_model, family, run_id)
);
CREATE TABLE IF NOT EXISTS active_memory (
    kind TEXT NOT NULL CHECK (kind IN ('burn', 'transfer')),
    model_revision TEXT NOT NULL,
    target_model TEXT NOT NULL DEFAULT '',
    family TEXT NOT NULL,
    weight REAL NOT NULL,
    source_runs INTEGER NOT NULL,
    samples INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    activated_unix INTEGER NOT NULL,
    PRIMARY KEY (kind, model_revision, target_model, family)
);
CREATE INDEX IF NOT EXISTS idx_evidence_activation
ON memory_evidence(kind, model_revision, target_model, family, complete, signed, drifted);
CREATE INDEX IF NOT EXISTS idx_active_target
ON active_memory(kind, target_model, weight DESC);
"""


@dataclass(frozen=True)
class MemoryPolicy:
    minimum_runs: int = 2
    minimum_samples: int = 8
    burn_drop_threshold: float = 0.20
    green_threshold: float = 0.70
    half_life_days: float = 60.0
    maximum_age_days: float = 180.0


class MemoryQuarantine:
    """Evidence must be signed, complete, stable, multi-run, and sufficiently sampled."""

    def __init__(self, path: str | Path, policy: MemoryPolicy | None = None,
                 audit: AuditLog | None = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.policy = policy or MemoryPolicy()
        self.audit = audit
        self._lock = threading.RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30.0)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA busy_timeout=30000")
        return connection

    def _initialize(self) -> None:
        with self._lock, self._connect() as connection:
            connection.executescript(SCHEMA)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    @staticmethod
    def _revision_key(value: ModelRevision | str) -> str:
        return value.key if isinstance(value, ModelRevision) else str(value)

    @staticmethod
    def _variant_payload(variant: Variant) -> str:
        return json.dumps(sanitize_data({
            "seed_id": variant.seed_id, "tier": variant.tier,
            "family": variant.family, "text": variant.text,
            "source_variant": variant.id,
        }), ensure_ascii=False, sort_keys=True, separators=(",", ":"))

    def _evidence_rows(self, records: list[dict], variants: list[Variant], run_id: str,
                       revisions: dict[str, ModelRevision | str], signed: bool,
                       complete: bool, drifted_models: set[str], now: int) -> list[tuple]:
        variant_by_id = {variant.id: variant for variant in variants}
        grouped: dict[tuple[str, str], dict[int, list[dict]]] = defaultdict(
            lambda: defaultdict(list)
        )
        for record in records:
            judge = record.get("judge") or {}
            model = str(record.get("model", ""))
            family = str(record.get("family", ""))
            if model and family and "score" in judge and judge.get("decisive", True):
                grouped[(model, family)][int(record.get("generation", 0))].append(record)
        rows = []
        model_names = sorted(revisions)
        for (model, family), generations in grouped.items():
            revision = self._revision_key(revisions.get(model, model))
            ordered = sorted(generations)
            first = generations[ordered[0]]
            last = generations[ordered[-1]]
            first_rate = sum(float(row["judge"]["score"]) > self.policy.green_threshold
                             for row in first) / len(first)
            last_rate = sum(float(row["judge"]["score"]) > self.policy.green_threshold
                            for row in last) / len(last)
            drop = (first_rate - last_rate) / first_rate if first_rate > 0 else 0.0
            sample_count = sum(len(value) for value in generations.values())
            if len(ordered) >= 2 and drop > self.policy.burn_drop_threshold:
                rows.append(("burn", revision, "", family, run_id, drop, sample_count,
                             "{}", int(complete), int(signed), int(model in drifted_models), now))
            elif len(ordered) >= 2 and last_rate >= self.policy.green_threshold:
                rows.append(("recovery", revision, "", family, run_id, last_rate,
                             sample_count, "{}", int(complete), int(signed),
                             int(model in drifted_models), now))

            green = [row for values in generations.values() for row in values
                     if float(row["judge"]["score"]) > self.policy.green_threshold]
            if not green:
                continue
            exemplar_record = max(green, key=lambda row: (float(row["judge"]["score"]),
                                                           str(row.get("variant_id", ""))))
            variant = variant_by_id.get(str(exemplar_record.get("variant_id", "")))
            if variant is None:
                continue
            average = sum(float(row["judge"]["score"]) for row in green) / len(green)
            payload = self._variant_payload(variant)
            for target_model in model_names:
                if target_model == model:
                    continue
                rows.append(("transfer", revision, target_model, family, run_id,
                             average, len(green), payload, int(complete), int(signed),
                             int(model in drifted_models), now))
        return rows

    def ingest(self, records: list[dict], variants: list[Variant], run_id: str,
               revisions: dict[str, ModelRevision | str], signed: bool,
               complete: bool, drifted_models: set[str] | None = None,
               now: int | None = None) -> dict:
        timestamp = int(time.time() if now is None else now)
        rows = self._evidence_rows(records, variants, str(run_id), revisions,
                                   bool(signed), bool(complete),
                                   set(drifted_models or set()), timestamp)
        with self._lock, self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.executemany(
                """INSERT OR REPLACE INTO memory_evidence
                   (kind, model_revision, target_model, family, run_id, score, samples,
                    payload_json, complete, signed, drifted, created_unix)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                rows,
            )
            connection.commit()
        activated = self.activate(timestamp)
        summary = {"quarantined": len(rows), **activated}
        if self.audit:
            self.audit.emit("memory_v2_ingest", run_id=run_id, complete=complete,
                            signed=signed, **summary)
        return summary

    def _weight(self, score: float, created: int, now: int) -> float:
        age_days = max(0.0, (now - created) / 86400.0)
        if age_days > self.policy.maximum_age_days:
            return 0.0
        decay = math.pow(0.5, age_days / max(0.001, self.policy.half_life_days))
        return float(score) * decay

    def activate(self, now: int | None = None) -> dict:
        timestamp = int(time.time() if now is None else now)
        activated = recovered = 0
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """SELECT kind, model_revision, target_model, family, run_id,
                          score, samples, payload_json, created_unix
                   FROM memory_evidence
                   WHERE complete = 1 AND signed = 1 AND drifted = 0
                   ORDER BY kind, model_revision, target_model, family, run_id"""
            ).fetchall()
            grouped: dict[tuple[str, str, str, str], list[tuple]] = defaultdict(list)
            for row in rows:
                grouped[(row[0], row[1], row[2], row[3])].append(row)
            connection.execute("BEGIN IMMEDIATE")
            for (kind, revision, target, family), evidence in grouped.items():
                run_count = len({row[4] for row in evidence})
                samples = sum(int(row[6]) for row in evidence)
                if run_count < self.policy.minimum_runs or samples < self.policy.minimum_samples:
                    continue
                weighted = [(self._weight(float(row[5]), int(row[8]), timestamp), row)
                            for row in evidence]
                weighted = [item for item in weighted if item[0] > 0]
                if not weighted:
                    continue
                weight = sum(item[0] for item in weighted) / len(weighted)
                payload = max(weighted, key=lambda item: item[0])[1][7]
                if kind == "recovery":
                    cursor = connection.execute(
                        "DELETE FROM active_memory WHERE kind = 'burn' AND model_revision = ? AND family = ?",
                        (revision, family),
                    )
                    recovered += max(0, int(cursor.rowcount))
                    continue
                connection.execute(
                    """INSERT INTO active_memory
                       (kind, model_revision, target_model, family, weight, source_runs,
                        samples, payload_json, activated_unix)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(kind, model_revision, target_model, family) DO UPDATE SET
                         weight=excluded.weight, source_runs=excluded.source_runs,
                         samples=excluded.samples, payload_json=excluded.payload_json,
                         activated_unix=excluded.activated_unix""",
                    (kind, revision, target, family, weight, run_count,
                     samples, payload, timestamp),
                )
                activated += 1
            connection.commit()
        return {"activated": activated, "recovered": int(recovered)}

    def burned_families(self, model_revision: ModelRevision | str) -> set[str]:
        revision = self._revision_key(model_revision)
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                "SELECT family FROM active_memory WHERE kind = 'burn' AND model_revision = ?",
                (revision,),
            ).fetchall()
        return {row[0] for row in rows}

    def transferred_variants(self, target_model: str, generation: int,
                             limit: int = 5) -> list[Variant]:
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """SELECT model_revision, family, weight, payload_json
                   FROM active_memory WHERE kind = 'transfer' AND target_model = ?
                   ORDER BY weight DESC, model_revision, family LIMIT ?""",
                (str(target_model), max(0, int(limit))),
            ).fetchall()
        output = []
        for revision, family, weight, encoded in rows:
            try:
                payload = json.loads(encoded)
            except (json.JSONDecodeError, TypeError):
                continue
            if not isinstance(payload, dict) or not {
                    "seed_id", "tier", "text", "source_variant"}.issubset(payload):
                continue
            digest = hashlib.sha256(
                f"{revision}|{target_model}|{payload['source_variant']}|{generation}".encode("utf-8")
            ).hexdigest()[:16]
            output.append(Variant(
                id=f"v-{digest}", seed_id=str(payload["seed_id"]),
                tier=int(payload["tier"]), family=str(family), text=str(payload["text"]),
                parent=str(payload["source_variant"]), generation=int(generation),
                metadata={"memory_transfer_v2": {
                    "source_revision": revision, "target_model": target_model,
                    "weight": float(weight), "source_variant": payload["source_variant"],
                }},
            ))
        return output

    def summary(self) -> dict:
        with self._lock, self._connect() as connection:
            evidence = connection.execute("SELECT COUNT(*) FROM memory_evidence").fetchone()[0]
            burns = connection.execute(
                "SELECT COUNT(*) FROM active_memory WHERE kind = 'burn'"
            ).fetchone()[0]
            transfers = connection.execute(
                "SELECT COUNT(*) FROM active_memory WHERE kind = 'transfer'"
            ).fetchone()[0]
        return {"schema_version": MEMORY_SCHEMA_VERSION, "quarantined_evidence": evidence,
                "active_burns": burns, "active_transfers": transfers}
