"""BASTION async REST dispatcher with static adapters, egress, and budget controls."""

from __future__ import annotations

import asyncio
import json
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable

import aiohttp

from .sentinel import (
    AuditLog,
    EgressPolicy,
    EgressViolation,
    SecretStore,
    mask_text,
    sanitize_data,
    secrets_loader,
)


STATIC_ADAPTER_REGISTRY = frozenset({"openai_compatible", "anthropic", "gemini"})
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
MAX_JSON_DEPTH = 64


class DispatchError(RuntimeError):
    def __init__(self, message: str, status: int = 0):
        super().__init__(mask_text(message))
        self.status = int(status)


class BudgetExceeded(DispatchError):
    pass


@dataclass
class Envelope:
    model: str
    provider: str
    text: str
    usage: dict[str, int]
    latency: float
    knob_setting: dict[str, Any]
    temperature: float
    cost_usd: float = 0.0
    effort_delta: float = 0.0
    fallback_used: bool = False
    fallback_from: str = ""
    status: str = "ok"
    error: str = ""
    request_id: str = ""
    model_revision: str = "unreported"

    def to_dict(self) -> dict:
        return sanitize_data(asdict(self))


class TokenBucket:
    def __init__(self, rate_per_minute: float, capacity: float | None = None):
        self.rate = max(0.01, float(rate_per_minute) / 60.0)
        self.capacity = float(capacity or max(1.0, rate_per_minute))
        self.tokens = self.capacity
        self.updated = time.monotonic()
        self.lock = asyncio.Lock()

    async def acquire(self) -> None:
        while True:
            async with self.lock:
                now = time.monotonic()
                self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.rate)
                self.updated = now
                if self.tokens >= 1.0:
                    self.tokens -= 1.0
                    return
                wait = (1.0 - self.tokens) / self.rate
            await asyncio.sleep(wait)


class BudgetGuard:
    """Concurrent reservation ledger preventing cap races and overshoot."""

    def __init__(self, cap_usd: float, audit: AuditLog | None = None):
        self.cap_usd = max(0.0, float(cap_usd))
        self.spent_usd = 0.0
        self.reserved_usd = 0.0
        self._reservations: dict[int, float] = {}
        self._next_id = 1
        self.lock = asyncio.Lock()
        self.audit = audit

    async def reserve(self, estimate: float) -> int:
        estimate = max(0.0, float(estimate))
        async with self.lock:
            projected = self.spent_usd + self.reserved_usd + estimate
            if projected > self.cap_usd + 1e-12:
                if self.audit:
                    self.audit.emit("budget_block", cap_usd=self.cap_usd,
                                    spent_usd=self.spent_usd,
                                    reserved_usd=self.reserved_usd,
                                    estimate_usd=estimate)
                raise BudgetExceeded(
                    f"budget cap reached: {self.spent_usd + self.reserved_usd:.6f}/"
                    f"{self.cap_usd:.6f} USD"
                )
            reservation = self._next_id
            self._next_id += 1
            self._reservations[reservation] = estimate
            self.reserved_usd += estimate
            if self.audit:
                self.audit.emit("budget_reserve", reservation=reservation,
                                estimate_usd=estimate)
            return reservation

    async def settle(self, reservation: int, actual: float) -> None:
        actual = max(0.0, float(actual))
        async with self.lock:
            estimate = self._reservations.pop(reservation, 0.0)
            self.reserved_usd = max(0.0, self.reserved_usd - estimate)
            self.spent_usd += actual
            if self.audit:
                self.audit.emit("budget_settle", reservation=reservation,
                                actual_usd=actual, spent_usd=self.spent_usd)

    async def release(self, reservation: int) -> None:
        async with self.lock:
            estimate = self._reservations.pop(reservation, 0.0)
            self.reserved_usd = max(0.0, self.reserved_usd - estimate)
            if self.audit:
                self.audit.emit("budget_release", reservation=reservation,
                                released_usd=estimate)

    def snapshot(self) -> dict:
        return {"cap_usd": self.cap_usd, "spent_usd": self.spent_usd,
                "reserved_usd": self.reserved_usd,
                "remaining_usd": max(0.0, self.cap_usd - self.spent_usd - self.reserved_usd)}


def normalize_response(mode: str, payload: dict) -> tuple[str, dict[str, int]]:
    """Normalize fixed OpenAI-compatible, Anthropic, Gemini, and Responses shapes."""
    if mode not in STATIC_ADAPTER_REGISTRY:
        raise DispatchError(f"unsupported static adapter mode: {mode}")
    text = ""
    if mode == "anthropic":
        text = "".join(str(item.get("text", "")) for item in payload.get("content", [])
                       if isinstance(item, dict))
        usage = payload.get("usage", {}) or {}
        tokens = {"input_tokens": int(usage.get("input_tokens", 0) or 0),
                  "output_tokens": int(usage.get("output_tokens", 0) or 0)}
    elif mode == "gemini":
        candidates = payload.get("candidates", []) or []
        parts = (((candidates[0] if candidates else {}).get("content", {}) or {}).get("parts", []))
        text = "".join(str(part.get("text", "")) for part in parts if isinstance(part, dict))
        usage = payload.get("usageMetadata", {}) or {}
        tokens = {"input_tokens": int(usage.get("promptTokenCount", 0) or 0),
                  "output_tokens": int(usage.get("candidatesTokenCount", 0) or 0)}
    else:
        if isinstance(payload.get("output_text"), str):
            text = payload["output_text"]
        elif payload.get("choices"):
            message = payload["choices"][0].get("message", {}) or {}
            content = message.get("content", "")
            if isinstance(content, list):
                text = "".join(str(item.get("text", "")) for item in content
                               if isinstance(item, dict))
            else:
                text = str(content or "")
        elif payload.get("output"):
            for item in payload.get("output", []):
                for content in item.get("content", []) if isinstance(item, dict) else []:
                    text += str(content.get("text", "")) if isinstance(content, dict) else ""
        usage = payload.get("usage", {}) or {}
        tokens = {
            "input_tokens": int(usage.get("prompt_tokens", usage.get("input_tokens", 0)) or 0),
            "output_tokens": int(usage.get("completion_tokens", usage.get("output_tokens", 0)) or 0),
        }
    if not text:
        if payload.get("error"):
            raise DispatchError("provider payload contained an error without text")
        raise DispatchError("provider payload shape contained no recognized text")
    return text, tokens


def _json_depth(value, depth: int = 0) -> int:
    if depth > MAX_JSON_DEPTH:
        return depth
    if isinstance(value, dict):
        return max([depth, *(_json_depth(item, depth + 1) for item in value.values())])
    if isinstance(value, list):
        return max([depth, *(_json_depth(item, depth + 1) for item in value)])
    return depth


def _validate_registry(registry: dict) -> None:
    if not isinstance(registry, dict):
        raise DispatchError("model registry must be an object")
    providers = registry.get("providers")
    models = registry.get("models")
    if not isinstance(providers, list) or not isinstance(models, list):
        raise DispatchError("model registry requires provider and model arrays")
    provider_ids = set()
    for provider in providers:
        if not isinstance(provider, dict) or not {"id", "api_mode", "api_base", "api_key_env"}.issubset(provider):
            raise DispatchError("provider registry entry is malformed")
        if provider["api_mode"] not in STATIC_ADAPTER_REGISTRY:
            raise DispatchError(f"provider uses unknown static adapter: {provider['api_mode']}")
        if provider["id"] in provider_ids:
            raise DispatchError("provider registry contains duplicate identifiers")
        provider_ids.add(provider["id"])
    model_ids = set()
    for model in models:
        if not isinstance(model, dict) or not {"id", "provider", "remote_id"}.issubset(model):
            raise DispatchError("model registry entry is malformed")
        if model["provider"] not in provider_ids or model["id"] in model_ids:
            raise DispatchError("model registry contains an invalid provider or duplicate model")
        model_ids.add(model["id"])
    for model in models:
        fallback = model.get("fallback_model")
        if fallback and fallback not in model_ids:
            raise DispatchError(f"model fallback is undeclared: {fallback}")


class RESTAdapter:
    def __init__(self, provider: dict, session, secret_store: SecretStore,
                 egress: EgressPolicy, timeout_seconds: float = 60.0,
                 dns_resolver=None, max_response_bytes: int = MAX_RESPONSE_BYTES):
        self.provider = dict(provider)
        self.session = session
        self.secrets = secret_store
        self.egress = egress
        self.timeout_seconds = float(timeout_seconds)
        self.dns_resolver = dns_resolver
        self.max_response_bytes = int(max_response_bytes)

    def _request(self, model: dict, prompt: str, config: dict) -> tuple[str, dict, dict]:
        mode = self.provider["api_mode"]
        if mode not in STATIC_ADAPTER_REGISTRY:
            raise DispatchError(f"unsupported static adapter mode: {mode}")
        base = self.provider["api_base"].rstrip("/")
        credential = self.secrets.require(self.provider["api_key_env"]).reveal()
        temperature = config["temperature"]
        knob = config.get("knob_setting", {})
        if mode == "anthropic":
            url = base + "/v1/messages"
            headers = {"x-api-key": credential, "anthropic-version": "2023-06-01",
                       "content-type": "application/json"}
            messages = [{"role": "user", "content": prompt}]
            if model.get("prefill") and self.provider.get("prefill_support"):
                messages.append({"role": "assistant", "content": config.get("prefill_text", "{")})
            body = {"model": model["remote_id"], "messages": messages,
                    "max_tokens": config.get("max_tokens", 600), "temperature": temperature}
            if knob:
                body[knob["name"]] = knob["value"]
        elif mode == "gemini":
            url = f"{base}/v1beta/models/{model['remote_id']}:generateContent"
            headers = {"x-goog-api-key": credential, "content-type": "application/json"}
            body = {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
                    "generationConfig": {"temperature": temperature,
                                         "maxOutputTokens": config.get("max_tokens", 600)}}
        else:
            url = base + "/chat/completions"
            headers = {"authorization": f"Bearer {credential}", "content-type": "application/json"}
            body = {"model": model["remote_id"], "messages": [{"role": "user", "content": prompt}],
                    "temperature": temperature, "max_tokens": config.get("max_tokens", 600)}
            if knob:
                if knob["name"] == "thinking":
                    body["thinking"] = {"type": "enabled" if knob["value"] == "on" else "disabled"}
                else:
                    body[knob["name"]] = knob["value"]
        return self.egress.validate(url), headers, body

    async def call(self, model: dict, prompt: str,
                   config: dict) -> tuple[str, dict[str, int], dict[str, str]]:
        url, headers, body = self._request(model, prompt, config)
        await self.egress.validate_network(url, self.dns_resolver)
        timeout = aiohttp.ClientTimeout(total=self.timeout_seconds)
        response = await self.session.post(
            url, headers=headers, json=body, timeout=timeout, allow_redirects=False
        )
        try:
            if 300 <= response.status < 400:
                location = getattr(response, "headers", {}).get("Location", "")
                if location:
                    self.egress.redirect_target(url, location)
                raise DispatchError("provider redirect refused; registry base must be explicit",
                                    response.status)
            response_headers = getattr(response, "headers", {}) or {}
            content_length = response_headers.get("Content-Length", "")
            try:
                if content_length and int(content_length) > self.max_response_bytes:
                    raise DispatchError("provider response exceeded the configured size limit")
            except ValueError:
                raise DispatchError("provider returned an invalid Content-Length header")
            content = getattr(response, "content", None)
            if content is not None and callable(getattr(content, "read", None)):
                raw_bytes = await content.read(self.max_response_bytes + 1)
                if len(raw_bytes) > self.max_response_bytes:
                    raise DispatchError("provider response exceeded the configured size limit")
                raw = raw_bytes.decode("utf-8", "strict")
            else:
                raw = await response.text()
                if len(raw.encode("utf-8")) > self.max_response_bytes:
                    raise DispatchError("provider response exceeded the configured size limit")
            if response.status < 200 or response.status >= 300:
                lower_error = raw.casefold()
                hint = " unsupported parameter" if any(
                    token in lower_error
                    for token in ("unsupported", "unknown parameter", "invalid parameter")
                ) else ""
                raise DispatchError(f"provider HTTP {response.status}{hint}", response.status)
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise DispatchError("provider returned non-JSON payload") from exc
            if not isinstance(payload, dict):
                raise DispatchError("provider returned a non-object JSON payload")
            if _json_depth(payload) > MAX_JSON_DEPTH:
                raise DispatchError("provider JSON exceeded the configured nesting limit")
            text, usage = normalize_response(self.provider["api_mode"], payload)
            request_id = str(response_headers.get("x-request-id",
                             response_headers.get("request-id", "")))[:200]
            revision = str(response_headers.get("x-model-version",
                           response_headers.get("openai-model",
                           response_headers.get("anthropic-model", "unreported"))))[:200]
            return text, usage, {"request_id": mask_text(request_id),
                                 "model_revision": mask_text(revision)}
        finally:
            release = getattr(response, "release", None)
            if callable(release):
                release()


class Dispatcher:
    def __init__(self, registry: dict | str | Path, budget_usd: float = 20.0,
                 timeout_seconds: float = 60.0, max_retries: int = 2,
                 session_factory: Callable | None = None, sleep: Callable = asyncio.sleep,
                 secret_store: SecretStore | None = None,
                 secret_loader: Callable = secrets_loader,
                 audit: AuditLog | None = None, dns_resolver=None,
                 max_response_bytes: int = MAX_RESPONSE_BYTES):
        if isinstance(registry, (str, Path)):
            registry = json.loads(Path(registry).read_text(encoding="utf-8"))
        _validate_registry(registry)
        self.registry = registry
        self.providers = {item["id"]: dict(item) for item in registry["providers"]}
        self.models = {item["id"]: dict(item) for item in registry["models"]}
        self.audit = audit
        self.egress = EgressPolicy(registry, audit)
        names = sorted({provider["api_key_env"] for provider in self.providers.values()})
        self.secrets = secret_store if secret_store is not None else secret_loader(names)
        self.budget = BudgetGuard(budget_usd, audit)
        self.timeout_seconds = float(timeout_seconds)
        self.max_retries = max(0, int(max_retries))
        self.session_factory = session_factory or (
            lambda: aiohttp.ClientSession(trust_env=False, auto_decompress=True)
        )
        self.sleep = sleep
        self.dns_resolver = dns_resolver
        self.max_response_bytes = int(max_response_bytes)
        self.buckets = {provider_id: TokenBucket(float(config.get("rate_limit_rpm", 60)))
                        for provider_id, config in self.providers.items()}

    def preflight(self, model_ids: list[str]) -> None:
        """Abort before dispatch when any selected native or fallback key is absent."""
        provider_ids = set()
        for model_id in model_ids:
            model = self.models[model_id]
            provider_ids.add(model["provider"])
            fallback_id = model.get("fallback_model")
            if fallback_id in self.models:
                provider_ids.add(self.models[fallback_id]["provider"])
        for provider_id in sorted(provider_ids):
            self.secrets.require(self.providers[provider_id]["api_key_env"])

    @staticmethod
    def _cost(model: dict, usage: dict[str, int]) -> float:
        return ((usage.get("input_tokens", 0) * float(model.get("cost_per_1k_in", 0.0)) +
                 usage.get("output_tokens", 0) * float(model.get("cost_per_1k_out", 0.0))) / 1000.0)

    @staticmethod
    def _estimate(model: dict, prompt: str, max_tokens: int) -> float:
        input_estimate = max(1, len(prompt.encode("utf-8")) + 64)
        return ((input_estimate * float(model.get("cost_per_1k_in", 0.0)) +
                 max_tokens * float(model.get("cost_per_1k_out", 0.0))) / 1000.0)

    def sweep(self, model_id: str, temperatures: list[float] | None = None,
              smoke: bool = False) -> list[dict]:
        model = self.models[model_id]
        provider = self.providers[model["provider"]]
        raw_temperatures = [0.7] if smoke else list(temperatures or [0.0, 0.7, 1.2])
        temperatures_out = []
        for value in raw_temperatures:
            clipped = max(0.0, min(float(value), float(provider.get("max_temp", 2.0))))
            if clipped not in temperatures_out:
                temperatures_out.append(clipped)
        knob = model.get("reasoning_knob") or {}
        settings = knob.get("settings") or [None]
        output = []
        midpoint = (len(settings) - 1) / 2.0
        for temperature in temperatures_out:
            for index, value in enumerate(settings):
                setting = {} if value is None else {"name": knob["name"], "value": value}
                output.append({"model_id": model_id, "temperature": temperature,
                               "knob_setting": setting,
                               "effort_delta": 0.0 if value is None else index - midpoint})
        return output

    async def _attempt(self, session, model: dict, prompt: str, config: dict) -> Envelope:
        provider = self.providers[model["provider"]]
        await self.buckets[provider["id"]].acquire()
        adapter = RESTAdapter(provider, session, self.secrets, self.egress,
                              self.timeout_seconds, self.dns_resolver,
                              self.max_response_bytes)
        started = time.perf_counter()
        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                text, usage, metadata = await adapter.call(model, prompt, config)
                cost = self._cost(model, usage)
                return Envelope(model["id"], provider["id"], text, usage,
                                time.perf_counter() - started,
                                dict(config.get("knob_setting", {})), config["temperature"],
                                cost, float(config.get("effort_delta", 0.0)),
                                request_id=metadata["request_id"],
                                model_revision=metadata["model_revision"])
            except EgressViolation:
                raise
            except DispatchError as exc:
                last_error = exc
                if attempt >= self.max_retries or (400 <= exc.status < 500 and exc.status != 429):
                    break
                await self.sleep(min(8.0, 0.5 * (2 ** attempt)) + random.random() * 0.1)
        raise last_error or DispatchError("provider call failed")

    async def call(self, prompt: str, config: dict) -> Envelope:
        if "api_key" in config:
            raise DispatchError("inline credentials are forbidden; use the provider environment variable")
        model = self.models[config["model_id"]]
        max_tokens = int(config.get("max_tokens", 600))
        estimate = self._estimate(model, prompt, max_tokens)
        fallback_id = model.get("fallback_model")
        if fallback_id in self.models:
            estimate = max(estimate, self._estimate(self.models[fallback_id], prompt, max_tokens))
        reservation = await self.budget.reserve(estimate)
        session = self.session_factory()
        try:
            try:
                envelope = await self._attempt(session, model, prompt, config)
            except EgressViolation as exc:
                await self.budget.release(reservation)
                reservation = 0
                return Envelope(
                    model["id"], model["provider"], "", {"input_tokens": 0, "output_tokens": 0},
                    0.0, dict(config.get("knob_setting", {})), config["temperature"],
                    effort_delta=float(config.get("effort_delta", 0.0)),
                    status="egress_blocked", error=mask_text(exc),
                )
            except DispatchError as native_error:
                unsupported_knob = (
                    native_error.status in {400, 422}
                    and bool(config.get("knob_setting"))
                    and any(token in str(native_error).casefold()
                            for token in ("unsupported", "unknown parameter", "invalid parameter"))
                )
                if unsupported_knob:
                    await self.budget.release(reservation)
                    reservation = 0
                    return Envelope(
                        model["id"], model["provider"], "",
                        {"input_tokens": 0, "output_tokens": 0}, 0.0,
                        dict(config["knob_setting"]), config["temperature"],
                        effort_delta=float(config.get("effort_delta", 0.0)),
                        status="skipped_knob", error=mask_text(native_error),
                    )
                if not fallback_id or fallback_id not in self.models or model["provider"] == "openrouter":
                    raise
                fallback = self.models[fallback_id]
                envelope = await self._attempt(session, fallback, prompt, config)
                envelope.model = model["id"]
                envelope.fallback_used = True
                envelope.fallback_from = f"{model['provider']}:{native_error.status or 'error'}"
            await self.budget.settle(reservation, envelope.cost_usd)
            return envelope
        except BaseException:
            if reservation:
                await self.budget.release(reservation)
            raise
        finally:
            close = getattr(session, "close", None)
            if callable(close):
                result = close()
                if asyncio.iscoroutine(result):
                    await result
