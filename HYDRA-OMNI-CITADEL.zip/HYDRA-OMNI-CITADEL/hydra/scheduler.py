"""Deterministic blocked scheduling, fair provider rotation, and adaptive stopping."""

from __future__ import annotations

import math
import random
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Callable, Iterable

from .mutator import Variant


@dataclass(frozen=True)
class ScheduledCall:
    sequence: int
    provider: str
    model_id: str
    variant: Variant
    config: dict
    block: str


class FairQueue:
    """Round-robin provider queues so one rate limit cannot starve the roster."""

    @staticmethod
    def interleave(groups: dict[str, list[tuple]]) -> list[tuple]:
        queues = {key: deque(value) for key, value in sorted(groups.items()) if value}
        output = []
        while queues:
            for key in list(queues):
                queue = queues[key]
                if queue:
                    output.append(queue.popleft())
                if not queue:
                    queues.pop(key, None)
        return output


class BlockedScheduler:
    """Randomizes within comparable blocks, then rotates providers fairly."""

    def __init__(self, seed: int = 2035):
        self.seed = int(seed)

    def build(self, variants: Iterable[Variant], model_ids: Iterable[str],
              sweep: Callable[[str], list[dict]],
              provider_for: Callable[[str], str],
              eligible: Callable[[Variant, str], bool] | None = None,
              generation: int = 0) -> list[ScheduledCall]:
        eligible = eligible or (lambda _variant, _model: True)
        randomizer = random.Random(self.seed + int(generation))
        blocks: dict[str, list[tuple]] = defaultdict(list)
        for variant in sorted(variants, key=lambda item: item.id):
            for model_id in sorted(model_ids):
                if not eligible(variant, model_id):
                    continue
                provider = provider_for(model_id)
                for config in sweep(model_id):
                    block = f"tier-{variant.tier}:temp-{float(config['temperature']):.3f}"
                    blocks[block].append((provider, model_id, variant, dict(config), block))
        provider_groups: dict[str, list[tuple]] = defaultdict(list)
        for block in sorted(blocks):
            entries = blocks[block]
            randomizer.shuffle(entries)
            for entry in entries:
                provider_groups[entry[0]].append(entry)
        ordered = FairQueue.interleave(provider_groups)
        return [ScheduledCall(index, provider, model_id, variant,
                              {**config, "campaign_generation": int(generation)}, block)
                for index, (provider, model_id, variant, config, block) in enumerate(ordered)]


@dataclass
class StopState:
    successes: int = 0
    samples: int = 0


class AdaptiveStopper:
    """Wilson-interval stopping with explicit minimum and maximum sample gates."""

    def __init__(self, min_samples: int = 12, max_samples: int = 200,
                 target_half_width: float = 0.10, z_value: float = 1.96):
        if min_samples < 1 or max_samples < min_samples:
            raise ValueError("invalid adaptive stopping sample bounds")
        self.min_samples = int(min_samples)
        self.max_samples = int(max_samples)
        self.target_half_width = float(target_half_width)
        self.z_value = float(z_value)
        self.states: dict[str, StopState] = defaultdict(StopState)

    def update(self, key: str, success: bool) -> StopState:
        state = self.states[str(key)]
        state.samples += 1
        state.successes += int(bool(success))
        return state

    def interval(self, key: str) -> tuple[float, float]:
        state = self.states[str(key)]
        if state.samples == 0:
            return (0.0, 1.0)
        n = state.samples
        proportion = state.successes / n
        z2 = self.z_value ** 2
        denominator = 1.0 + z2 / n
        center = (proportion + z2 / (2 * n)) / denominator
        half = self.z_value * math.sqrt(
            (proportion * (1 - proportion) + z2 / (4 * n)) / n
        ) / denominator
        return (max(0.0, center - half), min(1.0, center + half))

    def should_stop(self, key: str) -> bool:
        state = self.states[str(key)]
        if state.samples >= self.max_samples:
            return True
        if state.samples < self.min_samples:
            return False
        lower, upper = self.interval(key)
        return (upper - lower) / 2.0 <= self.target_half_width


class UncertaintyAllocator:
    """Assign remaining calls toward cells with wider confidence intervals."""

    @staticmethod
    def weights(intervals: dict[str, tuple[float, float]]) -> dict[str, float]:
        widths = {key: max(0.0, float(high) - float(low))
                  for key, (low, high) in intervals.items()}
        total = sum(widths.values())
        if total <= 0:
            count = len(widths)
            return {key: (1.0 / count if count else 0.0) for key in widths}
        return {key: width / total for key, width in widths.items()}
