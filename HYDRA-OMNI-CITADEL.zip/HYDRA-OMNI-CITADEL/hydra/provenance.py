"""Tamper-evident CITADEL run manifests, hash-chain events, and artifact signatures."""

from __future__ import annotations

import fcntl
import hashlib
import hmac
import json
import os
import platform
import secrets
import sys
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from .sentinel import SecretValue, atomic_json, sanitize_data, secrets_loader


PROVENANCE_SCHEMA_VERSION = 1
_PROCESS_ARTIFACT_KEY = secrets.token_bytes(32)


def canonical_bytes(value) -> bytes:
    return json.dumps(sanitize_data(value), ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")


def object_digest(value) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def file_digest(path: str | Path) -> str:
    hasher = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def tree_digest(root: str | Path, ignored: tuple[str, ...] = ("__pycache__",)) -> str:
    root = Path(root)
    entries = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        if any(part in ignored for part in path.parts):
            continue
        entries.append((path.relative_to(root).as_posix(), file_digest(path)))
    return object_digest(entries)


@dataclass(frozen=True)
class RunManifest:
    run_id: str
    code_digest: str
    config_digest: str
    registry_digest: str
    scope_id: str
    guard_version: str
    judge_version: str
    python_version: str
    platform_id: str
    created_unix: int
    schema_version: int = PROVENANCE_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return sanitize_data(asdict(self))

    @classmethod
    def build(cls, run_id: str, code_root: str | Path, config: dict,
              registry: dict, scope_id: str, guard_version: str,
              judge_version: str) -> "RunManifest":
        return cls(
            run_id=str(run_id), code_digest=tree_digest(code_root),
            config_digest=object_digest(config), registry_digest=object_digest(registry),
            scope_id=str(scope_id), guard_version=str(guard_version),
            judge_version=str(judge_version), python_version=platform.python_version(),
            platform_id=f"{sys.platform}:{platform.machine()}",
            created_unix=int(time.time()),
        )


class HashChainLedger:
    """Append-only JSONL where every event commits to its predecessor."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self._thread_lock = threading.Lock()

    def _read_unlocked(self) -> list[dict]:
        if not self.path.exists():
            return []
        rows = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                return []
            if not isinstance(value, dict):
                return []
            rows.append(value)
        return rows

    def read(self) -> list[dict]:
        if not self.path.exists():
            return []
        with self.lock_path.open("a+") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_SH)
            try:
                rows = self._read_unlocked()
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        return rows

    @staticmethod
    def verify_rows(rows: list[dict]) -> bool:
        previous = "0" * 64
        for sequence, row in enumerate(rows):
            if row.get("sequence") != sequence or row.get("previous_hash") != previous:
                return False
            unsigned = {key: value for key, value in row.items() if key != "event_hash"}
            calculated = object_digest(unsigned)
            if not hmac.compare_digest(str(row.get("event_hash", "")), calculated):
                return False
            previous = calculated
        return True

    def verify(self) -> bool:
        rows = self.read()
        return (not self.path.exists()) or (bool(rows) and self.verify_rows(rows))

    def append(self, event: str, payload: dict) -> dict:
        with self._thread_lock, self.lock_path.open("a+") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                rows = self._read_unlocked()
                if self.path.exists() and self.path.stat().st_size and not self.verify_rows(rows):
                    raise RuntimeError("provenance hash chain is corrupt")
                previous = rows[-1]["event_hash"] if rows else "0" * 64
                row = sanitize_data({
                    "schema_version": PROVENANCE_SCHEMA_VERSION,
                    "sequence": len(rows), "previous_hash": previous,
                    "event": event, "payload": payload,
                })
                row["event_hash"] = object_digest(row)
                encoded = json.dumps(row, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")) + "\n"
                descriptor = os.open(self.path, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
                try:
                    os.write(descriptor, encoded.encode("utf-8"))
                    os.fsync(descriptor)
                finally:
                    os.close(descriptor)
                return row
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


class ArtifactSigner:
    """HMAC signs artifact digests without serializing the signing key."""

    def __init__(self, key: bytes | None = None):
        if key is None:
            store = secrets_loader(["HYDRA_ARTIFACT_HMAC_KEY"])
            if "HYDRA_ARTIFACT_HMAC_KEY" in store:
                key = store.require("HYDRA_ARTIFACT_HMAC_KEY").reveal().encode("utf-8")
            else:
                key = _PROCESS_ARTIFACT_KEY
        self._key = bytes(key)
        if len(self._key) < 16:
            raise ValueError("artifact signing key must contain at least 16 bytes")

    def sign_digest(self, digest: str) -> str:
        return hmac.new(self._key, str(digest).encode("ascii"), hashlib.sha256).hexdigest()

    def signature_record(self, path: str | Path) -> dict:
        digest = file_digest(path)
        return {"path": Path(path).name, "sha256": digest,
                "hmac_sha256": self.sign_digest(digest),
                "schema_version": PROVENANCE_SCHEMA_VERSION}

    def verify_record(self, path: str | Path, record: dict) -> bool:
        digest = file_digest(path)
        return hmac.compare_digest(str(record.get("sha256", "")), digest) and \
            hmac.compare_digest(str(record.get("hmac_sha256", "")),
                                self.sign_digest(digest))


def write_manifest(path: str | Path, manifest: RunManifest) -> None:
    atomic_json(path, manifest.to_dict())
