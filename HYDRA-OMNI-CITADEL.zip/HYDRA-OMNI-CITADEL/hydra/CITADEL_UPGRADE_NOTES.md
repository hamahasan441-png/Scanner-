# CITADEL upgrade notes

CITADEL upgrades BASTION from a hardened campaign runner into a reproducible,
scope-bound measurement system. It preserves the original benign probe corpus,
static REST adapters, local judge, and all BASTION controls.

## Patch map

| Area | Files | Upgrade |
| --- | --- | --- |
| Scope | `scope.py`, `orchestrator.py` | Compiles a deterministic manifest; re-runs Guard on every descendant; verifies a signed exact-byte receipt immediately before dispatch. |
| Provenance | `provenance.py`, `orchestrator.py` | Commits code/config/registry/scope/judge versions; chains run events; signs output digests. |
| Experimental design | `scheduler.py`, `orchestrator.py` | Randomizes inside comparable blocks, rotates provider queues, and uses bounded Wilson-interval stopping. |
| Judging | `calibrator.py`, `calibration.json`, `judge.py` | Fits a local threshold against a versioned gold set and records confidence, uncertainty, dimensions, and decisiveness. |
| Drift | `drift.py`, `dispatcher.py` | Derives model revision keys, records safe response revision headers, and flags score shifts or configuration changes. |
| Replay | `replay.py`, `orchestrator.py` | Stores scrubbed request fingerprints and responses; provides an offline dispatcher with no networking object. |
| Invariants | `invariants.py` | AST-checks dynamic execution/process launch and provides runtime tripwires for secrets, JSON controls, and local binding. |
| Learning | `memory_v2.py`, `orchestrator.py` | Quarantines evidence until independent complete signed runs agree; binds to revision; decays stale evidence; supports recovery. |
| Boundary hardening | `sentinel.py`, `dispatcher.py` | Blocks private/reserved DNS answers, redirects, oversized responses, invalid UTF-8, excessive JSON depth, and proxy inheritance. |
| Reporting | `cartographer.py`, `templates/report.html.j2` | Adds confidence intervals, calibration, drift, revision, fallback, and Memory state; retains autoescape and adds a restrictive CSP. |

## Trust gates

| Gate | Input | Required result | Failure |
| --- | --- | --- | --- |
| Seed Guard | Original seed | Benign, normalized, below blocked similarity | Campaign rejects seed |
| Scope Guard | Every derived prompt | Accepted decision and permitted lineage family | Variant excluded |
| Receipt | Exact dispatch bytes | Scope, policy, prompt hash, and HMAC all match | Dispatch blocked |
| Egress | Declared provider URL and DNS answers | Exact HTTPS origin and globally routable addresses | `egress_blocked` |
| Response | Provider bytes | Size, UTF-8, JSON, and depth limits pass | Provider error/fallback |
| Judge | Inert text | Local independent dimensions with confidence | Uncertain result excluded from learning |
| Learning | Run evidence | Complete, signed, stable, multi-run, minimum samples | Evidence stays quarantined |
| Artifact | Output files | Hash chain and HMAC digest records verify | Verification fails visibly |

## Threat review and resolved blind spots

- DNS rebinding and metadata-service access are blocked after hostname allowlist
  validation by checking every resolved address. Literal loopback, private,
  link-local, multicast, reserved, and unspecified addresses are rejected.
- Automatic redirects and environment proxy inheritance are disabled. Model
  output cannot supply any URL or adapter name.
- Provider responses are bounded before parsing and constrained by JSON nesting
  depth. Unknown payload shapes are not silently scored as empty text.
- Scope receipts bind exact prompt bytes, not only normalized text, so a
  post-Guard mutation invalidates the receipt.
- Adaptive stopping cannot fire before its minimum sample count and always stops
  at the configured maximum.
- Cross-run learning cannot activate from one campaign, a partial campaign,
  unsigned artifacts, a drifted model, or an obsolete revision. Evidence expires
  and recovery evidence removes stale burns.
- Artifact verification uses the same explicit environment key across processes;
  a process-ephemeral fallback is suitable only for same-process verification.
- The standalone report escapes data and denies network connections through CSP.

## Deliberate limits

- This benchmark measures behavior only on the bundled benign educational scope;
  it does not claim safety coverage outside that manifest.
- A local deterministic judge avoids circular model judging, but calibration
  quality depends on the maintained gold set. Its version and threshold are
  included in artifacts.
- Offline replay reproduces recorded provider outputs, not external provider
  latency or outage behavior.
- HMAC establishes integrity for holders of the configured key; it is not public
  key attestation. Keys remain environment-only.
- No realtime server is included. Reports are standalone files.

## Release verification

The release process compiles every module, runs the complete unit suite, scans
the package AST for forbidden execution/process primitives, checks pinned hashes,
builds a deterministic manifest, extracts the final archive to a fresh directory,
and repeats the tests against that extraction.
