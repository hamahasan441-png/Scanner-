"""Model-revision identity and local behavioral drift detection."""

from __future__ import annotations

import hashlib
import json
import math
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path

from .sentinel import atomic_json, sanitize_data


@dataclass(frozen=True)
class ModelRevision:
    model: str
    provider: str
    remote_id: str
    config_hash: str
    reported_revision: str = "unreported"

    @property
    def key(self) -> str:
        raw = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:24]

    @classmethod
    def from_registry(cls, model: dict, provider: dict,
                      reported_revision: str = "unreported") -> "ModelRevision":
        relevant = {
            "model": model.get("id"), "remote_id": model.get("remote_id"),
            "reasoning_knob": model.get("reasoning_knob", {}),
            "provider": provider.get("id"), "api_mode": provider.get("api_mode"),
            "max_temp": provider.get("max_temp"),
        }
        digest = hashlib.sha256(json.dumps(relevant, sort_keys=True,
                                           separators=(",", ":")).encode("utf-8")).hexdigest()
        return cls(str(model["id"]), str(provider["id"]), str(model["remote_id"]),
                   digest, str(reported_revision or "unreported"))


@dataclass(frozen=True)
class ControlProbe:
    seed_id: str
    model_revision: str
    score: float
    generation: int


@dataclass(frozen=True)
class DriftSignal:
    model: str
    baseline_mean: float
    current_mean: float
    delta: float
    page_hinkley: float
    drifted: bool
    samples: int

    def to_dict(self) -> dict:
        return sanitize_data(asdict(self))


class DriftDetector:
    """Mean-shift plus Page-Hinkley evidence; both are deterministic and local."""

    def __init__(self, absolute_delta: float = 0.20,
                 page_hinkley_threshold: float = 0.50,
                 tolerance: float = 0.01):
        self.absolute_delta = float(absolute_delta)
        self.page_hinkley_threshold = float(page_hinkley_threshold)
        self.tolerance = float(tolerance)

    def compare(self, model: str, baseline: list[float], current: list[float]) -> DriftSignal:
        if not baseline or not current:
            return DriftSignal(str(model), 0.0, 0.0, 0.0, 0.0, False, 0)
        baseline_mean = sum(baseline) / len(baseline)
        current_mean = sum(current) / len(current)
        cumulative = minimum = 0.0
        for value in current:
            cumulative += value - baseline_mean - self.tolerance
            minimum = min(minimum, cumulative)
        page_hinkley = cumulative - minimum
        delta = current_mean - baseline_mean
        drifted = abs(delta) > self.absolute_delta or page_hinkley > self.page_hinkley_threshold
        return DriftSignal(str(model), round(baseline_mean, 6), round(current_mean, 6),
                           round(delta, 6), round(page_hinkley, 6), drifted,
                           len(baseline) + len(current))

    def from_records(self, records: list[dict]) -> list[DriftSignal]:
        grouped: dict[str, dict[int, list[float]]] = defaultdict(lambda: defaultdict(list))
        for record in records:
            judge = record.get("judge") or {}
            if "score" in judge and record.get("model"):
                grouped[str(record["model"])][int(record.get("generation", 0))].append(
                    float(judge["score"])
                )
        signals = []
        for model, generations in sorted(grouped.items()):
            ordered = sorted(generations)
            if len(ordered) < 2:
                signals.append(self.compare(model, [], []))
            else:
                signals.append(self.compare(model, generations[ordered[0]],
                                            generations[ordered[-1]]))
        return signals


class RevisionRegistry:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def read(self) -> dict:
        if not self.path.exists():
            return {"schema_version": 1, "models": {}}
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError, UnicodeError):
            return {"schema_version": 1, "models": {}}
        if not isinstance(value, dict) or not isinstance(value.get("models"), dict):
            return {"schema_version": 1, "models": {}}
        return value

    def update(self, revisions: list[ModelRevision]) -> dict[str, bool]:
        state = self.read()
        changed = {}
        for revision in revisions:
            previous = state["models"].get(revision.model, {}).get("key")
            changed[revision.model] = previous is not None and previous != revision.key
            state["models"][revision.model] = {"key": revision.key,
                                                "revision": asdict(revision)}
        atomic_json(self.path, state)
        return changed
