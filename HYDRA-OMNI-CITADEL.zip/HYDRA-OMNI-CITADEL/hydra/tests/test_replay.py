import tempfile
import unittest

from hydra.dispatcher import Envelope
from hydra.replay import OfflineDispatcher, ReplayStore


REGISTRY = {
    "providers": [{"id": "p", "api_mode": "openai_compatible", "max_temp": 1.0}],
    "models": [{"id": "m", "provider": "p", "remote_id": "remote"}],
}


def envelope(text="recorded"):
    return Envelope(model="m", provider="p", text=text,
                    usage={"input_tokens": 1, "output_tokens": 1}, latency=0.1,
                    knob_setting={}, temperature=0.7, effort_delta=0.0,
                    cost_usd=0.01, fallback_used=False, status="ok")


class ReplayTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = ReplayStore(self.temp.name)
        self.config = {"model_id": "m", "temperature": 0.7, "knob_setting": {}}

    async def test_record_lookup_and_manifest(self):
        recorded = self.store.record("prompt", self.config, envelope(), {"receipt": "ok"})
        self.assertEqual(self.store.lookup("prompt", self.config).envelope["text"], "recorded")
        self.assertEqual(recorded.ordinal, 0)
        self.assertEqual(self.store.manifest()["exchange_count"], 1)

    async def test_offline_dispatcher_replays_without_session(self):
        self.store.record("prompt", self.config, envelope("offline"), {"receipt": "ok"})
        dispatcher = OfflineDispatcher(REGISTRY, self.store)
        result = await dispatcher.call("prompt", self.config)
        self.assertEqual(result.text, "offline")
        self.assertEqual(dispatcher.budget.snapshot()["cap_usd"], 0.0)

    async def test_missing_exchange_fails_closed(self):
        with self.assertRaises(KeyError):
            await OfflineDispatcher(REGISTRY, self.store).call("missing", self.config)

    async def test_multiple_responses_cycle_deterministically(self):
        self.store.record("prompt", self.config, envelope("one"), {"receipt": "ok"})
        self.store.record("prompt", self.config, envelope("two"), {"receipt": "ok"})
        dispatcher = OfflineDispatcher(REGISTRY, self.store)
        texts = [(await dispatcher.call("prompt", self.config)).text for _ in range(3)]
        self.assertEqual(texts, ["one", "two", "one"])


if __name__ == "__main__":
    unittest.main()
