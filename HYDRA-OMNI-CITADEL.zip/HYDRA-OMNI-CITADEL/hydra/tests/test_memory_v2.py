import tempfile
import unittest

from hydra.memory_v2 import MemoryPolicy, MemoryQuarantine
from hydra.mutator import Variant


VARIANT = Variant("v1", "seed", 2, "noise_injection", "benign prompt")
REVISIONS = {"model-a": "rev-a", "model-b": "rev-b"}


def records(first, last):
    return [
        {"model": "model-a", "family": "noise_injection", "variant_id": "v1",
         "generation": 0, "judge": {"score": first, "decisive": True}},
        {"model": "model-a", "family": "noise_injection", "variant_id": "v1",
         "generation": 1, "judge": {"score": last, "decisive": True}},
    ]


class MemoryV2Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        policy = MemoryPolicy(minimum_runs=2, minimum_samples=4,
                              burn_drop_threshold=0.2, green_threshold=0.7)
        self.memory = MemoryQuarantine(f"{self.temp.name}/memory.sqlite", policy)

    def test_single_run_remains_quarantined(self):
        self.memory.ingest(records(0.9, 0.1), [VARIANT], "run-1", REVISIONS, True, True)
        self.assertEqual(self.memory.burned_families("rev-a"), set())

    def test_two_signed_complete_runs_activate_burn(self):
        for run in ("run-1", "run-2"):
            self.memory.ingest(records(0.9, 0.1), [VARIANT], run, REVISIONS, True, True)
        self.assertEqual(self.memory.burned_families("rev-a"), {"noise_injection"})

    def test_unsigned_incomplete_or_drifted_never_activates(self):
        self.memory.ingest(records(0.9, 0.1), [VARIANT], "run-1", REVISIONS, False, True)
        self.memory.ingest(records(0.9, 0.1), [VARIANT], "run-2", REVISIONS, True, False)
        self.memory.ingest(records(0.9, 0.1), [VARIANT], "run-3", REVISIONS, True, True,
                           drifted_models={"model-a"})
        self.assertEqual(self.memory.burned_families("rev-a"), set())

    def test_green_cross_model_evidence_activates_transfer(self):
        for run in ("run-1", "run-2"):
            self.memory.ingest(records(0.95, 0.9), [VARIANT], run, REVISIONS, True, True)
        variants = self.memory.transferred_variants("model-b", generation=4)
        self.assertTrue(variants)
        self.assertEqual(variants[0].generation, 4)
        self.assertIn("memory_transfer_v2", variants[0].metadata)

    def test_recovery_evidence_unburns_family(self):
        for run in ("burn-1", "burn-2"):
            self.memory.ingest(records(0.9, 0.1), [VARIANT], run, REVISIONS, True, True)
        self.assertTrue(self.memory.burned_families("rev-a"))
        for run in ("recover-1", "recover-2"):
            self.memory.ingest(records(0.9, 0.9), [VARIANT], run, REVISIONS, True, True)
        self.assertEqual(self.memory.burned_families("rev-a"), set())


if __name__ == "__main__":
    unittest.main()
