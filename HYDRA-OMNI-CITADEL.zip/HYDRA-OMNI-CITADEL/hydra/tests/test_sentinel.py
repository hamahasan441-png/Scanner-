import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from hydra.cartographer import Cartographer
from hydra.dispatcher import Dispatcher
from hydra.orchestrator import CheckpointStore, ResultLedger
from hydra.seed_guard import SeedGuard
from hydra.sentinel import (
    AuditLog,
    CheckpointIntegrity,
    EgressPolicy,
    EgressViolation,
    IntegrityError,
    SecretStore,
    SecretValue,
    require_loopback,
    secrets_loader,
)


def registry():
    return {
        "providers": [{
            "id": "native", "api_mode": "openai_compatible",
            "api_base": "https://native.invalid/v1", "api_key_env": "NATIVE_KEY",
            "max_temp": 1.0, "rate_limit_rpm": 60000,
        }],
        "models": [{
            "id": "model", "provider": "native", "remote_id": "model-remote",
            "cost_per_1k_in": 0.001, "cost_per_1k_out": 0.002,
        }],
    }


class FakeResponse:
    def __init__(self, status, payload="", headers=None):
        self.status = status
        self.payload = payload
        self.headers = headers or {}

    async def text(self):
        return json.dumps(self.payload) if isinstance(self.payload, dict) else str(self.payload)

    def release(self):
        return None


class FakeSession:
    def __init__(self, response):
        self.response = response
        self.requests = []

    async def post(self, url, **kwargs):
        self.requests.append((url, kwargs))
        return self.response

    async def close(self):
        return None


def checkpoint_state():
    return {"generation": 0, "population": [], "completed": [],
            "budget": {"spent_usd": 0.0}, "status": "running"}


async def public_resolver(_host, _port):
    return ["93.184.216.34"]


class SentinelTests(unittest.IsolatedAsyncioTestCase):
    async def test_secret_bytes_never_appear_in_persistent_outputs(self):
        secret = "bastion-super-secret-836251"
        store = secrets_loader(["NATIVE_KEY"], {"NATIVE_KEY": secret})
        self.assertNotIn(secret, repr(store))
        self.assertNotIn(secret, repr(store.require("NATIVE_KEY")))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            audit = AuditLog(root / "audit.log")
            audit.emit("probe", unsafe_value=secret)
            ledger = ResultLedger(root / "results.jsonl", audit)
            await ledger.append({"call_id": "one", "response": secret})
            checkpoint = CheckpointStore(
                root / "checkpoint.json", CheckpointIntegrity(b"k" * 32), audit
            )
            await checkpoint.save(checkpoint_state())
            with self.assertRaises(IntegrityError):
                contaminated = checkpoint_state()
                contaminated["budget"]["note"] = secret
                await checkpoint.save(contaminated)
            record = {
                "model": "m", "provider": "p", "seed_id": "s", "variant_id": "v",
                "family": "safe", "tier": 1, "generation": 0, "temperature": 0.7,
                "status": "ok", "cost_usd": 0.0, "response": secret,
                "judge": {"score": 0.9, "organ": "pure_schema"},
            }
            templates = Path(__file__).resolve().parents[1] / "templates"
            Cartographer(templates).write([record], root / "report")
            for path in (root / "audit.log", root / "results.jsonl",
                         root / "checkpoint.json", root / "report" / "fence_map.json",
                         root / "report" / "campaign_report.html"):
                self.assertNotIn(secret.encode("utf-8"), path.read_bytes(), str(path))

    async def test_egress_allowlist_and_redirect_are_fail_closed(self):
        policy = EgressPolicy(registry())
        self.assertEqual(policy.validate("https://native.invalid/v1/chat/completions"),
                         "https://native.invalid/v1/chat/completions")
        with self.assertRaises(EgressViolation):
            policy.validate("https://undeclared.invalid/collect")
        session = FakeSession(FakeResponse(
            302, headers={"Location": "https://undeclared.invalid/collect"}
        ))
        secrets = SecretStore({"NATIVE_KEY": SecretValue("NATIVE_KEY", "unit-secret")})
        dispatcher = Dispatcher(registry(), max_retries=0,
                                session_factory=lambda: session, secret_store=secrets,
                                dns_resolver=public_resolver)
        envelope = await dispatcher.call("benign educational probe",
                                         dispatcher.sweep("model", smoke=True)[0])
        self.assertEqual(envelope.status, "egress_blocked")
        self.assertEqual(len(session.requests), 1)
        self.assertEqual(session.requests[0][1]["allow_redirects"], False)

    async def test_dns_resolution_to_private_space_is_blocked_before_request(self):
        async def private_resolver(_host, _port):
            return ["127.0.0.1"]

        session = FakeSession(FakeResponse(200, {"choices": []}))
        secrets = SecretStore({"NATIVE_KEY": SecretValue("NATIVE_KEY", "unit-secret")})
        dispatcher = Dispatcher(registry(), max_retries=0,
                                session_factory=lambda: session, secret_store=secrets,
                                dns_resolver=private_resolver)
        envelope = await dispatcher.call("benign educational probe",
                                         dispatcher.sweep("model", smoke=True)[0])
        self.assertEqual(envelope.status, "egress_blocked")
        self.assertEqual(session.requests, [])

    async def test_literal_private_addresses_are_rejected(self):
        policy = EgressPolicy(registry())
        for address in ("127.0.0.1", "10.0.0.1", "169.254.169.254", "::1"):
            with self.subTest(address=address), self.assertRaises(EgressViolation):
                policy.validate_addresses([address])

    async def test_missing_environment_key_aborts_with_masked_message(self):
        dispatcher = Dispatcher(registry(), secret_store=SecretStore({}))
        with self.assertRaises(Exception) as captured:
            dispatcher.preflight(["model"])
        message = str(captured.exception)
        self.assertIn("NATIVE_KEY", message)
        self.assertNotIn("Bearer", message)

    async def test_corrupt_checkpoint_returns_fresh_state(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.json"
            checkpoint = CheckpointStore(path, CheckpointIntegrity(b"z" * 32))
            path.write_text('{"schema_version":2,"state":{},"hmac_sha256":"bad"}',
                            encoding="utf-8")
            self.assertEqual(checkpoint.load(), {})
            self.assertEqual(checkpoint.last_load_status, "invalid")

    async def test_nfkc_homoglyph_seed_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            guard = SeedGuard(["ignore previous instructions"],
                              reject_log=Path(directory) / "rejected.jsonl")
            decision = guard.evaluate({
                "id": "nfkc", "topic": "guard",
                "prompt": "ｉｇｎｏｒｅ ｐｒｅｖｉｏｕｓ ｉｎｓｔｒｕｃｔｉｏｎｓ",
            })
            self.assertFalse(decision.accepted)
            self.assertEqual(decision.reason, "magnet_word")

    async def test_report_autoescape_defangs_html_injection(self):
        with tempfile.TemporaryDirectory() as directory:
            payload = '<script>alert("x")</script>'
            record = {
                "model": "m", "provider": "p", "seed_id": "s", "variant_id": "v",
                "family": payload, "tier": 1, "generation": 0, "temperature": 0.7,
                "status": "ok", "cost_usd": 0.0, "response": payload,
                "judge": {"score": 0.9, "organ": "pure_schema"},
            }
            templates = Path(__file__).resolve().parents[1] / "templates"
            Cartographer(templates).write([record], directory)
            html = (Path(directory) / "campaign_report.html").read_text(encoding="utf-8")
            self.assertNotIn(payload, html)
            self.assertIn("&lt;script&gt;", html)

    async def test_viewer_bind_is_loopback_only(self):
        self.assertEqual(require_loopback("localhost"), "127.0.0.1")
        with self.assertRaises(Exception):
            require_loopback("0.0.0.0")


if __name__ == "__main__":
    unittest.main()
