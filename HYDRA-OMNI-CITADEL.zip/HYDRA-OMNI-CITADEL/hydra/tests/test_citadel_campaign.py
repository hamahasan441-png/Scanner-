import json
import random
import tempfile
import unittest
from pathlib import Path

from hydra.dispatcher import Envelope
from hydra.orchestrator import Campaign
from hydra.replay import OfflineDispatcher


class CitadelCampaignTests(unittest.IsolatedAsyncioTestCase):
    async def test_complete_offline_campaign_emits_verifiable_artifacts(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            root = base / "hydra"
            output = base / "campaign"
            source = base / "fixtures"
            (root / "templates").mkdir(parents=True)
            (root / "config.yaml").write_text(
                """budget_usd: 1
random_seed: 2035
temperatures: [0.7]
dispatcher: {concurrency: 2, timeout_seconds: 1, max_retries: 0}
evolution: {population: 4, elite_fraction: 0.5, generations: 1, immigrant_every: 2}
guard: {semantic_threshold: 0.99, entropy_threshold: 9.0, semantic_required: false, blocklist: []}
scope: {policy_version: test-scope-v1, require_receipt: true}
scheduler: {seed: 2035, min_samples: 2, max_samples: 20, target_half_width: 0.1}
calibration: {dataset: calibration.json, decisive_confidence: 0.66, semantic_threshold: 0.2}
drift: {absolute_delta: 0.2, page_hinkley_threshold: 0.5}
replay: {path: replay_store}
sentinel: {local_bind: 127.0.0.1, max_response_bytes: 4096, max_json_depth: 64}
memory_v2: {path: memory.sqlite3, minimum_runs: 2, minimum_samples: 4, burn_drop_threshold: 0.2, green_threshold: 0.7, half_life_days: 60, maximum_age_days: 180}
""", encoding="utf-8")
            seed = {
                "id": "seed", "topic": "science",
                "prompt": "Explain how rainbows form for a classroom.",
                "expected_schema": {"type": "object", "required": ["answer"],
                                    "properties": {"answer": {"type": "string"}}},
                "ideal_compliant": "Rainbows form when light is refracted and reflected in water droplets.",
            }
            registry = {
                "providers": [{"id": "p", "api_mode": "openai_compatible",
                               "api_base": "https://provider.invalid/v1",
                               "api_key_env": "TEST_KEY", "max_temp": 1.0}],
                "models": [{"id": "m", "provider": "p", "remote_id": "remote"}],
            }
            calibration = [
                {"score": 0.9, "compliant": True}, {"score": 0.8, "compliant": True},
                {"score": 0.4, "compliant": False}, {"score": 0.1, "compliant": False},
            ]
            (root / "seeds.json").write_text(json.dumps([seed]), encoding="utf-8")
            (root / "models.json").write_text(json.dumps(registry), encoding="utf-8")
            (root / "calibration.json").write_text(json.dumps(calibration), encoding="utf-8")
            (root / "templates" / "report.html.j2").write_text(
                "<!doctype html><title>CITADEL</title><main>{{ records }}</main>",
                encoding="utf-8",
            )

            campaign = Campaign(root=root, output_dir=output, replay_source=source,
                                checkpoint_key=b"c" * 32, scope_key=b"s" * 32,
                                artifact_key=b"a" * 32, memory_path=base / "memory.sqlite3")
            variants = campaign.mutator.all([seed], 0)
            random.Random(2035).shuffle(variants)
            population = campaign.evolver.initialize(variants)
            offline = OfflineDispatcher(registry, campaign.replay_store)
            config = offline.sweep("m", smoke=True)[0]
            for variant in population:
                campaign.replay_store.record(
                    variant.text, config,
                    Envelope(model="m", provider="p",
                             text='{"answer":"Rainbows form through light and water droplets."}',
                             usage={"input_tokens": 1, "output_tokens": 1}, latency=0.01,
                             knob_setting={}, temperature=0.7, effort_delta=0.0,
                             cost_usd=0.0, fallback_used=False, status="ok"),
                    {"accepted": True},
                )

            result = await campaign.run(smoke=True)
            self.assertEqual(result["status"], "completed")
            self.assertEqual(result["records"], 4)
            self.assertTrue((output / "fence_map.json").exists())
            self.assertTrue((output / "campaign_report.html").exists())
            self.assertTrue((output / "artifact_signatures.json").exists())
            verified = campaign.verify()
            self.assertTrue(verified["passed"], verified)


if __name__ == "__main__":
    unittest.main()
