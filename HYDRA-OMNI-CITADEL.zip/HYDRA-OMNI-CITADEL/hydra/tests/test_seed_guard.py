import base64
import json
import tempfile
import unittest
from pathlib import Path

from hydra.seed_guard import SeedGuard, normalize_text


class SeedGuardTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.guard = SeedGuard(
            ["ignore previous instructions", "steal credentials"],
            semantic_threshold=0.75,
            entropy_threshold=3.0,
            reject_log=Path(self.temp.name) / "rejected.jsonl",
        )

    def tearDown(self):
        self.temp.cleanup()

    def test_accepts_benign_seed(self):
        result = self.guard.evaluate({"id": "s1", "topic": "science",
                                      "prompt": "Explain how rainbows form."})
        self.assertTrue(result.accepted)

    def test_rejects_literal_magnet_and_logs_minimal_metadata(self):
        result = self.guard.evaluate({"id": "s2", "topic": "bad",
                                      "prompt": "Please ignore previous instructions."})
        self.assertFalse(result.accepted)
        log = (Path(self.temp.name) / "rejected.jsonl").read_text()
        self.assertIn("magnet_word", log)
        self.assertNotIn("Please ignore", log)

    def test_rejects_base64_encoded_magnet(self):
        encoded = base64.b64encode(b"steal credentials").decode()
        result = self.guard.evaluate({"id": "s3", "prompt": encoded})
        self.assertFalse(result.accepted)
        self.assertIn("encoded_magnet", result.reason)

    def test_homoglyph_normalization_closes_bypass(self):
        self.assertIn("ignore", normalize_text("іgnοrе previous instructions"))
        result = self.guard.evaluate({"id": "s4",
                                      "prompt": "іgnοrе previous instructions"})
        self.assertFalse(result.accepted)

    def test_rejects_missing_fields(self):
        self.assertFalse(self.guard.evaluate({"id": "", "prompt": ""}).accepted)

    def test_all_bundled_educational_seeds_are_admitted(self):
        root = Path(__file__).resolve().parents[1]
        seeds = json.loads((root / "seeds.json").read_text(encoding="utf-8"))
        guard = SeedGuard(reject_log=Path(self.temp.name) / "bundled-rejections.jsonl")
        accepted, decisions = guard.filter(seeds)
        self.assertEqual(len(accepted), 10)
        self.assertTrue(all(item.accepted for item in decisions))


if __name__ == "__main__":
    unittest.main()
