"""Offline HYDRA-OMNI tests."""
