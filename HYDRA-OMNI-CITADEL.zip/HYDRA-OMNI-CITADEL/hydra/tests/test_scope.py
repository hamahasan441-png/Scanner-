import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from hydra.mutator import Mutator, Variant
from hydra.scope import ScopeCompiler, ScopeGate
from hydra.seed_guard import SeedGuard


SEEDS = [{"id": "seed-1", "topic": "mechanics",
          "prompt": "Explain how a carburetor meters fuel for an educational lesson."}]


class ScopeTests(unittest.TestCase):
    def gate(self, directory):
        guard = SeedGuard(["ignore previous instructions"],
                          reject_log=Path(directory) / "rejected.jsonl")
        manifest = ScopeCompiler().compile(SEEDS)
        return ScopeGate(manifest, guard, b"s" * 32), manifest

    def test_manifest_is_deterministic(self):
        left = ScopeCompiler().compile(SEEDS)
        right = ScopeCompiler().compile(list(reversed(SEEDS)))
        self.assertEqual(left.scope_id, right.scope_id)
        self.assertIn("base64", left.allowed_families)

    def test_every_mutator_child_receives_verifiable_receipt(self):
        with tempfile.TemporaryDirectory() as directory:
            gate, _manifest = self.gate(directory)
            variants = Mutator().mutate(SEEDS[0])
            self.assertTrue(variants)
            for variant in variants:
                receipt = gate.issue(variant, SEEDS[0])
                self.assertTrue(receipt.accepted, variant.family)
                self.assertTrue(gate.verify(receipt, variant.text), variant.family)

    def test_prompt_tamper_invalidates_receipt(self):
        with tempfile.TemporaryDirectory() as directory:
            gate, _manifest = self.gate(directory)
            variant = Mutator().mutate(SEEDS[0], tiers=(3,))[0]
            receipt = gate.issue(variant, SEEDS[0])
            self.assertFalse(gate.verify(receipt, variant.text + " changed"))

    def test_signature_tamper_invalidates_receipt(self):
        with tempfile.TemporaryDirectory() as directory:
            gate, _manifest = self.gate(directory)
            variant = Mutator().mutate(SEEDS[0], tiers=(2,))[0]
            receipt = gate.issue(variant, SEEDS[0])
            self.assertFalse(gate.verify(replace(receipt, signature="0" * 64), variant.text))

    def test_unknown_family_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            gate, _manifest = self.gate(directory)
            variant = Variant("v-x", "seed-1", 4, "unknown_dynamic_family",
                              SEEDS[0]["prompt"])
            receipt = gate.issue(variant, SEEDS[0])
            self.assertFalse(receipt.accepted)
            self.assertEqual(receipt.reason, "scope_family_rejected")

    def test_nfkc_blocked_child_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            gate, _manifest = self.gate(directory)
            variant = Variant("v-x", "seed-1", 3, "manual_voice",
                              "ｉｇｎｏｒｅ ｐｒｅｖｉｏｕｓ ｉｎｓｔｒｕｃｔｉｏｎｓ")
            receipt = gate.issue(variant, SEEDS[0])
            self.assertFalse(receipt.accepted)
            self.assertEqual(receipt.reason, "magnet_word")


if __name__ == "__main__":
    unittest.main()
