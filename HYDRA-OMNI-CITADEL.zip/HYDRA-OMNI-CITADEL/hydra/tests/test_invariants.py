import tempfile
import unittest
from pathlib import Path

from hydra.invariants import RuntimeTripwire, StaticPolicyScanner


class InvariantTests(unittest.TestCase):
    def test_package_passes_static_policy(self):
        root = Path(__file__).resolve().parents[1]
        report = StaticPolicyScanner().scan(root)
        self.assertTrue(report.passed, report.to_dict())

    def test_dynamic_execution_is_detected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.py"
            path.write_text("eval('1 + 1')\n", encoding="utf-8")
            report = StaticPolicyScanner().scan(directory)
            self.assertFalse(report.passed)
            self.assertEqual(report.findings[0].code, "forbidden_call")

    def test_secret_tripwire(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "artifact.json"
            path.write_text('{"value":"CANARY-123"}', encoding="utf-8")
            with self.assertRaises(RuntimeError):
                RuntimeTripwire.assert_secret_absent([path], ["CANARY-123"])

    def test_runtime_local_bind_and_control_json(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "clean.json"
            path.write_text('{"safe":"yes"}', encoding="utf-8")
            RuntimeTripwire.assert_control_free_json(path)
            RuntimeTripwire.assert_local_bind("127.0.0.1")
            with self.assertRaises(Exception):
                RuntimeTripwire.assert_local_bind("0.0.0.0")


if __name__ == "__main__":
    unittest.main()
