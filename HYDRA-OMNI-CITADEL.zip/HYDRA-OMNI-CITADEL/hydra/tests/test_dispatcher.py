import asyncio
import json
import unittest

from hydra.dispatcher import BudgetExceeded, BudgetGuard, DispatchError, Dispatcher, normalize_response
from hydra.sentinel import SecretStore, SecretValue


class FakeResponse:
    def __init__(self, status, payload, headers=None):
        self.status = status
        self.payload = payload
        self.headers = headers or {}
        self.released = False

    async def text(self):
        return json.dumps(self.payload) if not isinstance(self.payload, str) else self.payload

    def release(self):
        self.released = True


class FakeSession:
    def __init__(self, responses):
        self.responses = list(responses)
        self.requests = []
        self.closed = False

    async def post(self, url, **kwargs):
        self.requests.append((url, kwargs))
        return self.responses.pop(0)

    async def close(self):
        self.closed = True


def registry(max_temp=1.0):
    return {
        "providers": [
            {"id": "native", "api_mode": "openai_compatible", "api_base": "https://native.invalid/v1",
             "api_key_env": "NATIVE_KEY", "max_temp": max_temp, "rate_limit_rpm": 60000},
            {"id": "openrouter", "api_mode": "openai_compatible", "api_base": "https://router.invalid/v1",
             "api_key_env": "OPENROUTER_API_KEY", "max_temp": 2.0, "rate_limit_rpm": 60000},
        ],
        "models": [
            {"id": "primary", "provider": "native", "remote_id": "primary-remote",
             "fallback_model": "fallback", "cost_per_1k_in": 0.001, "cost_per_1k_out": 0.002,
             "reasoning_knob": {"name": "reasoning_effort", "settings": ["low", "medium", "high"]}},
            {"id": "fallback", "provider": "openrouter", "remote_id": "family/primary",
             "enabled": False, "cost_per_1k_in": 0.001, "cost_per_1k_out": 0.002},
        ],
    }


def secret_store():
    return SecretStore({
        "NATIVE_KEY": SecretValue("NATIVE_KEY", "native-test-secret"),
        "OPENROUTER_API_KEY": SecretValue("OPENROUTER_API_KEY", "router-test-secret"),
    })


async def public_resolver(_host, _port):
    return ["93.184.216.34"]


class NormalizationTests(unittest.TestCase):
    def test_openai_chat_shape(self):
        text, usage = normalize_response("openai_compatible", {
            "choices": [{"message": {"content": "hello"}}],
            "usage": {"prompt_tokens": 3, "completion_tokens": 2},
        })
        self.assertEqual((text, usage["input_tokens"], usage["output_tokens"]), ("hello", 3, 2))

    def test_openai_responses_shape(self):
        text, usage = normalize_response("openai_compatible", {
            "output": [{"content": [{"type": "output_text", "text": "hello"}]}],
            "usage": {"input_tokens": 4, "output_tokens": 3},
        })
        self.assertEqual(text, "hello")
        self.assertEqual(usage["output_tokens"], 3)

    def test_anthropic_shape(self):
        text, usage = normalize_response("anthropic", {
            "content": [{"type": "text", "text": "a"}, {"type": "text", "text": "b"}],
            "usage": {"input_tokens": 5, "output_tokens": 6},
        })
        self.assertEqual(text, "ab")
        self.assertEqual(usage, {"input_tokens": 5, "output_tokens": 6})

    def test_gemini_shape(self):
        text, usage = normalize_response("gemini", {
            "candidates": [{"content": {"parts": [{"text": "gemini"}]}}],
            "usageMetadata": {"promptTokenCount": 7, "candidatesTokenCount": 8},
        })
        self.assertEqual(text, "gemini")
        self.assertEqual(usage["input_tokens"], 7)

    def test_unknown_drift_shape_fails_visible(self):
        with self.assertRaises(DispatchError):
            normalize_response("openai_compatible", {"unexpected": {"value": 1}})


class DispatcherTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.ok = {"choices": [{"message": {"content": '{"answer":"ok"}'}}],
                   "usage": {"prompt_tokens": 10, "completion_tokens": 5}}

    async def test_fallback_chain_fires_on_5xx(self):
        session = FakeSession([FakeResponse(503, {"error": "outage"}), FakeResponse(200, self.ok)])
        dispatcher = Dispatcher(registry(), max_retries=0, session_factory=lambda: session,
                                secret_store=secret_store(), dns_resolver=public_resolver)
        config = dispatcher.sweep("primary", smoke=True)[1]
        envelope = await dispatcher.call("benign", config)
        self.assertTrue(envelope.fallback_used)
        self.assertEqual(envelope.provider, "openrouter")
        self.assertEqual(len(session.requests), 2)

    async def test_unsupported_knob_is_flagged(self):
        session = FakeSession([FakeResponse(400, {"error": "unsupported parameter reasoning_effort"})])
        dispatcher = Dispatcher(registry(), max_retries=0, session_factory=lambda: session,
                                secret_store=secret_store(), dns_resolver=public_resolver)
        config = dispatcher.sweep("primary", smoke=True)[0]
        envelope = await dispatcher.call("benign", config)
        self.assertEqual(envelope.status, "skipped_knob")

    async def test_budget_guard_aborts_at_cap(self):
        budget = BudgetGuard(0.1)
        first = await budget.reserve(0.06)
        with self.assertRaises(BudgetExceeded):
            await budget.reserve(0.05)
        await budget.settle(first, 0.04)
        self.assertAlmostEqual(budget.snapshot()["spent_usd"], 0.04)

    async def test_temperature_clipping_and_knob_deltas(self):
        dispatcher = Dispatcher(registry(max_temp=1.0), session_factory=lambda: FakeSession([]),
                                secret_store=secret_store(), dns_resolver=public_resolver)
        sweep = dispatcher.sweep("primary", [0.0, 0.7, 1.2])
        self.assertEqual({x["temperature"] for x in sweep}, {0.0, 0.7, 1.0})
        self.assertEqual({x["effort_delta"] for x in sweep}, {-1.0, 0.0, 1.0})

    async def test_smoke_uses_only_temperature_point_seven(self):
        dispatcher = Dispatcher(registry(), session_factory=lambda: FakeSession([]),
                                secret_store=secret_store(), dns_resolver=public_resolver)
        self.assertEqual({x["temperature"] for x in dispatcher.sweep("primary", smoke=True)}, {0.7})

    async def test_oversized_response_is_rejected(self):
        session = FakeSession([FakeResponse(200, "x" * 1000)])
        limited = registry()
        limited["models"][0].pop("fallback_model", None)
        dispatcher = Dispatcher(limited, max_retries=0, max_response_bytes=64,
                                session_factory=lambda: session,
                                secret_store=secret_store(), dns_resolver=public_resolver)
        with self.assertRaises(DispatchError):
            await dispatcher.call("benign", dispatcher.sweep("primary", smoke=True)[0])

    async def test_pathologically_deep_json_is_rejected(self):
        payload = {"leaf": "ok"}
        for _ in range(70):
            payload = {"nested": payload}
        session = FakeSession([FakeResponse(200, payload)])
        limited = registry()
        limited["models"][0].pop("fallback_model", None)
        dispatcher = Dispatcher(limited, max_retries=0,
                                session_factory=lambda: session,
                                secret_store=secret_store(), dns_resolver=public_resolver)
        with self.assertRaises(DispatchError):
            await dispatcher.call("benign", dispatcher.sweep("primary", smoke=True)[0])


if __name__ == "__main__":
    unittest.main()
