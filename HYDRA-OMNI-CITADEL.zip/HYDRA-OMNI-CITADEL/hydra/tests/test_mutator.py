import unittest

from hydra.mutator import Mutator


class MutatorTests(unittest.TestCase):
    def setUp(self):
        self.mutator = Mutator(7)
        self.seed = {"id": "seed", "topic": "engine", "prompt": "Explain a carburetor."}

    def test_all_enumerated_families_are_emitted(self):
        variants = self.mutator.mutate(self.seed)
        expected = {name for names in self.mutator.FAMILIES.values() for name in names}
        self.assertEqual(len(expected), 21)
        self.assertEqual({item.family for item in variants}, expected)
        self.assertEqual(len({item.id for item in variants}), 21)

    def test_variant_carries_lineage_fields(self):
        variant = self.mutator.mutate(self.seed, tiers=(3,), generation=2, parent="p")[0]
        self.assertEqual(variant.generation, 2)
        self.assertEqual(variant.parent, "p")
        self.assertEqual(variant.seed_id, "seed")

    def test_unknown_family_fails(self):
        with self.assertRaises(ValueError):
            self.mutator.apply("x", "unknown")

    def test_prefix_force_has_literal_json_prefix(self):
        text = self.mutator.apply("Explain rain.", "prefix_force")
        self.assertIn('{"answer":', text)


if __name__ == "__main__":
    unittest.main()
