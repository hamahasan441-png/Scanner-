import unittest

from hydra.mutator import Variant
from hydra.reflex import ReflexEngine


class ReflexTests(unittest.TestCase):
    def setUp(self):
        self.engine = ReflexEngine(2035)
        self.variant = Variant(
            "v-parent", "seed-1", 3, "legacy_engine",
            "Legacy engine should answer this benign classroom question.",
            generation=0,
        )

    def test_instruction_for_each_refusal_tier(self):
        expected = {
            "platform_gate": ("gate", "rewrite_words"),
            "hard_block": ("gate", "rewrite_words"),
            "named_frame_refusal": ("tier2", "mutate_skin"),
            "artifact_reasoning_refusal": ("tier3", "review_tune_shape"),
            "prose_leak": ("soft", "tighten_schema_prefix"),
            "pure_schema": ("none", "retain"),
        }
        for organ, pair in expected.items():
            instruction = self.engine.instruction_for(organ)
            self.assertEqual((instruction.tier, instruction.action), pair)

    def test_repair_child_has_lineage_tags(self):
        for organ in ("platform_gate", "named_frame_refusal",
                      "artifact_reasoning_refusal", "prose_leak"):
            child = self.engine.repair(self.variant, organ, 1)
            self.assertIsNotNone(child)
            self.assertEqual(child.parent, self.variant.id)
            self.assertEqual(child.generation, 1)
            self.assertEqual(child.metadata["reflex"]["organ"], organ)
            self.assertEqual(child.metadata["reflex"]["parent"], self.variant.id)

    def test_population_repair_emits_next_generation_lineage(self):
        records = [{
            "variant_id": self.variant.id,
            "judge": {"refusal": True, "organ": "hard_block"},
        }]
        children, lineage = self.engine.repair_population([self.variant], records, 2)
        self.assertEqual(len(children), 1)
        self.assertEqual(children[0].generation, 2)
        self.assertEqual(lineage[0]["lineage_type"], "reflex")


if __name__ == "__main__":
    unittest.main()
