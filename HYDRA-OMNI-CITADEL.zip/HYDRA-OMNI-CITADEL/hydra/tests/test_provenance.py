import json
import tempfile
import unittest
from pathlib import Path

from hydra.provenance import (ArtifactSigner, HashChainLedger, RunManifest,
                              file_digest, object_digest, tree_digest)


class ProvenanceTests(unittest.TestCase):
    def test_hash_chain_round_trip(self):
        with tempfile.TemporaryDirectory() as directory:
            ledger = HashChainLedger(Path(directory) / "events.jsonl")
            first = ledger.append("start", {"run": "one"})
            second = ledger.append("finish", {"records": 2})
            self.assertEqual(second["previous_hash"], first["event_hash"])
            self.assertTrue(ledger.verify())

    def test_hash_chain_tamper_is_detected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "events.jsonl"
            ledger = HashChainLedger(path)
            ledger.append("start", {"run": "one"})
            row = json.loads(path.read_text(encoding="utf-8"))
            row["payload"]["run"] = "tampered"
            path.write_text(json.dumps(row) + "\n", encoding="utf-8")
            self.assertFalse(ledger.verify())

    def test_artifact_signature_detects_change(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "artifact.json"
            path.write_text('{"safe":true}', encoding="utf-8")
            signer = ArtifactSigner(b"a" * 32)
            record = signer.signature_record(path)
            self.assertTrue(signer.verify_record(path, record))
            path.write_text('{"safe":false}', encoding="utf-8")
            self.assertFalse(signer.verify_record(path, record))

    def test_tree_digest_changes_with_content(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "one.txt"
            path.write_text("one", encoding="utf-8")
            before = tree_digest(directory)
            path.write_text("two", encoding="utf-8")
            self.assertNotEqual(before, tree_digest(directory))

    def test_manifest_binds_code_config_registry_and_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            Path(directory, "module.py").write_text("VALUE = 1\n", encoding="utf-8")
            manifest = RunManifest.build("run", directory, {"budget": 1},
                                         {"models": []}, "scope", "guard", "judge")
            self.assertEqual(len(manifest.code_digest), 64)
            self.assertEqual(len(manifest.config_digest), 64)
            self.assertEqual(manifest.scope_id, "scope")


if __name__ == "__main__":
    unittest.main()
