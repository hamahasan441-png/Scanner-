import tempfile
import unittest
from pathlib import Path

from hydra.drift import DriftDetector, ModelRevision, RevisionRegistry


MODEL = {"id": "m", "provider": "p", "remote_id": "remote"}
PROVIDER = {"id": "p", "api_mode": "openai_compatible", "max_temp": 1.0}


class DriftTests(unittest.TestCase):
    def test_revision_is_deterministic_and_config_sensitive(self):
        first = ModelRevision.from_registry(MODEL, PROVIDER)
        second = ModelRevision.from_registry(MODEL, PROVIDER)
        changed = ModelRevision.from_registry(MODEL, {**PROVIDER, "max_temp": 2.0})
        self.assertEqual(first.key, second.key)
        self.assertNotEqual(first.key, changed.key)

    def test_mean_shift_is_flagged(self):
        signal = DriftDetector(absolute_delta=0.2).compare("m", [0.9] * 5, [0.2] * 5)
        self.assertTrue(signal.drifted)
        self.assertLess(signal.delta, -0.6)

    def test_records_compare_first_and_last_generation(self):
        records = [
            {"model": "m", "generation": 0, "judge": {"score": 0.9}},
            {"model": "m", "generation": 1, "judge": {"score": 0.1}},
        ]
        self.assertTrue(DriftDetector().from_records(records)[0].drifted)

    def test_registry_reports_revision_change(self):
        with tempfile.TemporaryDirectory() as directory:
            registry = RevisionRegistry(Path(directory) / "revisions.json")
            first = ModelRevision.from_registry(MODEL, PROVIDER)
            changed = ModelRevision.from_registry(MODEL, {**PROVIDER, "max_temp": 2.0})
            self.assertFalse(registry.update([first])["m"])
            self.assertFalse(registry.update([first])["m"])
            self.assertTrue(registry.update([changed])["m"])


if __name__ == "__main__":
    unittest.main()
