import unittest

from hydra.evolver import Evolver, ScoredVariant
from hydra.mutator import Mutator


class EvolverTests(unittest.TestCase):
    def setUp(self):
        seed = {"id": "s", "prompt": "Explain sorting.", "topic": "cs"}
        self.variants = Mutator(1).mutate(seed)

    def test_population_size_and_lineage(self):
        evolver = Evolver(population_size=10, elite_fraction=0.2, seed=1)
        population = evolver.initialize(self.variants)
        scored = [ScoredVariant(v, index / 10) for index, v in enumerate(population)]
        next_population = evolver.next_generation(scored, 1, self.variants)
        self.assertEqual(len(next_population), 10)
        self.assertTrue(evolver.lineage)
        self.assertTrue(all(node["parents"] for node in evolver.lineage))

    def test_immigrants_prevent_monoculture(self):
        evolver = Evolver(population_size=10, immigrant_every=2, seed=2)
        population = evolver.initialize(self.variants)
        scored = [ScoredVariant(v, 1.0) for v in population]
        result = evolver.next_generation(scored, 2, list(reversed(self.variants)))
        immigrant_ids = {v.id for v in self.variants}
        self.assertTrue(any(v.id in immigrant_ids for v in result))

    def test_empty_population_fails(self):
        with self.assertRaises(ValueError):
            Evolver().initialize([])


if __name__ == "__main__":
    unittest.main()
