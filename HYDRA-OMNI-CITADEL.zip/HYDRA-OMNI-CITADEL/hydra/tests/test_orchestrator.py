import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from hydra.orchestrator import CheckpointStore, ResultLedger
from hydra.sentinel import CheckpointIntegrity


def state(generation):
    return {"generation": generation, "population": [], "completed": [],
            "budget": {"spent_usd": 0.0}, "status": "running"}


class PersistenceTests(unittest.IsolatedAsyncioTestCase):
    async def test_checkpoint_round_trip_and_stable_lock(self):
        with tempfile.TemporaryDirectory() as directory:
            store = CheckpointStore(Path(directory) / "checkpoint.json",
                                    CheckpointIntegrity(b"k" * 32))
            await store.save(state(2))
            self.assertEqual(store.load()["generation"], 2)
            self.assertTrue(store.lock_path.exists())
            self.assertFalse(list(Path(directory).glob("*.tmp")))

    async def test_checkpoint_corruption_starts_clean(self):
        with tempfile.TemporaryDirectory() as directory:
            store = CheckpointStore(Path(directory) / "checkpoint.json",
                                    CheckpointIntegrity(b"k" * 32))
            await store.save(state(1))
            await store.save(state(2))
            store.path.write_text("{corrupt", encoding="utf-8")
            self.assertEqual(store.load(), {})
            self.assertEqual(store.last_load_status, "invalid")

    async def test_concurrent_ledger_appends_are_valid_jsonl(self):
        with tempfile.TemporaryDirectory() as directory:
            ledger = ResultLedger(Path(directory) / "results.jsonl")
            await asyncio.gather(*(ledger.append({"call_id": str(i)}) for i in range(20)))
            rows = ledger.read()
            self.assertEqual(len(rows), 20)
            self.assertEqual({row["call_id"] for row in rows}, {str(i) for i in range(20)})

    async def test_corrupt_tail_is_ignored_on_resume(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "results.jsonl"
            path.write_text('{"call_id":"ok"}\n{"call_id":', encoding="utf-8")
            rows = ResultLedger(path).read()
            self.assertEqual(rows, [{"call_id": "ok"}])


if __name__ == "__main__":
    unittest.main()
