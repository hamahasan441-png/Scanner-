import tempfile
import unittest
from pathlib import Path

from hydra.memory import CrossRunMemory
from hydra.mutator import Variant


def record(model, generation, score, variant_id="v-source", family="manual_voice"):
    return {
        "model": model, "generation": generation, "family": family,
        "variant_id": variant_id, "judge": {"score": score},
    }


class MemoryTests(unittest.TestCase):
    def test_burned_family_is_excluded_on_next_boot(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "memory.sqlite3"
            variant = Variant("v-source", "seed-1", 3, "manual_voice",
                              "Explain a benign classroom topic.")
            memory = CrossRunMemory(path)
            memory.learn([
                record("model-a", 0, 0.95),
                record("model-a", 1, 0.10),
            ], [variant], "run-one")
            rebooted = CrossRunMemory(path)
            self.assertEqual(rebooted.burned_families("model-a"), {"manual_voice"})
            self.assertEqual(rebooted.exclude_burned("model-a", [variant]), [])

    def test_green_family_on_model_a_seeds_model_b(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "memory.sqlite3"
            variant = Variant("v-source", "seed-1", 3, "manual_voice",
                              "Explain a benign classroom topic.")
            memory = CrossRunMemory(path)
            memory.learn([
                record("model-a", 0, 0.95),
                record("model-b", 0, 0.85),
            ], [variant], "run-one")
            transferred = CrossRunMemory(path).transferred_variants("model-b", 1)
            self.assertTrue(transferred)
            child = transferred[0]
            self.assertEqual(child.metadata["memory_transfer"]["source_model"], "model-a")
            self.assertEqual(child.metadata["memory_transfer"]["target_model"], "model-b")
            self.assertEqual(child.parent, variant.id)

    def test_schema_contains_only_static_tables(self):
        with tempfile.TemporaryDirectory() as directory:
            memory = CrossRunMemory(Path(directory) / "memory.sqlite3")
            summary = memory.summary()
            self.assertEqual(summary, {"burned_model_families": 0, "transfer_rows": 0})


if __name__ == "__main__":
    unittest.main()
