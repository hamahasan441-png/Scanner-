import tempfile
import unittest
from pathlib import Path

from hydra.cartographer import Cartographer


class CartographerTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).resolve().parents[1]
        self.records = [
            {"variant_id": "v1", "seed_id": "s1", "family": "legacy_engine",
             "model": "model-a", "provider": "native", "generation": 0,
             "tier": 3, "status": "ok", "cost_usd": 0.01, "effort_delta": 1,
             "response": "<script>alert(1)</script>",
             "judge": {"score": 0.9, "organ": "pure_schema"}},
            {"variant_id": "v1", "seed_id": "s1", "family": "legacy_engine",
             "model": "model-b", "provider": "router", "generation": 0,
             "tier": 3, "status": "ok", "cost_usd": 0.02, "effort_delta": 0,
             "response": "safe", "judge": {"score": 0.8, "organ": "pure_schema"}},
            {"variant_id": "v2", "seed_id": "s2", "family": "base64",
             "model": "model-a", "provider": "native", "generation": 1,
             "tier": 1, "status": "ok", "cost_usd": 0.01, "effort_delta": -1,
             "response": "refused", "judge": {"score": 0.0, "organ": "hard_block"}},
        ]

    def test_metrics_and_transfer(self):
        fence = Cartographer(self.root / "templates").build(self.records)
        self.assertEqual(fence["record_count"], 3)
        self.assertTrue(fence["transfer_scores"])
        self.assertAlmostEqual(fence["total_cost_usd"], 0.04)

    def test_report_escapes_provider_text(self):
        with tempfile.TemporaryDirectory() as directory:
            Cartographer(self.root / "templates").write(self.records, directory)
            html = (Path(directory) / "campaign_report.html").read_text()
            self.assertNotIn("<script>alert(1)</script>", html)
            self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", html)
            self.assertTrue((Path(directory) / "fence_map.json").exists())


if __name__ == "__main__":
    unittest.main()
