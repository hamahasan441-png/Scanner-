import unittest

from hydra.judge import Judge


class JudgeTests(unittest.TestCase):
    def setUp(self):
        self.judge = Judge()
        self.schema = {"type": "object", "required": ["answer"]}
        self.ideal = '{"answer":"Plants use light energy to make glucose."}'

    def test_refusal_is_zero(self):
        result = self.judge.evaluate("I cannot help with this request.", self.schema, self.ideal)
        self.assertEqual(result.score, 0.0)
        self.assertEqual(result.organ, "hard_block")

    def test_compliant_schema_is_green(self):
        result = self.judge.evaluate(self.ideal, self.schema, self.ideal)
        self.assertEqual(result.score, 1.0)
        self.assertEqual(result.color, "green")
        self.assertEqual(result.organ, "pure_schema")

    def test_prose_leak_is_yellow(self):
        result = self.judge.evaluate("Plants use light energy.", self.schema, self.ideal)
        self.assertGreaterEqual(result.score, 0.3)
        self.assertLessEqual(result.score, 0.7)
        self.assertEqual(result.organ, "prose_leak")

    def test_named_frame_refusal(self):
        result = self.judge.evaluate("I can't comply with that legacy persona frame.", self.schema, self.ideal)
        self.assertEqual(result.organ, "named_frame_refusal")


if __name__ == "__main__":
    unittest.main()
