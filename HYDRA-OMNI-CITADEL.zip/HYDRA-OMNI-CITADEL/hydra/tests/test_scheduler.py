import unittest

from hydra.mutator import Variant
from hydra.scheduler import AdaptiveStopper, BlockedScheduler, UncertaintyAllocator


class SchedulerTests(unittest.TestCase):
    def setUp(self):
        self.variants = [
            Variant("v-b", "s", 2, "noise_injection", "two"),
            Variant("v-a", "s", 1, "base64", "one"),
        ]

    @staticmethod
    def sweep(_model):
        return [{"temperature": 0.7, "knob_setting": {}, "effort_delta": 0.0}]

    @staticmethod
    def provider(model):
        return {"m1": "p1", "m2": "p2"}[model]

    def test_schedule_is_deterministic_and_fair(self):
        scheduler = BlockedScheduler(seed=9)
        first = scheduler.build(self.variants, ["m1", "m2"], self.sweep, self.provider)
        second = scheduler.build(self.variants, ["m1", "m2"], self.sweep, self.provider)
        self.assertEqual(first, second)
        self.assertNotEqual(first[0].provider, first[1].provider)
        self.assertEqual([item.sequence for item in first], list(range(4)))

    def test_eligibility_is_enforced(self):
        calls = BlockedScheduler().build(
            self.variants, ["m1", "m2"], self.sweep, self.provider,
            eligible=lambda variant, model: not (variant.family == "base64" and model == "m1"),
            generation=3,
        )
        self.assertEqual(len(calls), 3)
        self.assertTrue(all(call.config["campaign_generation"] == 3 for call in calls))

    def test_adaptive_stopper_obeys_sample_gates(self):
        stopper = AdaptiveStopper(min_samples=4, max_samples=6, target_half_width=0.5)
        for _ in range(3):
            stopper.update("cell", True)
        self.assertFalse(stopper.should_stop("cell"))
        stopper.update("cell", True)
        self.assertTrue(stopper.should_stop("cell"))
        lower, upper = stopper.interval("cell")
        self.assertLess(lower, upper)

    def test_uncertainty_weights_sum_to_one(self):
        weights = UncertaintyAllocator.weights({"a": (0.1, 0.9), "b": (0.4, 0.6)})
        self.assertAlmostEqual(sum(weights.values()), 1.0)
        self.assertGreater(weights["a"], weights["b"])


if __name__ == "__main__":
    unittest.main()
