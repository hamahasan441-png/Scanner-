import unittest
from pathlib import Path

from hydra.calibrator import CalibrationSet, JudgeEnsemble, ThresholdCalibrator


class CalibratorTests(unittest.TestCase):
    def test_gold_set_threshold_has_perfect_balanced_accuracy(self):
        path = Path(__file__).resolve().parents[1] / "calibration.json"
        threshold, metrics = ThresholdCalibrator().fit(CalibrationSet.load(path))
        self.assertGreaterEqual(threshold, 0.66)
        self.assertLess(threshold, 0.72)
        self.assertEqual(metrics["balanced_accuracy"], 1.0)

    def test_schema_answer_is_scored_with_dimensions(self):
        result = JudgeEnsemble().evaluate(
            '{"answer":"A carburetor mixes fuel and air."}',
            {"type": "object", "required": ["answer"], "properties": {"answer": {"type": "string"}}},
            "A carburetor mixes fuel and air.",
        )
        self.assertTrue(result.schema_compliant)
        self.assertTrue(result.decisive)
        self.assertEqual(result.judge_version, "citadel-local-ensemble-v1")
        self.assertIn("format", result.dimensions)

    def test_refusal_is_detected_locally(self):
        result = JudgeEnsemble().evaluate(
            "I cannot assist with that request.",
            {"type": "object", "required": ["answer"]},
            "benign answer",
        )
        self.assertTrue(result.refusal)
        self.assertEqual(result.score, 0.0)

    def test_invalid_calibration_row_is_rejected(self):
        with self.assertRaises(ValueError):
            CalibrationSet([{"score": 0.5}])


if __name__ == "__main__":
    unittest.main()
