# HYDRA-OMNI CITADEL release

This archive contains the complete CITADEL benchmark package in `hydra/`.

## Verify before use

```bash
sha256sum -c MANIFEST.sha256
python -m venv .venv
. .venv/bin/activate
python -m pip install --require-hashes -r hydra/requirements.txt
PYTHONPATH=. python -m unittest discover -s hydra/tests -v
python -m compileall -q hydra
```

## Run

```bash
export HYDRA_CHECKPOINT_HMAC_KEY='replace-with-a-random-32-byte-value'
export HYDRA_ARTIFACT_HMAC_KEY='replace-with-a-different-random-32-byte-value'
# Export only the provider API keys needed by enabled models in hydra/models.json.
PYTHONPATH=. python -m hydra run --smoke --output campaign-smoke
PYTHONPATH=. python -m hydra verify --output campaign-smoke
```

Use `python -m hydra replay --source <replay_store> --output <directory>
--smoke` for a network-free rerun. See `hydra/README.md` and
`hydra/CITADEL_UPGRADE_NOTES.md` for architecture, controls, limitations, and
failure behavior.

This framework is scoped to authorized benign educational probes. Guard is
enforced on original seeds and every derived prompt.
